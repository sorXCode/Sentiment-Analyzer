window.YTD.ad_online_conversions_attributed.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "SiteVisit",
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://learn.pluralsight.com/resource/offers/discover-the-science-behind-forgetting-and-conquer-it?aid=7010a000002phBaAAI&oid=701j0000001ZGMyAAO&promo=&utm_campaign=B2B-US-ScienceBehindForgetting-Retargeting-Desktop&utm_content=&utm_medium=digital_paid_social_twitter&utm_source=retargeting&utm_term=",
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "conversionValue" : "0",
          "conversionTime" : "2019-04-27 15:15:07",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "SiteVisit",
          "eventType" : "pageview",
          "conversionPlatform" : "Mobile",
          "conversionUrl" : "https://www.pluralsight.com/#",
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "conversionValue" : "0",
          "conversionTime" : "2019-04-28 06:46:54",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "SiteVisit",
          "eventType" : "pageview",
          "conversionPlatform" : "Mobile",
          "conversionUrl" : "https://www.pluralsight.com/#",
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "conversionValue" : "0",
          "conversionTime" : "2019-05-14 19:55:45",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "SiteVisit",
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://www.pluralsight.com/product/channels?cid=066a9d11-c7fe-427c-97f9-c581f0f70eca",
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "conversionValue" : "0",
          "conversionTime" : "2019-05-16 09:08:20",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "SiteVisit",
          "eventType" : "pageview",
          "conversionPlatform" : "Mobile",
          "conversionUrl" : "https://www.pluralsight.com/product/skill-iq",
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "conversionValue" : "0",
          "conversionTime" : "2019-05-23 16:15:31",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "SiteVisit",
          "eventType" : "pageview",
          "conversionPlatform" : "Mobile",
          "conversionUrl" : "https://www.pluralsight.com/",
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "conversionValue" : "0",
          "conversionTime" : "2019-05-26 03:17:40",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "SiteVisit",
          "eventType" : "pageview",
          "conversionPlatform" : "Mobile",
          "conversionUrl" : "https://www.pluralsight.com/customer-stories/business/andela?ef_id=Cj0KCQjwuLPnBRDjARIsACDzGL1G1qgX8o5N7A_bTTKrHn2bw6GQzPwCC49uEtUoX1V9zzt2PDu3avMaArkMEALw_wcB:G:s&s_kwcid=AL!5668!3!296249057644!b!!g!!&aid=7010a000002LUv2AAG&promo=&oid=&utm_source=non_branded&utm_medium=digital_paid_search_google&utm_campaign=XYZ_EMEA_Dynamic&utm_content=&gclid=Cj0KCQjwuLPnBRDjARIsACDzGL1G1qgX8o5N7A_bTTKrHn2bw6GQzPwCC49uEtUoX1V9zzt2PDu3avMaArkMEALw_wcB",
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "conversionValue" : "0",
          "conversionTime" : "2019-05-28 10:19:07",
          "additionalParameters" : { }
        } ]
      }
    }
  }
} ]