window.YTD.tweet.part0 = [ {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "NairaBetAt10",
      "indices" : [ "78", "91" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "1106510966068379648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1106510966068379648",
  "created_at" : "Fri Mar 15 11:02:26 +0000 2019",
  "favorited" : false,
  "full_text" : "Juventus vs Porto\nBarcelona vs Ajax\nLiverpool vs Man U\nTottenham vs Man City\n\n#NairaBetAt10",
  "lang" : "in"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/w71drEEvC9",
      "expanded_url" : "http://disq.us/t/3425dw4",
      "display_url" : "disq.us/t/3425dw4",
      "indices" : [ "5", "28" ]
    } ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "0",
  "id_str" : "1015142141213986816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1015142141213986816",
  "possibly_sensitive" : false,
  "created_at" : "Fri Jul 06 07:55:21 +0000 2018",
  "favorited" : false,
  "full_text" : "Nice https://t.co/w71drEEvC9",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "UNION BANK",
      "screen_name" : "UNIONBANK_NG",
      "indices" : [ "0", "13" ],
      "id_str" : "429173115",
      "id" : "429173115"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "21" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "965890706928734209",
  "id_str" : "965891076283346944",
  "in_reply_to_user_id" : "429173115",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "965891076283346944",
  "in_reply_to_status_id" : "965890706928734209",
  "created_at" : "Tue Feb 20 10:09:12 +0000 2018",
  "favorited" : false,
  "full_text" : "@UNIONBANK_NG Chinedu",
  "lang" : "en",
  "in_reply_to_screen_name" : "UNIONBANK_NG",
  "in_reply_to_user_id_str" : "429173115"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TOTAL NIGERIA",
      "screen_name" : "TOTALNigeria",
      "indices" : [ "0", "13" ],
      "id_str" : "2223762204",
      "id" : "2223762204"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "1",
  "in_reply_to_status_id_str" : "906118615065403393",
  "id_str" : "906119124669038593",
  "in_reply_to_user_id" : "259258056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "906119124669038593",
  "in_reply_to_status_id" : "906118615065403393",
  "created_at" : "Fri Sep 08 11:36:48 +0000 2017",
  "favorited" : false,
  "full_text" : "@TOTALNigeria 27th of June, 1967... If day and month counts \uD83D\uDE09",
  "lang" : "en",
  "in_reply_to_screen_name" : "sorXCode",
  "in_reply_to_user_id_str" : "259258056"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TOTAL NIGERIA",
      "screen_name" : "TOTALNigeria",
      "indices" : [ "0", "13" ],
      "id_str" : "2223762204",
      "id" : "2223762204"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "18" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "906086642921988096",
  "id_str" : "906118615065403393",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "906118615065403393",
  "in_reply_to_status_id" : "906086642921988096",
  "created_at" : "Fri Sep 08 11:34:47 +0000 2017",
  "favorited" : false,
  "full_text" : "@TOTALNigeria 1967",
  "lang" : "und",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "EFCC Nigeria",
      "screen_name" : "officialEFCC",
      "indices" : [ "3", "16" ],
      "id_str" : "1088596340",
      "id" : "1088596340"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "831842294655508480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "831842294655508480",
  "created_at" : "Wed Feb 15 12:27:12 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @officialEFCC: If you feel like you aren't where you ought to be in life, make sure to keep your hands doing something positive until de…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "EFCC Nigeria",
      "screen_name" : "officialEFCC",
      "indices" : [ "3", "16" ],
      "id_str" : "1088596340",
      "id" : "1088596340"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "831842181065371648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "831842181065371648",
  "created_at" : "Wed Feb 15 12:26:45 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @officialEFCC: We're only about 14 years old Rita. Luckily we have age on our side and the strength and zeal to burn off some saccharine…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Zoto",
      "screen_name" : "myzoto",
      "indices" : [ "0", "7" ],
      "id_str" : "2869365082",
      "id" : "2869365082"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "807667750751629313",
  "id_str" : "819694245241962496",
  "in_reply_to_user_id" : "259258056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "819694245241962496",
  "in_reply_to_status_id" : "807667750751629313",
  "created_at" : "Thu Jan 12 23:55:11 +0000 2017",
  "favorited" : false,
  "full_text" : "@myzoto issue not resolved!!",
  "lang" : "en",
  "in_reply_to_screen_name" : "sorXCode",
  "in_reply_to_user_id_str" : "259258056"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Zoto",
      "screen_name" : "myzoto",
      "indices" : [ "0", "7" ],
      "id_str" : "2869365082",
      "id" : "2869365082"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "137" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "807904045897760769",
  "id_str" : "812326286697832448",
  "in_reply_to_user_id" : "2869365082",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "812326286697832448",
  "in_reply_to_status_id" : "807904045897760769",
  "created_at" : "Fri Dec 23 15:57:33 +0000 2016",
  "favorited" : false,
  "full_text" : "@myzoto issue still remain unsolved, it's over 14days now. Im not seeing the mail you claim to have sent to my mailbox. What's happening?",
  "lang" : "en",
  "in_reply_to_screen_name" : "myzoto",
  "in_reply_to_user_id_str" : "2869365082"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "SARCASM!",
      "screen_name" : "FunnySayings",
      "indices" : [ "3", "16" ],
      "id_str" : "337502808",
      "id" : "337502808"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "810463164701741056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "810463164701741056",
  "created_at" : "Sun Dec 18 12:34:10 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @FunnySayings: 5 rules of a relationship:\n\n1. stay faithful\n2. make them feel wanted\n3. respect your partner\n4. don't flirt with others…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "126" ],
  "favorite_count" : "0",
  "id_str" : "807979259088269312",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "807979259088269312",
  "created_at" : "Sun Dec 11 16:04:01 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: 90% of the time it's not the person you miss, it's the feelings and moments you had when you were with them.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "807979153853186048",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "807979153853186048",
  "created_at" : "Sun Dec 11 16:03:36 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: If it is important to you, you will find a way. If it's not, you'll find an excuse.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "lovequotes",
      "indices" : [ "108", "119" ]
    }, {
      "text" : "quotes",
      "indices" : [ "120", "127" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "0",
  "id_str" : "807978948126801921",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "807978948126801921",
  "created_at" : "Sun Dec 11 16:02:47 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Love the heart that hurts you, but never hurt the heart that loves you. #lovequotes #quotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "lovequotes",
      "indices" : [ "115", "126" ]
    }, {
      "text" : "quotes",
      "indices" : [ "127", "134" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "134" ],
  "favorite_count" : "0",
  "id_str" : "807978785949810688",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "807978785949810688",
  "created_at" : "Sun Dec 11 16:02:08 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Sometimes the things we are most afraid of, are the things that make us happy! #lovequotes #quotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Zoto",
      "screen_name" : "myzoto",
      "indices" : [ "0", "7" ],
      "id_str" : "2869365082",
      "id" : "2869365082"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "807667750751629313",
  "in_reply_to_user_id" : "2869365082",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "807667750751629313",
  "created_at" : "Sat Dec 10 19:26:12 +0000 2016",
  "favorited" : false,
  "full_text" : "@myzoto Referred friends but neither I nor them is getting d bonus after successful recharges &amp; IDs upload 4 verification. Its over 96hrs nw",
  "lang" : "en",
  "in_reply_to_screen_name" : "myzoto",
  "in_reply_to_user_id_str" : "2869365082"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "lovequotes",
      "indices" : [ "103", "114" ]
    }, {
      "text" : "quotes",
      "indices" : [ "115", "122" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "122" ],
  "favorite_count" : "0",
  "id_str" : "787064185175891968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "787064185175891968",
  "created_at" : "Fri Oct 14 22:54:59 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Some days are meant to be counted, others are meant to be weighed. #lovequotes #quotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "787063865313992704",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "787063865313992704",
  "created_at" : "Fri Oct 14 22:53:43 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Sometimes the wrong choices bring us to the right places.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Quote Soup",
      "screen_name" : "Quote_Soup",
      "indices" : [ "3", "14" ],
      "id_str" : "601227277",
      "id" : "601227277"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "787062293469204481",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "787062293469204481",
  "created_at" : "Fri Oct 14 22:47:28 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @Quote_Soup: As long as you can laugh at yourself you will never cease to be amused.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Lovequotes",
      "indices" : [ "91", "102" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "109" ],
  "favorite_count" : "0",
  "id_str" : "787061694862352384",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "787061694862352384",
  "created_at" : "Fri Oct 14 22:45:05 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek People who want things find ways. Others find excuses. #Lovequotes quotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "111" ],
  "favorite_count" : "0",
  "id_str" : "786348003787468800",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "786348003787468800",
  "created_at" : "Wed Oct 12 23:29:08 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: If it is important enough to you, you will find a way. If it is not, you will find an excuse.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "0",
  "id_str" : "785079804748005376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "785079804748005376",
  "created_at" : "Sun Oct 09 11:29:46 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: God's plan is bigger than your mistakes.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "785079425301831680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "785079425301831680",
  "created_at" : "Sun Oct 09 11:28:15 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Your pupils can expand by as much as 45% when looking at someone you love.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Life Tips\uD83D\uDCA1",
      "screen_name" : "BestProAdvice",
      "indices" : [ "3", "17" ],
      "id_str" : "1305995330",
      "id" : "1305995330"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "770937076997029889",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "770937076997029889",
  "created_at" : "Wed Aug 31 10:51:37 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @BestProAdvice: Even when you have doubts, take that step. Take chances. Mistakes are never a failure—they can be turned into wisdom.\n—…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "lovequotes",
      "indices" : [ "75", "86" ]
    }, {
      "text" : "quotes",
      "indices" : [ "87", "94" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "770935374176784384",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "770935374176784384",
  "created_at" : "Wed Aug 31 10:44:51 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek What is beauty if the brain is empty?? #lovequotes #quotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Quote Soup",
      "screen_name" : "Quote_Soup",
      "indices" : [ "3", "14" ],
      "id_str" : "601227277",
      "id" : "601227277"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "727604260318281728",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "727604260318281728",
  "created_at" : "Tue May 03 21:02:28 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @Quote_Soup: When you lose something, don't think of it as a loss; accept it as the gift that gets you on the path you were meant to tra…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "727602169009082368",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "727602169009082368",
  "created_at" : "Tue May 03 20:54:09 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Only two ways to live life. One is as though nothing is a miracle. The other is as though everything is a miracle. - Albert…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The Google Fact™",
      "screen_name" : "thegooglefact",
      "indices" : [ "3", "17" ],
      "id_str" : "167989418",
      "id" : "167989418"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "132" ],
  "favorite_count" : "0",
  "id_str" : "727601636902879232",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "727601636902879232",
  "created_at" : "Tue May 03 20:52:03 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @thegooglefact: If you tell your friend a secret, expect their boy/girlfriend to know. Even if you tell them not to tell anybody.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "LoveQuotes",
      "indices" : [ "117", "128" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "128" ],
  "favorite_count" : "0",
  "id_str" : "727601251500883969",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "727601251500883969",
  "created_at" : "Tue May 03 20:50:31 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Having a good boyfriend\nis like having a good bra,\nits all about support! Quotes #LoveQuotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "SARCASM!",
      "screen_name" : "FunnySayings",
      "indices" : [ "3", "16" ],
      "id_str" : "337502808",
      "id" : "337502808"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "122" ],
  "favorite_count" : "0",
  "id_str" : "727601107640422401",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "727601107640422401",
  "created_at" : "Tue May 03 20:49:56 +0000 2016",
  "favorited" : false,
  "full_text" : "RT @FunnySayings: and karma said:\nyou will fall in love with someone who doesn't love you, for not loving someone who did.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/q7WarBSrBH",
      "expanded_url" : "http://downloadsave.org/bf1e",
      "display_url" : "downloadsave.org/bf1e",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "719463572649029632",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "719463572649029632",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 11 09:54:17 +0000 2016",
  "favorited" : false,
  "full_text" : "https://t.co/q7WarBSrBH",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "G Facts",
      "screen_name" : "GoogleFacts",
      "indices" : [ "3", "15" ],
      "id_str" : "559675462",
      "id" : "559675462"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "681593961329242112",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "681593961329242112",
  "created_at" : "Mon Dec 28 21:53:58 +0000 2015",
  "favorited" : false,
  "full_text" : "RT @GoogleFacts: When you zone out, small areas of your brain fall asleep.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "681008812174737409",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "681008812174737409",
  "created_at" : "Sun Dec 27 07:08:48 +0000 2015",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Before you can win, you have to believe you are worthy. -Mike Ditka",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14FRIDAYS",
      "indices" : [ "131", "141" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "141" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "527460806972428288",
  "id_str" : "528170236592549888",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "528170236592549888",
  "in_reply_to_status_id" : "527460806972428288",
  "created_at" : "Fri Oct 31 13:02:51 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc  *2 locate all TOTAL service stations around\nu *2 customize ur search&amp;ur needs with\na powerful filters system #14FRIDAYS",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14FRIDAYS",
      "indices" : [ "122", "132" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "132" ],
  "favorite_count" : "0",
  "id_str" : "528168868116590593",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "528168868116590593",
  "created_at" : "Fri Oct 31 12:57:25 +0000 2014",
  "favorited" : false,
  "full_text" : "-To locate all TOTAL service stations around\nyou\n- To customize your search and your needs with\na powerful filters system #14FRIDAYS",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "3", "19" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ {
      "url" : "http://t.co/JKJrGzVZt3",
      "expanded_url" : "http://goo.gl/yY3oSS",
      "display_url" : "goo.gl/yY3oSS",
      "indices" : [ "74", "96" ]
    }, {
      "url" : "http://t.co/Z3VHB5CQ4e",
      "expanded_url" : "http://goo.gl/C6mbLA",
      "display_url" : "goo.gl/C6mbLA",
      "indices" : [ "113", "135" ]
    } ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "528168379937730560",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "528168379937730560",
  "possibly_sensitive" : false,
  "created_at" : "Fri Oct 31 12:55:29 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TOTALNigeriaplc: MENTION 2 BENEFITS OF TOTAL SERVICES APP\nDownload at http://t.co/JKJrGzVZt3 - Android &amp; http://t.co/Z3VHB5CQ4e - IOS h…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "My Feelings ❅",
      "screen_name" : "DamnRealPosts",
      "indices" : [ "3", "17" ],
      "id_str" : "176224244",
      "id" : "176224244"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "466672374025568257",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "466672374025568257",
  "created_at" : "Wed May 14 20:12:19 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @DamnRealPosts: Something about you is so damn addicting.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/sBzsJVO2lc",
      "expanded_url" : "http://dlvr.it/5gJDqK",
      "display_url" : "dlvr.it/5gJDqK",
      "indices" : [ "36", "58" ]
    } ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "466671182398648321",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "466671182398648321",
  "possibly_sensitive" : false,
  "created_at" : "Wed May 14 20:07:34 +0000 2014",
  "favorited" : false,
  "full_text" : "Woman dies praying for Chibok girls http://t.co/sBzsJVO2lc",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "466670778222923778",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "466670778222923778",
  "created_at" : "Wed May 14 20:05:58 +0000 2014",
  "favorited" : false,
  "full_text" : "You never fail until you stop trying.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mana Ionescu",
      "screen_name" : "manamica",
      "indices" : [ "3", "12" ],
      "id_str" : "13520532",
      "id" : "13520532"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "466670755447836673",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "466670755447836673",
  "created_at" : "Wed May 14 20:05:53 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @manamica: \"Whether you think you can or you think you can't, you're right.\" - Henry Ford",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "115" ],
  "favorite_count" : "0",
  "id_str" : "460648240191660032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "460648240191660032",
  "created_at" : "Mon Apr 28 05:14:33 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: When writing an essay, remember this: if it's boring to you, it's twice as boring to your reader.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "121" ],
  "favorite_count" : "0",
  "id_str" : "460644026350587904",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "460644026350587904",
  "created_at" : "Mon Apr 28 04:57:48 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: The greatest glory in living lies not in never falling, but in rising every time we fall. -Nelson Mandela",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "LiISaint",
      "indices" : [ "3", "12" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "123" ],
  "favorite_count" : "0",
  "id_str" : "460643972822863872",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "460643972822863872",
  "created_at" : "Mon Apr 28 04:57:36 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LiISaint: \"Just kidding\" is just an excuse to not get in trouble for something that you really wanted to say all along.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "460643905261023232",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "460643905261023232",
  "created_at" : "Mon Apr 28 04:57:20 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: 8% human DNA is made up of ancient viruses that used to infect us millions of years ago.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "460643830375923712",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "460643830375923712",
  "created_at" : "Mon Apr 28 04:57:02 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: A warrior does not give up what he loves; he finds the love in what he does.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMGFacts",
      "screen_name" : "OMGFacts",
      "indices" : [ "3", "12" ],
      "id_str" : "77888423",
      "id" : "77888423"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/OMGFacts/status/460524239552933890/photo/1",
      "source_status_id" : "460524239552933890",
      "indices" : [ "30", "52" ],
      "url" : "http://t.co/0VepIpEh2x",
      "media_url" : "http://pbs.twimg.com/media/BmQcWumCQAAC6PR.jpg",
      "id_str" : "460524238688894976",
      "source_user_id" : "77888423",
      "id" : "460524238688894976",
      "media_url_https" : "https://pbs.twimg.com/media/BmQcWumCQAAC6PR.jpg",
      "source_user_id_str" : "77888423",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1500",
          "h" : "996",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "797",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "452",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "460524239552933890",
      "display_url" : "pic.twitter.com/0VepIpEh2x"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "460643756560375808",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "460643756560375808",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 28 04:56:44 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @OMGFacts: Alesund, Norway http://t.co/0VepIpEh2x",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/OMGFacts/status/460524239552933890/photo/1",
      "source_status_id" : "460524239552933890",
      "indices" : [ "30", "52" ],
      "url" : "http://t.co/0VepIpEh2x",
      "media_url" : "http://pbs.twimg.com/media/BmQcWumCQAAC6PR.jpg",
      "id_str" : "460524238688894976",
      "source_user_id" : "77888423",
      "id" : "460524238688894976",
      "media_url_https" : "https://pbs.twimg.com/media/BmQcWumCQAAC6PR.jpg",
      "source_user_id_str" : "77888423",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1500",
          "h" : "996",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "797",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "452",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "460524239552933890",
      "display_url" : "pic.twitter.com/0VepIpEh2x"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "460643506839883777",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "460643506839883777",
  "created_at" : "Mon Apr 28 04:55:45 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Smile, even if it's fake. Laugh, even if you hurt. Don't let anyone get to you, you're beautiful regardless of what anyone …",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "id_str" : "460099705008304128",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "460099705008304128",
  "created_at" : "Sat Apr 26 16:54:52 +0000 2014",
  "favorited" : false,
  "full_text" : "Abstain from sin and ask God anything...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/TxBKzCfIRD",
      "expanded_url" : "http://bit.ly/1jArpPR",
      "display_url" : "bit.ly/1jArpPR",
      "indices" : [ "17", "39" ]
    } ]
  },
  "display_text_range" : [ "0", "39" ],
  "favorite_count" : "0",
  "id_str" : "458960728981262336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458960728981262336",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:28:59 +0000 2014",
  "favorited" : false,
  "full_text" : "Test Publication http://t.co/TxBKzCfIRD",
  "lang" : "fr"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/3vBAieYfJK",
      "expanded_url" : "http://bit.ly/1jM9pDt",
      "display_url" : "bit.ly/1jM9pDt",
      "indices" : [ "87", "109" ]
    } ]
  },
  "display_text_range" : [ "0", "109" ],
  "favorite_count" : "0",
  "id_str" : "458960611939196928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458960611939196928",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:28:31 +0000 2014",
  "favorited" : false,
  "full_text" : "Paul PSquare finally comes out to talk about split with his brother, See what he said! http://t.co/3vBAieYfJK",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/wZLheXPtWx",
      "expanded_url" : "http://bit.ly/1jM7UVz",
      "display_url" : "bit.ly/1jM7UVz",
      "indices" : [ "77", "99" ]
    } ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "458959931669221376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458959931669221376",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:25:49 +0000 2014",
  "favorited" : false,
  "full_text" : "JUST IN: ‘Object Of Interest’ Found In Search For Missing Malaysian Aircraft http://t.co/wZLheXPtWx",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/VPUFAvZygZ",
      "expanded_url" : "http://bit.ly/1myv8Ep",
      "display_url" : "bit.ly/1myv8Ep",
      "indices" : [ "66", "88" ]
    } ]
  },
  "display_text_range" : [ "0", "88" ],
  "favorite_count" : "0",
  "id_str" : "436932719852142592",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436932719852142592",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:37:32 +0000 2014",
  "favorited" : false,
  "full_text" : "PHOTOS: SEE What Nigerian Gays &amp; L£sbians Are Doing In London http://t.co/VPUFAvZygZ",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/Q7cdQQFU6X",
      "expanded_url" : "http://bit.ly/1myv7AC",
      "display_url" : "bit.ly/1myv7AC",
      "indices" : [ "85", "107" ]
    } ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "436932650172162048",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436932650172162048",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:37:16 +0000 2014",
  "favorited" : false,
  "full_text" : "Popular Nigerian BLASTS Omotola Jalade, SEE What Happened + What Omotola Did! (LOOK) http://t.co/Q7cdQQFU6X",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/hJ0ycB5rQH",
      "expanded_url" : "http://bit.ly/1dZl3uE",
      "display_url" : "bit.ly/1dZl3uE",
      "indices" : [ "71", "93" ]
    } ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "0",
  "id_str" : "436932596619304960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436932596619304960",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:37:03 +0000 2014",
  "favorited" : false,
  "full_text" : "Beautiful Ladies Show Off B00BS To Raise Money For Cancer (SEE PHOTOS) http://t.co/hJ0ycB5rQH",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/Li51gTjQjh",
      "expanded_url" : "http://bit.ly/1bSkPH9",
      "display_url" : "bit.ly/1bSkPH9",
      "indices" : [ "68", "90" ]
    } ]
  },
  "display_text_range" : [ "0", "90" ],
  "favorite_count" : "0",
  "id_str" : "436932517921570816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436932517921570816",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:36:44 +0000 2014",
  "favorited" : false,
  "full_text" : "PHOTOS: Eddie Murphy's HOT Daughter Goes Fully Nak£d Again!! (LOOK) http://t.co/Li51gTjQjh",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/MKMLw11rWN",
      "expanded_url" : "http://bit.ly/1dZkEIS",
      "display_url" : "bit.ly/1dZkEIS",
      "indices" : [ "41", "63" ]
    } ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "436932217399701506",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436932217399701506",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:35:33 +0000 2014",
  "favorited" : false,
  "full_text" : "10 Things All Women Secretly Want In Bed http://t.co/MKMLw11rWN",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/mTNK2g6xS7",
      "expanded_url" : "http://bit.ly/1dZkpgU",
      "display_url" : "bit.ly/1dZkpgU",
      "indices" : [ "29", "51" ]
    } ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "0",
  "id_str" : "436931845180370944",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436931845180370944",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:34:04 +0000 2014",
  "favorited" : false,
  "full_text" : "5 Things A Player Never Says http://t.co/mTNK2g6xS7",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Important",
      "indices" : [ "0", "10" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/bHgfFHc8VR",
      "expanded_url" : "http://bit.ly/1myuLK0",
      "display_url" : "bit.ly/1myuLK0",
      "indices" : [ "59", "81" ]
    } ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "436931758492487680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436931758492487680",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:33:43 +0000 2014",
  "favorited" : false,
  "full_text" : "#Important: What Your Blood Pressure Says About You (READ) http://t.co/bHgfFHc8VR",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/btrxeO754w",
      "expanded_url" : "http://bit.ly/MIUSy4",
      "display_url" : "bit.ly/MIUSy4",
      "indices" : [ "90", "112" ]
    } ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "436931608265113600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436931608265113600",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:33:07 +0000 2014",
  "favorited" : false,
  "full_text" : "Cassava Bread To Generate Over N240 Billion For Farmers Annually – Agric Minister Adesina http://t.co/btrxeO754w",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/hHSZkQU18C",
      "expanded_url" : "http://bit.ly/MIUL5o",
      "display_url" : "bit.ly/MIUL5o",
      "indices" : [ "31", "53" ]
    } ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "436931487221678080",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436931487221678080",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:32:39 +0000 2014",
  "favorited" : false,
  "full_text" : "7 Most Outrageous Breakup Note http://t.co/hHSZkQU18C",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "102" ],
  "favorite_count" : "0",
  "id_str" : "436931315259424768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436931315259424768",
  "created_at" : "Fri Feb 21 18:31:58 +0000 2014",
  "favorited" : false,
  "full_text" : "Dear Past, thank you for your lessons. Dear Future, I'm ready. Dear God, thank you for another chance.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/5w9IqAPqP4",
      "expanded_url" : "http://vanguardngr.com/",
      "display_url" : "vanguardngr.com",
      "indices" : [ "0", "22" ]
    }, {
      "url" : "http://t.co/xsOe6ss57r",
      "expanded_url" : "http://bit.ly/1dZjJIm",
      "display_url" : "bit.ly/1dZjJIm",
      "indices" : [ "76", "98" ]
    } ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "id_str" : "436931085663223808",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436931085663223808",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:31:03 +0000 2014",
  "favorited" : false,
  "full_text" : "http://t.co/5w9IqAPqP4 --- Prostitution, abortions on the increase in Lagos http://t.co/xsOe6ss57r",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "436930865877504000",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436930865877504000",
  "created_at" : "Fri Feb 21 18:30:10 +0000 2014",
  "favorited" : false,
  "full_text" : "You can never \"just be friends\" with someone you fell in love with.........",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/uZMztKpEQG",
      "expanded_url" : "http://bit.ly/1l5MO8K",
      "display_url" : "bit.ly/1l5MO8K",
      "indices" : [ "44", "66" ]
    } ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "0",
  "id_str" : "436907658541813760",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436907658541813760",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 16:57:57 +0000 2014",
  "favorited" : false,
  "full_text" : "Guys, 3 Ways To Be Sure She TRULY Wants You http://t.co/uZMztKpEQG",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/esL0zoL9y6",
      "expanded_url" : "http://bit.ly/1l5MM0R",
      "display_url" : "bit.ly/1l5MM0R",
      "indices" : [ "74", "96" ]
    } ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "436907554372071424",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436907554372071424",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 16:57:32 +0000 2014",
  "favorited" : false,
  "full_text" : "SEE The Popular Record Label Skales Signed With After Being Dumped By EME http://t.co/esL0zoL9y6",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/LsRX8dfzzW",
      "expanded_url" : "http://bit.ly/1jV5HLt",
      "display_url" : "bit.ly/1jV5HLt",
      "indices" : [ "68", "90" ]
    } ]
  },
  "display_text_range" : [ "0", "90" ],
  "favorite_count" : "0",
  "id_str" : "436907484994105346",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436907484994105346",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 16:57:16 +0000 2014",
  "favorited" : false,
  "full_text" : "Goodnews For Funke Akindele, SEE What Just Happened To Her!! (LOOK) http://t.co/LsRX8dfzzW",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "133" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436888644406620162",
  "id_str" : "436891227561414656",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436891227561414656",
  "in_reply_to_status_id" : "436888644406620162",
  "created_at" : "Fri Feb 21 15:52:40 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 3. Continuous concern for safety and environmental protection 4.Contributions to the development of host communities",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14daysofawango",
      "indices" : [ "59", "74" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436888644406620162",
  "id_str" : "436890026593751040",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436890026593751040",
  "in_reply_to_status_id" : "436888644406620162",
  "created_at" : "Fri Feb 21 15:47:54 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 1.Professionalism\n2.Respect for employees #14daysofawango",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14daysofawango",
      "indices" : [ "0", "15" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "id_str" : "436887083400302592",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436887083400302592",
  "created_at" : "Fri Feb 21 15:36:12 +0000 2014",
  "favorited" : false,
  "full_text" : "#14daysofawango day9 is sh*t! How can u say there's no winner on twitter when I obviously got d ans? u guys should do smt@@TOTALNigeriaplc",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "GodDey",
      "indices" : [ "132", "139" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "436877155579203585",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436877155579203585",
  "created_at" : "Fri Feb 21 14:56:45 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc day9 quiz is full of sh*t!I posted more than 5 possible ans on twitter which I got 3 4rm, yt u claim dt no 1 wins! #GodDey",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "41" ],
  "favorite_count" : "0",
  "id_str" : "436872959807205376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436872959807205376",
  "created_at" : "Fri Feb 21 14:40:04 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: occupation: princess",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "128" ],
  "favorite_count" : "0",
  "id_str" : "436872905625174016",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436872905625174016",
  "created_at" : "Fri Feb 21 14:39:52 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Due to the new discovery of many brain parasites, Scientist say that a Zombie Apocalypse is actually possible.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "436872850407190528",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436872850407190528",
  "created_at" : "Fri Feb 21 14:39:39 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Hello how are you? [Fine] Hey, I didn't ask you how you looked!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "34", "40" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "436872772275691520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436872772275691520",
  "created_at" : "Fri Feb 21 14:39:20 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: Haters hating on #Virgo cause they come to close to perfection.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Fitness Motivation",
      "screen_name" : "Stayin_Fit",
      "indices" : [ "3", "14" ],
      "id_str" : "1578718718",
      "id" : "1578718718"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "436872629895852032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436872629895852032",
  "created_at" : "Fri Feb 21 14:38:46 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Stayin_Fit: To keep going just make a 45 minute long playlist and don't stop until it's done.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "mufc",
      "indices" : [ "12", "17" ]
    }, {
      "text" : "mutour",
      "indices" : [ "125", "132" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ "3", "10" ],
      "id_str" : "558797310",
      "id" : "558797310"
    } ],
    "urls" : [ {
      "url" : "http://t.co/lfN5fpm00l",
      "expanded_url" : "http://bit.ly/OeZz3E",
      "display_url" : "bit.ly/OeZz3E",
      "indices" : [ "102", "124" ]
    } ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "436749804912517120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436749804912517120",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 06:30:42 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @ManUtd: #mufc will play AS Roma &amp; Inter Milan in the International Champions Cup this summer. http://t.co/lfN5fpm00l #mutour http://t.c…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "436748498172903424",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436748498172903424",
  "created_at" : "Fri Feb 21 06:25:31 +0000 2014",
  "favorited" : false,
  "full_text" : "It doesn't matter who hurt you, or broke you down, what matters is who made you smile again.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "30" ],
  "favorite_count" : "0",
  "id_str" : "436748435832975360",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436748435832975360",
  "created_at" : "Fri Feb 21 06:25:16 +0000 2014",
  "favorited" : false,
  "full_text" : "Stay faithful or remain single",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/MLV1CHwpqI",
      "expanded_url" : "http://bit.ly/1dVgq4P",
      "display_url" : "bit.ly/1dVgq4P",
      "indices" : [ "26", "48" ]
    } ]
  },
  "display_text_range" : [ "0", "48" ],
  "favorite_count" : "0",
  "id_str" : "436748138108686336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436748138108686336",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 06:24:05 +0000 2014",
  "favorited" : false,
  "full_text" : "16 Signs You May Have HIV http://t.co/MLV1CHwpqI",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/arqYfEBmXO",
      "expanded_url" : "http://bit.ly/1brxGPR",
      "display_url" : "bit.ly/1brxGPR",
      "indices" : [ "109", "131" ]
    } ]
  },
  "display_text_range" : [ "0", "131" ],
  "favorite_count" : "0",
  "id_str" : "436748091153461248",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436748091153461248",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 06:23:53 +0000 2014",
  "favorited" : false,
  "full_text" : "How ‘Penniless Ethiopian Prostitute’ Posed As A Saudi Princess, Swindled Londoners Of £14 Million (PICTURED) http://t.co/arqYfEBmXO",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "SpeakComedy",
      "screen_name" : "SpeakComedy",
      "indices" : [ "3", "15" ],
      "id_str" : "50618718",
      "id" : "50618718"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "436747905136087040",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747905136087040",
  "created_at" : "Fri Feb 21 06:23:09 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @SpeakComedy: Stay up late, regret it in the morning, repeat.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "SpeakComedy",
      "screen_name" : "SpeakComedy",
      "indices" : [ "3", "15" ],
      "id_str" : "50618718",
      "id" : "50618718"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "89" ],
  "favorite_count" : "0",
  "id_str" : "436747861456596992",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747861456596992",
  "created_at" : "Fri Feb 21 06:22:59 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @SpeakComedy: im pretty sure by now “tired” is just part of my personality description",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "SpeakComedy",
      "screen_name" : "SpeakComedy",
      "indices" : [ "3", "15" ],
      "id_str" : "50618718",
      "id" : "50618718"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "436747825079414784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747825079414784",
  "created_at" : "Fri Feb 21 06:22:50 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @SpeakComedy: I say \"i don't know\" to everything when I'm in a bad mood.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "spread",
      "indices" : [ "50", "57" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "76" ],
  "favorite_count" : "0",
  "id_str" : "436747754522832897",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747754522832897",
  "created_at" : "Fri Feb 21 06:22:33 +0000 2014",
  "favorited" : false,
  "full_text" : "Sex with someone who doesn't wants u is RAPE......#spread d word not d virus",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "436747640051863552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747640051863552",
  "created_at" : "Fri Feb 21 06:22:06 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: I’m like a tropical island: hot, wet, and waiting for tourists.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ "91", "98" ]
    }, {
      "text" : "lovequotes",
      "indices" : [ "99", "110" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "id_str" : "436747569927290881",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747569927290881",
  "created_at" : "Fri Feb 21 06:21:49 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek You can turn off the sun, but I`m still gonna shine... #quotes #lovequotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "436747541674475520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747541674475520",
  "created_at" : "Fri Feb 21 06:21:42 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: In life you are either a passenger or a pilot, it's your choice.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "130" ],
  "favorite_count" : "0",
  "id_str" : "436747420949823488",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747420949823488",
  "created_at" : "Fri Feb 21 06:21:14 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Go ahead, say it. You want to run away from everything. But know one thing: you can't run away from yourself.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "68" ],
  "favorite_count" : "0",
  "id_str" : "436747126618738688",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436747126618738688",
  "created_at" : "Fri Feb 21 06:20:04 +0000 2014",
  "favorited" : false,
  "full_text" : "I can't control my feelings.....buh I hate how my feelins control me",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14daysofawango",
      "indices" : [ "34", "49" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "49" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436551844849258496",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436551844849258496",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 17:24:05 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 5. use seat belt #14daysofawango",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14daysofawango",
      "indices" : [ "95", "110" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436551591509106688",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436551591509106688",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 17:23:04 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 2. maintain your vehicle properly and\nregularly and also check the oil level. #14daysofawango",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14daysofAwango",
      "indices" : [ "49", "64" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "3", "19" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "436551484080410624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436551484080410624",
  "created_at" : "Thu Feb 20 17:22:39 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TOTALNigeriaplc: Dear customers Day 9 of the #14daysofAwango giveaways contest has commenced, reply this tweet with your answer http://…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "436548665835266048",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436548665835266048",
  "created_at" : "Thu Feb 20 17:11:27 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Stop wearing your wishbone where your backbone ought to be.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "33" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436548494539902977",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436548494539902977",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 17:10:46 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 5. use seat belt",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436548323106099200",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436548323106099200",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 17:10:05 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 4. dO not over use air conditioning.",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436548186585726976",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436548186585726976",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 17:09:33 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 3. remove any unnecessary loads from your vehicle.",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436547789141839872",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436547789141839872",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 17:07:58 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 2. maintain your vehicle properly and regularly and also check the oil\nlevel.",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "129" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436547629242413056",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436547629242413056",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 17:07:20 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 1. check your tyre pressure once a month.because under inflated tyres\ncan increase fuel consumption by up to 4%.",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/KilClKTfsy",
      "expanded_url" : "http://bit.ly/1fk80Em",
      "display_url" : "bit.ly/1fk80Em",
      "indices" : [ "86", "108" ]
    } ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "436540768027947009",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436540768027947009",
  "possibly_sensitive" : false,
  "created_at" : "Thu Feb 20 16:40:04 +0000 2014",
  "favorited" : false,
  "full_text" : "Fashola Bans Wearing Of Mini-Skirts, Other ‘Indecent’ Attires For Lagos Gov’t Workers http://t.co/KilClKTfsy",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "17", "23" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "436540099967602688",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436540099967602688",
  "created_at" : "Thu Feb 20 16:37:25 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: #Virgo will never forget who matters to them and who do not.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14DaysofAwango",
      "indices" : [ "113", "128" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "128" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436538285943689216",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436538285943689216",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 16:30:12 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc Drive as soon as you started your engine and turn it off when you park\nfor more than a minute.. #14DaysofAwango",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "143" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436537849148878848",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436537849148878848",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 16:28:28 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc Dont use the Air Conditioning excessively. Unnecessary use can\nincrease fuel consumption&amp;give more CO[carbon(II)oxide] off",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "132" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436536297755533312",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436536297755533312",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 16:22:18 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc 1. Checking the oil level regularly enables to save fuel. 2. Drive at\nreasonable speed and avoid aggressive driving",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14daysOfAwango",
      "indices" : [ "77", "92" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436531051918532608",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436531051918532608",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 16:01:27 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc Check your oil level every 2000 km or before a long journey #14daysOfAwango",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14daysofAwongo",
      "indices" : [ "83", "98" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "436515141228560384",
  "id_str" : "436528718509793280",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436528718509793280",
  "in_reply_to_status_id" : "436515141228560384",
  "created_at" : "Thu Feb 20 15:52:11 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc Engine 0il : Be sure to use the right specification of engine oil #14daysofAwongo",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/FnmPwG8dku",
      "expanded_url" : "http://thetrentonline.com/3-steps-stop-busy-start-productive/?utm_source=rss&utm_medium=rss&utm_campaign=3-steps-stop-busy-start-productive",
      "display_url" : "thetrentonline.com/3-steps-stop-b…",
      "indices" : [ "54", "76" ]
    } ]
  },
  "display_text_range" : [ "0", "76" ],
  "favorite_count" : "0",
  "id_str" : "436449311157923840",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436449311157923840",
  "possibly_sensitive" : false,
  "created_at" : "Thu Feb 20 10:36:39 +0000 2014",
  "favorited" : false,
  "full_text" : "3 Steps To Stop Being Busy And Start Being Productive http://t.co/FnmPwG8dku",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/X2dEe6ti9E",
      "expanded_url" : "http://thetrentonline.com/fast-furious-actress-michelle-rodriguez-cara-delevingne-confirm-lesbian-relationship-photos-2/?utm_source=rss&utm_medium=rss&utm_campaign=fast-furious-actress-michelle-rodriguez-cara-delevingne-confirm-lesbian-relationship-photos-2",
      "display_url" : "thetrentonline.com/fast-furious-a…",
      "indices" : [ "108", "130" ]
    } ]
  },
  "display_text_range" : [ "0", "130" ],
  "favorite_count" : "0",
  "id_str" : "436449214022041600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436449214022041600",
  "possibly_sensitive" : false,
  "created_at" : "Thu Feb 20 10:36:16 +0000 2014",
  "favorited" : false,
  "full_text" : "Fast And Furious Actress Michelle Rodriguez And Cara Delevingne Confirm Their Lesbian Relationship (PHOTOS) http://t.co/X2dEe6ti9E",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/05lqgnhcYX",
      "expanded_url" : "http://thetrentonline.com/depressed-man-tries-feed-self-tigers-reject-pictured/?utm_source=rss&utm_medium=rss&utm_campaign=depressed-man-tries-feed-self-tigers-reject-pictured",
      "display_url" : "thetrentonline.com/depressed-man-…",
      "indices" : [ "75", "97" ]
    } ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "436449152277700608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436449152277700608",
  "possibly_sensitive" : false,
  "created_at" : "Thu Feb 20 10:36:01 +0000 2014",
  "favorited" : false,
  "full_text" : "Depressed Man Tries To Feed Self To Tigers, But They Reject Him (Pictured) http://t.co/05lqgnhcYX",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/51WFx788Au",
      "expanded_url" : "http://thetrentonline.com/woman-catches-robber-ties-rapes-3-days-feeds-viagra-pictured/?utm_source=rss&utm_medium=rss&utm_campaign=woman-catches-robber-ties-rapes-3-days-feeds-viagra-pictured",
      "display_url" : "thetrentonline.com/woman-catches-…",
      "indices" : [ "85", "107" ]
    } ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "436448962154086400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436448962154086400",
  "possibly_sensitive" : false,
  "created_at" : "Thu Feb 20 10:35:16 +0000 2014",
  "favorited" : false,
  "full_text" : "Woman Catches Robber, Ties Him Up, Rapes Him For 3-Days, Feeds Him Viagra (PICTURED) http://t.co/51WFx788Au",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "436448808437051393",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436448808437051393",
  "created_at" : "Thu Feb 20 10:34:39 +0000 2014",
  "favorited" : false,
  "full_text" : "All, everything that I understand, I understand only because I love. - Leo Tolstoy",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "25" ],
  "favorite_count" : "0",
  "id_str" : "436448508712058880",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436448508712058880",
  "created_at" : "Thu Feb 20 10:33:27 +0000 2014",
  "favorited" : false,
  "full_text" : "I don't belief in failure",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "29" ],
  "favorite_count" : "0",
  "id_str" : "436447643347456000",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436447643347456000",
  "created_at" : "Thu Feb 20 10:30:01 +0000 2014",
  "favorited" : false,
  "full_text" : "always take a thoughtful step",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "436447423066800128",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436447423066800128",
  "created_at" : "Thu Feb 20 10:29:09 +0000 2014",
  "favorited" : false,
  "full_text" : "Dey say am black,buh dat one day lyk 24HRS,u claim she's ur gal,buh I guess she's OURS,ur album no sweet,jux SOUR,I go bake u witout FLOURS",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/4bArwVfBVI",
      "expanded_url" : "http://bit.ly/1gJLsgt",
      "display_url" : "bit.ly/1gJLsgt",
      "indices" : [ "40", "62" ]
    } ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "0",
  "id_str" : "436446886447562752",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436446886447562752",
  "possibly_sensitive" : false,
  "created_at" : "Thu Feb 20 10:27:01 +0000 2014",
  "favorited" : false,
  "full_text" : "Uche Jombo Shares Her No Makeup Picture http://t.co/4bArwVfBVI",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "49" ],
  "favorite_count" : "0",
  "id_str" : "436446775298498560",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436446775298498560",
  "created_at" : "Thu Feb 20 10:26:34 +0000 2014",
  "favorited" : false,
  "full_text" : "u cn't buy luv because wen its real,its priceless",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/lb4lamdgb9",
      "expanded_url" : "http://bit.ly/1gJL165",
      "display_url" : "bit.ly/1gJL165",
      "indices" : [ "25", "47" ]
    } ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "436446481458167809",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436446481458167809",
  "possibly_sensitive" : false,
  "created_at" : "Thu Feb 20 10:25:24 +0000 2014",
  "favorited" : false,
  "full_text" : "Give This Dog A Title... http://t.co/lb4lamdgb9",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "436445232629288960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436445232629288960",
  "created_at" : "Thu Feb 20 10:20:26 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: I have an X in my equation that U can replace.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "136" ],
  "favorite_count" : "0",
  "id_str" : "436445180531855360",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436445180531855360",
  "created_at" : "Thu Feb 20 10:20:14 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Giving up doesn't always mean you're weak, sometimes it means you are strong and smart enough to let go and move on.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "lovequotes",
      "indices" : [ "124", "135" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "436444846484881408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436444846484881408",
  "created_at" : "Thu Feb 20 10:18:54 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek It's better to live your own life imperfectly than to imitate someone else's perfectly. #lovequotes #qu…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "436379952939008000",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436379952939008000",
  "created_at" : "Thu Feb 20 06:01:02 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: It’s impossible to spell “pick up” without “u.”",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14DaysOfAwango",
      "indices" : [ "32", "47" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "436172198764896256",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436172198764896256",
  "created_at" : "Wed Feb 19 16:15:30 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc RED and YELLOW #14DaysOfAwango",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "14DaysOfAwango",
      "indices" : [ "15", "30" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "30" ],
  "favorite_count" : "0",
  "id_str" : "436171853447839745",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436171853447839745",
  "created_at" : "Wed Feb 19 16:14:08 +0000 2014",
  "favorited" : false,
  "full_text" : "RED and YELLOW #14DaysOfAwango",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "436111009976438784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436111009976438784",
  "created_at" : "Wed Feb 19 12:12:21 +0000 2014",
  "favorited" : false,
  "full_text" : "The greater the effort, the greater the glory. Pierre Corneille",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "35" ],
  "favorite_count" : "0",
  "id_str" : "436109001332641793",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436109001332641793",
  "created_at" : "Wed Feb 19 12:04:23 +0000 2014",
  "favorited" : false,
  "full_text" : "Life: Cherish it, love it, live it.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "118" ],
  "favorite_count" : "0",
  "id_str" : "436079731784830976",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436079731784830976",
  "created_at" : "Wed Feb 19 10:08:04 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: It does not matter how many times you get knocked down, but how many times you get up. -Vince Lombardi",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "411VibesDotCom",
      "indices" : [ "118", "133" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "#TheInfoNG",
      "screen_name" : "411Vibes",
      "indices" : [ "3", "12" ],
      "id_str" : "2951641768",
      "id" : "2951641768"
    } ],
    "urls" : [ {
      "url" : "http://t.co/c7SssyxvT7",
      "expanded_url" : "http://bit.ly/1bk5caM",
      "display_url" : "bit.ly/1bk5caM",
      "indices" : [ "95", "117" ]
    } ]
  },
  "display_text_range" : [ "0", "133" ],
  "favorite_count" : "0",
  "id_str" : "436078269646270464",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436078269646270464",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 19 10:02:16 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @411Vibes: DANG!!! Girl Eats Only Chicken For 15 Years, Guess What Happens To Her. MUST SEE http://t.co/c7SssyxvT7 #411VibesDotCom",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "436075479934971904",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436075479934971904",
  "created_at" : "Wed Feb 19 09:51:10 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Make memories you'll look back and smile at.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "137" ],
  "favorite_count" : "0",
  "id_str" : "436075447882100736",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436075447882100736",
  "created_at" : "Wed Feb 19 09:51:03 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: No one can choose your mountain or tell you when to climb. It's yours alone to challenge. At your own pace and time.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mana Ionescu",
      "screen_name" : "manamica",
      "indices" : [ "3", "12" ],
      "id_str" : "13520532",
      "id" : "13520532"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "436075405523845120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436075405523845120",
  "created_at" : "Wed Feb 19 09:50:53 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @manamica: \"You usually can't tell what's inspiring until you look back on it.\" - Carly Simon",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "436075373886181377",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436075373886181377",
  "created_at" : "Wed Feb 19 09:50:45 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: You look so familiar… didn't we take a class together? I could've sworn we had chemistry.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wadup NG",
      "screen_name" : "Waduponline",
      "indices" : [ "3", "15" ],
      "id_str" : "619843957",
      "id" : "619843957"
    } ],
    "urls" : [ {
      "url" : "http://t.co/DZDqEr6WLU",
      "expanded_url" : "http://dlvr.it/4ygwBf",
      "display_url" : "dlvr.it/4ygwBf",
      "indices" : [ "70", "92" ]
    } ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "436075099503198208",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436075099503198208",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 19 09:49:40 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @waduponline: Read Pastor E. A Adeboye’s message to skin bleachers http://t.co/DZDqEr6WLU",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ {
      "url" : "http://t.co/yBgMtVs2c4",
      "expanded_url" : "http://pic-viewimage.com/1a2aKDF",
      "display_url" : "pic-viewimage.com/1a2aKDF",
      "indices" : [ "51", "73" ]
    } ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "436074998567284736",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436074998567284736",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 19 09:49:16 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: Yoga improves your sex life \uD83D\uDE09 http://t.co/yBgMtVs2c4",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "436074825279614977",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436074825279614977",
  "created_at" : "Wed Feb 19 09:48:34 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Women are influenced by how a man smells.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "148" ],
  "favorite_count" : "0",
  "id_str" : "436074641971773440",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436074641971773440",
  "created_at" : "Wed Feb 19 09:47:51 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Look at your problems as problems &amp; they'll continue to hold you down. See them as blessings in disguise &amp; that's what they…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "76" ],
  "favorite_count" : "0",
  "id_str" : "435892917941841920",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435892917941841920",
  "created_at" : "Tue Feb 18 21:45:44 +0000 2014",
  "favorited" : false,
  "full_text" : "Sooner or later, those who win are those who think they can. - Paul Tournier",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "435891951200899072",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435891951200899072",
  "created_at" : "Tue Feb 18 21:41:54 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Talking to your mother has the same effect on stress as getting a hug.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Kabs_Cebekhulu",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "id_str" : "435889211997446144",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435889211997446144",
  "created_at" : "Tue Feb 18 21:31:01 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Kabs_Cebekhulu: I Loooove My Flaws..",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Kabs_Cebekhulu",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "435888723532984320",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435888723532984320",
  "created_at" : "Tue Feb 18 21:29:04 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Kabs_Cebekhulu: They Gon' Love You a Little Different When you Are At The Top!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Nah",
      "screen_name" : "Sodamniove",
      "indices" : [ "3", "14" ],
      "id_str" : "2356448440",
      "id" : "2356448440"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "435885789025931265",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435885789025931265",
  "created_at" : "Tue Feb 18 21:17:25 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @sodamnIove: I really like being around you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "zlatan",
      "indices" : [ "0", "7" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "7" ],
  "favorite_count" : "0",
  "id_str" : "435885552127447041",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435885552127447041",
  "created_at" : "Tue Feb 18 21:16:28 +0000 2014",
  "favorited" : false,
  "full_text" : "#zlatan",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "24", "30" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "435882698977337344",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435882698977337344",
  "created_at" : "Tue Feb 18 21:05:08 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: I am a #Virgo because I will always persevere, sacrificing my heart for only those I hold dear.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "435882493305446400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435882493305446400",
  "created_at" : "Tue Feb 18 21:04:19 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: We were given 2 hands to hold. 2 eyes to see But why only one heart? Because the other was given to someone else. For u…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Supreme Master TV",
      "screen_name" : "SupremeMasterTV",
      "indices" : [ "3", "19" ],
      "id_str" : "26778990",
      "id" : "26778990"
    } ],
    "urls" : [ {
      "url" : "http://t.co/bTIyRVuBDs",
      "expanded_url" : "http://on.fb.me/O5HmFJ",
      "display_url" : "on.fb.me/O5HmFJ",
      "indices" : [ "84", "106" ]
    } ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "435881878915416064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435881878915416064",
  "possibly_sensitive" : false,
  "created_at" : "Tue Feb 18 21:01:52 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @SupremeMasterTV: Bravo to Vegan Olympian Alexey Voyevoda for winning the gold! \nhttp://t.co/bTIyRVuBDs",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AwkwardPosts",
      "screen_name" : "awkwardposts",
      "indices" : [ "3", "16" ],
      "id_str" : "745493354956259328",
      "id" : "745493354956259328"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "435881853091065857",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435881853091065857",
  "created_at" : "Tue Feb 18 21:01:46 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @awkwardposts: The amount of people i would marry without a seconds hesitation is quite worrying",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AwkwardPosts",
      "screen_name" : "awkwardposts",
      "indices" : [ "3", "16" ],
      "id_str" : "745493354956259328",
      "id" : "745493354956259328"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "435881770010279936",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435881770010279936",
  "created_at" : "Tue Feb 18 21:01:26 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @awkwardposts: Can i sell my feelings on ebay i don’t want them anymore",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "101" ],
  "favorite_count" : "0",
  "id_str" : "435881518616297472",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435881518616297472",
  "created_at" : "Tue Feb 18 21:00:26 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: The greatest weapon against stress is our ability to choose one thought over another.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "39" ],
  "favorite_count" : "0",
  "id_str" : "435879967348764672",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435879967348764672",
  "created_at" : "Tue Feb 18 20:54:17 +0000 2014",
  "favorited" : false,
  "full_text" : "Life is cheap, it only take one bullet.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "435826541831131136",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435826541831131136",
  "created_at" : "Tue Feb 18 17:21:59 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Don't be pushed around by your problems. Be led by your dreams.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ֆђϊναα",
      "screen_name" : "shivaashivaa61",
      "indices" : [ "3", "18" ],
      "id_str" : "3007864190",
      "id" : "3007864190"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "435759034030112768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435759034030112768",
  "created_at" : "Tue Feb 18 12:53:44 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @shivaashivaa61: those who tweet love quotes 90% of them are single :p",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "•16 days•",
      "screen_name" : "masquerader_",
      "indices" : [ "3", "16" ],
      "id_str" : "4320405856",
      "id" : "4320405856"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "435758951045820416",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435758951045820416",
  "created_at" : "Tue Feb 18 12:53:24 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Masquerader_: Over thinking leads to Over thinking",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "CharlesBukkake1",
      "indices" : [ "3", "19" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "435758836038008832",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435758836038008832",
  "created_at" : "Tue Feb 18 12:52:57 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @CharlesBukkake1: I'll be bad and unprepared when I'm good and ready.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "21" ],
  "favorite_count" : "0",
  "id_str" : "435723281719914497",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435723281719914497",
  "created_at" : "Tue Feb 18 10:31:40 +0000 2014",
  "favorited" : false,
  "full_text" : "Nothing is impossible",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "435645182948962304",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435645182948962304",
  "created_at" : "Tue Feb 18 05:21:20 +0000 2014",
  "favorited" : false,
  "full_text" : "The reason why everyone wants love so much is because it's the closest thing to magic.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mana Ionescu",
      "screen_name" : "manamica",
      "indices" : [ "3", "12" ],
      "id_str" : "13520532",
      "id" : "13520532"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "435645091508924416",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435645091508924416",
  "created_at" : "Tue Feb 18 05:20:58 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @manamica: \"I want to be inspiring to myself, to my kids, my family, and my friends.\" - Jodie Foster",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "0",
  "id_str" : "435554062873149440",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435554062873149440",
  "created_at" : "Mon Feb 17 23:19:15 +0000 2014",
  "favorited" : false,
  "full_text" : "When will you realise how much i fucking care about you?",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "85" ],
  "favorite_count" : "0",
  "id_str" : "435356716323307520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435356716323307520",
  "created_at" : "Mon Feb 17 10:15:04 +0000 2014",
  "favorited" : false,
  "full_text" : "People too weak to follow their own dreams will always find a way to discourage yours",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "435280629971058688",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435280629971058688",
  "created_at" : "Mon Feb 17 05:12:43 +0000 2014",
  "favorited" : false,
  "full_text" : "Nothing you wear is more important than your smile. -Connie Stevens",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "id_str" : "435274413949599744",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435274413949599744",
  "created_at" : "Mon Feb 17 04:48:01 +0000 2014",
  "favorited" : false,
  "full_text" : "Dont believ rumors, only believe what you see.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "435274128757899264",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435274128757899264",
  "created_at" : "Mon Feb 17 04:46:53 +0000 2014",
  "favorited" : false,
  "full_text" : "Dont believe rumors, only believe what you see.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "princess",
      "screen_name" : "sayingsforgirls",
      "indices" : [ "3", "19" ],
      "id_str" : "256986185",
      "id" : "256986185"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "435172041818640384",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435172041818640384",
  "created_at" : "Sun Feb 16 22:01:14 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @SayingsForGirls: No matter how great you are, not everybody will like you. That’s life.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "0",
  "id_str" : "435171928958312448",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435171928958312448",
  "created_at" : "Sun Feb 16 22:00:47 +0000 2014",
  "favorited" : false,
  "full_text" : "Don't rush things. Anything worth having is worth waiting for.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "id_str" : "435161461154152448",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435161461154152448",
  "created_at" : "Sun Feb 16 21:19:11 +0000 2014",
  "favorited" : false,
  "full_text" : "Stay positive, tomorrow will be amazing.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lets Be Real",
      "screen_name" : "iadorewomen_",
      "indices" : [ "3", "16" ],
      "id_str" : "169719009",
      "id" : "169719009"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "100" ],
  "favorite_count" : "0",
  "id_str" : "435130058215542784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435130058215542784",
  "created_at" : "Sun Feb 16 19:14:24 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @iadorewomen_: I want a laid back, funny, shit talking, play fighting, type of relationship. \uD83D\uDC8F\uD83D\uDE1C\uD83D\uDC4C\uD83D\uDC4D",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "435096758432333824",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435096758432333824",
  "created_at" : "Sun Feb 16 17:02:05 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Always be there for the person who is always there for you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "435096696880918529",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435096696880918529",
  "created_at" : "Sun Feb 16 17:01:50 +0000 2014",
  "favorited" : false,
  "full_text" : "Never regret growing old. Not everyone has that privilege.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travel Scenes ✈️",
      "screen_name" : "TheWorldStories",
      "indices" : [ "3", "19" ],
      "id_str" : "284441324",
      "id" : "284441324"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheWorldStories/status/429581191474589696/photo/1",
      "source_status_id" : "429581191474589696",
      "indices" : [ "106", "128" ],
      "url" : "http://t.co/G96dLP03Gl",
      "media_url" : "http://pbs.twimg.com/media/BfYt0UjIAAArfqq.jpg",
      "id_str" : "429581191352942592",
      "source_user_id" : "284441324",
      "id" : "429581191352942592",
      "media_url_https" : "https://pbs.twimg.com/media/BfYt0UjIAAArfqq.jpg",
      "source_user_id_str" : "284441324",
      "sizes" : {
        "small" : {
          "w" : "640",
          "h" : "480",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "640",
          "h" : "480",
          "resize" : "fit"
        },
        "large" : {
          "w" : "640",
          "h" : "480",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "429581191474589696",
      "display_url" : "pic.twitter.com/G96dLP03Gl"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "128" ],
  "favorite_count" : "0",
  "id_str" : "435095861266505728",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435095861266505728",
  "possibly_sensitive" : false,
  "created_at" : "Sun Feb 16 16:58:31 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheWorldStories: Flathead Lake - is the largest natural freshwater lake in northwestern Montana, USA. http://t.co/G96dLP03Gl",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheWorldStories/status/429581191474589696/photo/1",
      "source_status_id" : "429581191474589696",
      "indices" : [ "106", "128" ],
      "url" : "http://t.co/G96dLP03Gl",
      "media_url" : "http://pbs.twimg.com/media/BfYt0UjIAAArfqq.jpg",
      "id_str" : "429581191352942592",
      "source_user_id" : "284441324",
      "id" : "429581191352942592",
      "media_url_https" : "https://pbs.twimg.com/media/BfYt0UjIAAArfqq.jpg",
      "source_user_id_str" : "284441324",
      "sizes" : {
        "small" : {
          "w" : "640",
          "h" : "480",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "640",
          "h" : "480",
          "resize" : "fit"
        },
        "large" : {
          "w" : "640",
          "h" : "480",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "429581191474589696",
      "display_url" : "pic.twitter.com/G96dLP03Gl"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travel Scenes ✈️",
      "screen_name" : "TheWorldStories",
      "indices" : [ "3", "19" ],
      "id_str" : "284441324",
      "id" : "284441324"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheWorldStories/status/429140275685240832/photo/1",
      "source_status_id" : "429140275685240832",
      "indices" : [ "69", "91" ],
      "url" : "http://t.co/Q9SUYFSIDU",
      "media_url" : "http://pbs.twimg.com/media/BfSczpMIAAAjsSn.jpg",
      "id_str" : "429140275551010816",
      "source_user_id" : "284441324",
      "id" : "429140275551010816",
      "media_url_https" : "https://pbs.twimg.com/media/BfSczpMIAAAjsSn.jpg",
      "source_user_id_str" : "284441324",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "453",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "720",
          "h" : "480",
          "resize" : "fit"
        },
        "large" : {
          "w" : "720",
          "h" : "480",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "429140275685240832",
      "display_url" : "pic.twitter.com/Q9SUYFSIDU"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "435095743905660928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435095743905660928",
  "possibly_sensitive" : false,
  "created_at" : "Sun Feb 16 16:58:03 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheWorldStories: The endless beaches of beautiful Cancun, Mexico http://t.co/Q9SUYFSIDU",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheWorldStories/status/429140275685240832/photo/1",
      "source_status_id" : "429140275685240832",
      "indices" : [ "69", "91" ],
      "url" : "http://t.co/Q9SUYFSIDU",
      "media_url" : "http://pbs.twimg.com/media/BfSczpMIAAAjsSn.jpg",
      "id_str" : "429140275551010816",
      "source_user_id" : "284441324",
      "id" : "429140275551010816",
      "media_url_https" : "https://pbs.twimg.com/media/BfSczpMIAAAjsSn.jpg",
      "source_user_id_str" : "284441324",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "453",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "720",
          "h" : "480",
          "resize" : "fit"
        },
        "large" : {
          "w" : "720",
          "h" : "480",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "429140275685240832",
      "display_url" : "pic.twitter.com/Q9SUYFSIDU"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Retarded Mom",
      "screen_name" : "unusuaifactpage",
      "indices" : [ "3", "19" ],
      "id_str" : "2478045696",
      "id" : "2478045696"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "101" ],
  "favorite_count" : "0",
  "id_str" : "435095018324635648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435095018324635648",
  "created_at" : "Sun Feb 16 16:55:10 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @UnusuaIFactPage: One in four people can compose a text-message without looking at their cellphone",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Retarded Mom",
      "screen_name" : "unusuaifactpage",
      "indices" : [ "3", "19" ],
      "id_str" : "2478045696",
      "id" : "2478045696"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "129" ],
  "favorite_count" : "0",
  "id_str" : "435095001757134848",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435095001757134848",
  "created_at" : "Sun Feb 16 16:55:06 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @UnusuaIFactPage: 88% people at some point in their life have tried to close the fridge slowly to see when the light goes out.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Retarded Mom",
      "screen_name" : "unusuaifactpage",
      "indices" : [ "3", "19" ],
      "id_str" : "2478045696",
      "id" : "2478045696"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "435094984828940288",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435094984828940288",
  "created_at" : "Sun Feb 16 16:55:02 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @UnusuaIFactPage: People who oversleep tend to crave more sleep.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/w7hbEwBHMd",
      "expanded_url" : "http://on.nnd.ng/1gPftd7",
      "display_url" : "on.nnd.ng/1gPftd7",
      "indices" : [ "99", "121" ]
    } ]
  },
  "display_text_range" : [ "0", "121" ],
  "favorite_count" : "0",
  "id_str" : "435057722288263168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435057722288263168",
  "possibly_sensitive" : false,
  "created_at" : "Sun Feb 16 14:26:58 +0000 2014",
  "favorited" : false,
  "full_text" : "[TheTrent] Pakistan Breaks Guinness World Record Of Largest Human Flag With 29,040 Youths (PHOTOS) http://t.co/w7hbEwBHMd",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "435051776480645120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435051776480645120",
  "created_at" : "Sun Feb 16 14:03:21 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Never apologize for showing feelings. When you do so, you apologize for the truth.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Daily Post Nigeria",
      "screen_name" : "DailyPostNGR",
      "indices" : [ "3", "16" ],
      "id_str" : "413428207",
      "id" : "413428207"
    } ],
    "urls" : [ {
      "url" : "http://t.co/6s7s3ty1oz",
      "expanded_url" : "http://ow.ly/3hls56",
      "display_url" : "ow.ly/3hls56",
      "indices" : [ "56", "78" ]
    } ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "435008764962680832",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435008764962680832",
  "possibly_sensitive" : false,
  "created_at" : "Sun Feb 16 11:12:26 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @DailyPostNgr: \"I'm always the bad guy\" - Mourinho - http://t.co/6s7s3ty1oz",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "435008680736878592",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435008680736878592",
  "created_at" : "Sun Feb 16 11:12:06 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Bitterness is like drinking poison &amp; waiting for the other person to die. -Steve Ostten",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "122" ],
  "favorite_count" : "0",
  "id_str" : "435008497336741888",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435008497336741888",
  "created_at" : "Sun Feb 16 11:11:22 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Its easy to forget things you want to remember. Its hard to forget things you don't want to remember.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "LoveQuotes",
      "indices" : [ "112", "123" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "123" ],
  "favorite_count" : "0",
  "id_str" : "435004736056872960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "435004736056872960",
  "created_at" : "Sun Feb 16 10:56:25 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek As long as you hate, there will be people to hate.\n— George Harrison Quotes #LoveQuotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Kabs_Cebekhulu",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "434997324432277504",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434997324432277504",
  "created_at" : "Sun Feb 16 10:26:58 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Kabs_Cebekhulu: Its So Easy To Say No Sometimes Outta Fear So Why not Take The Hard Road And Saying Yes!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "434996432517746688",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434996432517746688",
  "created_at" : "Sun Feb 16 10:23:26 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Everyone Dies. But not everyone really lives.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Marilyn Monroe",
      "screen_name" : "MarilynMonroeID",
      "indices" : [ "3", "19" ],
      "id_str" : "1596901142",
      "id" : "1596901142"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "434996242209587200",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434996242209587200",
  "created_at" : "Sun Feb 16 10:22:40 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @MarilynMonroeID: Forever is a long time, but I would spend it with you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "434930810672914432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434930810672914432",
  "created_at" : "Sun Feb 16 06:02:40 +0000 2014",
  "favorited" : false,
  "full_text" : "Live like a candle which burns itself but gives light to others",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Fitness & Motivation",
      "screen_name" : "StayFitDaily",
      "indices" : [ "3", "16" ],
      "id_str" : "568604985",
      "id" : "568604985"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "434927283334553600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434927283334553600",
  "created_at" : "Sun Feb 16 05:48:39 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @StayFitDaily: When people say healthy food is expensive, I tell them surgery is expensive.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "434916982803423232",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434916982803423232",
  "created_at" : "Sun Feb 16 05:07:43 +0000 2014",
  "favorited" : false,
  "full_text" : "Temporary defeat is not permanent failure, because a future where I don't succeed does not exist.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "16", "22" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "434791307295604736",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434791307295604736",
  "created_at" : "Sat Feb 15 20:48:20 +0000 2014",
  "favorited" : false,
  "full_text" : "Once you lose a #Virgo's love, you never get it back. They will however always care for you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "434784282012565507",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434784282012565507",
  "created_at" : "Sat Feb 15 20:20:25 +0000 2014",
  "favorited" : false,
  "full_text" : "Just be you, and if people don't like it, well,fuck them.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "434768556409253888",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434768556409253888",
  "created_at" : "Sat Feb 15 19:17:56 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: You don’t need car keys to drive me crazy.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "68" ],
  "favorite_count" : "0",
  "id_str" : "434764406543900672",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434764406543900672",
  "created_at" : "Sat Feb 15 19:01:26 +0000 2014",
  "favorited" : false,
  "full_text" : "Being positive in a negative situation isn't naive, it's leadership.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "24", "30" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "111" ],
  "favorite_count" : "0",
  "id_str" : "434728897167777792",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434728897167777792",
  "created_at" : "Sat Feb 15 16:40:20 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: I am a #Virgo because my mind doesn't have an off switch. I analyze my dreams as I'm dreaming.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "434727568156426241",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434727568156426241",
  "created_at" : "Sat Feb 15 16:35:03 +0000 2014",
  "favorited" : false,
  "full_text" : "Faith is taking the first step even when you don't see the whole staircase.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "0",
  "id_str" : "434727213905510400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434727213905510400",
  "created_at" : "Sat Feb 15 16:33:39 +0000 2014",
  "favorited" : false,
  "full_text" : "Even if I knew that tomorrow the world would go to pieces, I would still plant my apple tree.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "434726645963177984",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434726645963177984",
  "created_at" : "Sat Feb 15 16:31:23 +0000 2014",
  "favorited" : false,
  "full_text" : "Try to be like the turtle - at ease in your own shell.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "434726300201541633",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434726300201541633",
  "created_at" : "Sat Feb 15 16:30:01 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: When you talk, you are repeating what you already know. But if you listen, you may learn something new.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "434726238151012352",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434726238151012352",
  "created_at" : "Sat Feb 15 16:29:46 +0000 2014",
  "favorited" : false,
  "full_text" : "Health is the greatest gift, contentment the greatest wealth, faithfulness the best relationship.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "114" ],
  "favorite_count" : "0",
  "id_str" : "434725904942903296",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434725904942903296",
  "created_at" : "Sat Feb 15 16:28:27 +0000 2014",
  "favorited" : false,
  "full_text" : "The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "434725742099066881",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434725742099066881",
  "created_at" : "Sat Feb 15 16:27:48 +0000 2014",
  "favorited" : false,
  "full_text" : "I liked things better when I didn't understand them.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "434725643847487488",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434725643847487488",
  "created_at" : "Sat Feb 15 16:27:24 +0000 2014",
  "favorited" : false,
  "full_text" : "He who stops being better stops being good.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "434725439979159552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434725439979159552",
  "created_at" : "Sat Feb 15 16:26:36 +0000 2014",
  "favorited" : false,
  "full_text" : "All you need is love. But a little chocolate now and then doesn't hurt.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "434725222718406656",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434725222718406656",
  "created_at" : "Sat Feb 15 16:25:44 +0000 2014",
  "favorited" : false,
  "full_text" : "God loves each of us as if there were only one of us.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ETHICAL ONE",
      "screen_name" : "PsychographEd",
      "indices" : [ "3", "17" ],
      "id_str" : "58795639",
      "id" : "58795639"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "136" ],
  "favorite_count" : "0",
  "id_str" : "434724088083664896",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434724088083664896",
  "created_at" : "Sat Feb 15 16:21:14 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @PsychographEd: When people respond to my text with ‘K’, I get tempted to respond to with “U” for uranium, but I just control myself.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "434723911386005504",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434723911386005504",
  "created_at" : "Sat Feb 15 16:20:31 +0000 2014",
  "favorited" : false,
  "full_text" : "I never eat in a restaurant that's over a hundred feet off the ground and won't stand still.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "434723352117526528",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434723352117526528",
  "created_at" : "Sat Feb 15 16:18:18 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Marilyn Manson sometimes writes the word “Fuck” on his face to stop photographers from taking his photo as they can’t prin…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "129" ],
  "favorite_count" : "0",
  "id_str" : "434722445971701760",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434722445971701760",
  "created_at" : "Sat Feb 15 16:14:42 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: People are more likely to assume you're arguing with them when you're actually just explaining why you're right.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "434721079668768768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434721079668768768",
  "created_at" : "Sat Feb 15 16:09:16 +0000 2014",
  "favorited" : false,
  "full_text" : "Finding love is about timing. Psychologists believe it’s possible to find the right person but at the wrong time",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "434720616902828033",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434720616902828033",
  "created_at" : "Sat Feb 15 16:07:26 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Calling me ugly wont make you pretty.\nCalling me fake wont make you real.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "21" ],
  "favorite_count" : "0",
  "id_str" : "434580568521850880",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434580568521850880",
  "created_at" : "Sat Feb 15 06:50:56 +0000 2014",
  "favorited" : false,
  "full_text" : "Create each day anew.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "OJBjezreel",
      "indices" : [ "13", "24" ]
    }, {
      "text" : "NotAfraid",
      "indices" : [ "25", "35" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "35" ],
  "favorite_count" : "0",
  "id_str" : "434422828889538560",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434422828889538560",
  "created_at" : "Fri Feb 14 20:24:08 +0000 2014",
  "favorited" : false,
  "full_text" : "Listening to #OJBjezreel #NotAfraid",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "434422556029124608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434422556029124608",
  "created_at" : "Fri Feb 14 20:23:03 +0000 2014",
  "favorited" : false,
  "full_text" : "Gravitation is not responsible for people falling in love.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "434422419793915905",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434422419793915905",
  "created_at" : "Fri Feb 14 20:22:30 +0000 2014",
  "favorited" : false,
  "full_text" : "All you need is love. But a little chocolate now and then doesn't hurt.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "434394850625355776",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434394850625355776",
  "created_at" : "Fri Feb 14 18:32:57 +0000 2014",
  "favorited" : false,
  "full_text" : "God loves each of us as if there were only one of us.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "3", "15" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "434203941489098752",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434203941489098752",
  "created_at" : "Fri Feb 14 05:54:21 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @ChaskaBorek Don't go through life, grow through life.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "434083036108689408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "434083036108689408",
  "created_at" : "Thu Feb 13 21:53:55 +0000 2014",
  "favorited" : false,
  "full_text" : "If we should die tonight, then we should all die together.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "45" ],
  "favorite_count" : "0",
  "id_str" : "433911696110145536",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "433911696110145536",
  "created_at" : "Thu Feb 13 10:33:04 +0000 2014",
  "favorited" : false,
  "full_text" : "Everything in your life happens for a reason.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "41" ],
  "favorite_count" : "0",
  "id_str" : "433659660609261568",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "433659660609261568",
  "created_at" : "Wed Feb 12 17:51:34 +0000 2014",
  "favorited" : false,
  "full_text" : "Nothing leads to good that is not natural",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "0",
  "id_str" : "433659473249730560",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "433659473249730560",
  "created_at" : "Wed Feb 12 17:50:50 +0000 2014",
  "favorited" : false,
  "full_text" : "We are all in the gutter, but some of us are looking at the stars.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "433533583371022336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "433533583371022336",
  "created_at" : "Wed Feb 12 09:30:35 +0000 2014",
  "favorited" : false,
  "full_text" : "The more you care, the more it hurts.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "0",
  "id_str" : "433166778467106816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "433166778467106816",
  "created_at" : "Tue Feb 11 09:13:02 +0000 2014",
  "favorited" : false,
  "full_text" : "If you can't beat them, then you should consider joining them.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "433145169773617153",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "433145169773617153",
  "created_at" : "Tue Feb 11 07:47:10 +0000 2014",
  "favorited" : false,
  "full_text" : "Education is not preparation for Life; Education is Life itself",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Drizzy Fan",
      "screen_name" : "Drakee_YMCMB",
      "indices" : [ "3", "16" ],
      "id_str" : "411859932",
      "id" : "411859932"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "432998428667559937",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "432998428667559937",
  "created_at" : "Mon Feb 10 22:04:04 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Drakee_YMCMB: Music always helps, no matter what you're going through.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "36" ],
  "favorite_count" : "0",
  "id_str" : "432941700823392256",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "432941700823392256",
  "created_at" : "Mon Feb 10 18:18:39 +0000 2014",
  "favorited" : false,
  "full_text" : "Haters never DIE, they just MULTIPLY",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mana Ionescu",
      "screen_name" : "manamica",
      "indices" : [ "3", "12" ],
      "id_str" : "13520532",
      "id" : "13520532"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "432928220498112512",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "432928220498112512",
  "created_at" : "Mon Feb 10 17:25:05 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @manamica: \"Everything you've ever wanted is on the other side of fear.\" - George Addair",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "132" ],
  "favorite_count" : "0",
  "id_str" : "432917260555284480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "432917260555284480",
  "created_at" : "Mon Feb 10 16:41:32 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: What lies behind us &amp; what lies before us are tiny matters compared to what lies within us. -Ralph Waldo Emerson",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/vi_CAde/status/432896616987893760/photo/1",
      "indices" : [ "24", "46" ],
      "url" : "http://t.co/vhOy0Pp3zV",
      "media_url" : "http://pbs.twimg.com/media/BgH1Le9IYAENu--.jpg",
      "id_str" : "432896616841109505",
      "id" : "432896616841109505",
      "media_url_https" : "https://pbs.twimg.com/media/BgH1Le9IYAENu--.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "332",
          "h" : "332",
          "resize" : "fit"
        },
        "large" : {
          "w" : "332",
          "h" : "332",
          "resize" : "fit"
        },
        "small" : {
          "w" : "332",
          "h" : "332",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/vhOy0Pp3zV"
    } ],
    "hashtags" : [ {
      "text" : "faith",
      "indices" : [ "9", "15" ]
    } ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "id_str" : "432896616987893760",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "432896616987893760",
  "possibly_sensitive" : false,
  "created_at" : "Mon Feb 10 15:19:30 +0000 2014",
  "favorited" : false,
  "full_text" : "I put my #faith in you! http://t.co/vhOy0Pp3zV",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/vi_CAde/status/432896616987893760/photo/1",
      "indices" : [ "24", "46" ],
      "url" : "http://t.co/vhOy0Pp3zV",
      "media_url" : "http://pbs.twimg.com/media/BgH1Le9IYAENu--.jpg",
      "id_str" : "432896616841109505",
      "id" : "432896616841109505",
      "media_url_https" : "https://pbs.twimg.com/media/BgH1Le9IYAENu--.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "332",
          "h" : "332",
          "resize" : "fit"
        },
        "large" : {
          "w" : "332",
          "h" : "332",
          "resize" : "fit"
        },
        "small" : {
          "w" : "332",
          "h" : "332",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/vhOy0Pp3zV"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "432872085309124608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "432872085309124608",
  "created_at" : "Mon Feb 10 13:42:02 +0000 2014",
  "favorited" : false,
  "full_text" : "The quality of a leader is reflected in the standards they set for themselves.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "432856951836647424",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "432856951836647424",
  "created_at" : "Mon Feb 10 12:41:54 +0000 2014",
  "favorited" : false,
  "full_text" : "The heat has been insane lately D: make sure to hydrate yourselves and drink plenty of H20!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "84" ],
  "favorite_count" : "0",
  "id_str" : "432179733410091008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "432179733410091008",
  "created_at" : "Sat Feb 08 15:50:52 +0000 2014",
  "favorited" : false,
  "full_text" : "Too much stress literally causes the human brain to freeze and shut down temporarily",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "432084791182520320",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "432084791182520320",
  "created_at" : "Sat Feb 08 09:33:36 +0000 2014",
  "favorited" : false,
  "full_text" : "Running away from your problems is a race you'll never win.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "431779478088728576",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "431779478088728576",
  "created_at" : "Fri Feb 07 13:20:24 +0000 2014",
  "favorited" : false,
  "full_text" : "William Shakespeare' is an anagram of 'I am a weakish speller'.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "115" ],
  "favorite_count" : "0",
  "id_str" : "431779138295570432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "431779138295570432",
  "created_at" : "Fri Feb 07 13:19:03 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Everyone makes mistakes. The important thing is that you learn from them and don't repeat them.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Y! Online",
      "screen_name" : "YNaija",
      "indices" : [ "3", "10" ],
      "id_str" : "173620667",
      "id" : "173620667"
    } ],
    "urls" : [ {
      "url" : "http://t.co/H41GecJQ7a",
      "expanded_url" : "http://www.ynaija.com/it-was-very-painful-woman-with-maggots-in-vagina-speaks-out/",
      "display_url" : "ynaija.com/it-was-very-pa…",
      "indices" : [ "81", "103" ]
    } ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "431778992874881024",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "431778992874881024",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 07 13:18:28 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @YNaija: ‘It was very painful’: Woman with maggots in private part speaks out http://t.co/H41GecJQ7a",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "8" ],
  "favorite_count" : "0",
  "id_str" : "430780074346831872",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "430780074346831872",
  "created_at" : "Tue Feb 04 19:09:07 +0000 2014",
  "favorited" : false,
  "full_text" : "im ßa¢k!",
  "lang" : "tr"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "426206217049231360",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "426206217049231360",
  "created_at" : "Thu Jan 23 04:14:15 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Do not regret growing older; it is a privilege denied to many.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Retarded Mom",
      "screen_name" : "unusuaifactpage",
      "indices" : [ "3", "19" ],
      "id_str" : "2478045696",
      "id" : "2478045696"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "425345152089989120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "425345152089989120",
  "created_at" : "Mon Jan 20 19:12:41 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @UnusuaIFactPage: Chocolate, sex and laughter are all key to a healthy brain.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Retarded Mom",
      "screen_name" : "unusuaifactpage",
      "indices" : [ "3", "19" ],
      "id_str" : "2478045696",
      "id" : "2478045696"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "425345076005330944",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "425345076005330944",
  "created_at" : "Mon Jan 20 19:12:23 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @UnusuaIFactPage: Loneliness causes people to take longer baths/showers, sleep longer and over think more",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "424911225886359552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "424911225886359552",
  "created_at" : "Sun Jan 19 14:28:25 +0000 2014",
  "favorited" : false,
  "full_text" : "The only way to enjoy anything in this life is to earn it first.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "76" ],
  "favorite_count" : "0",
  "id_str" : "424782963461857280",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "424782963461857280",
  "created_at" : "Sun Jan 19 05:58:45 +0000 2014",
  "favorited" : false,
  "full_text" : "Animals don't hate, and we're supposed to be better than them. Elvis Presley",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "id_str" : "424417717828206592",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "424417717828206592",
  "created_at" : "Sat Jan 18 05:47:23 +0000 2014",
  "favorited" : false,
  "full_text" : "Goes around comes around...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "424415736699047936",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "424415736699047936",
  "created_at" : "Sat Jan 18 05:39:31 +0000 2014",
  "favorited" : false,
  "full_text" : "If you don't build your dream, someone will hire you to build theirs.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "id_str" : "423656273759182848",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "423656273759182848",
  "created_at" : "Thu Jan 16 03:21:41 +0000 2014",
  "favorited" : false,
  "full_text" : "Everyday holds the possibility of a miracle.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "423035620962107392",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "423035620962107392",
  "created_at" : "Tue Jan 14 10:15:26 +0000 2014",
  "favorited" : false,
  "full_text" : "Trust, respect, great sex and communication - 4 essential parts of a successful relationship",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "35" ],
  "favorite_count" : "0",
  "id_str" : "422914313834475520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "422914313834475520",
  "created_at" : "Tue Jan 14 02:13:24 +0000 2014",
  "favorited" : false,
  "full_text" : "CR7 WINS 2013 BALLON D'OR... GREAT!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "422715785707274240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "422715785707274240",
  "created_at" : "Mon Jan 13 13:04:31 +0000 2014",
  "favorited" : false,
  "full_text" : "When a person is down in the world, an ounce of help is sometimes better than a pound of preaching.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James",
      "screen_name" : "JamesWoodd",
      "indices" : [ "3", "14" ],
      "id_str" : "282080510",
      "id" : "282080510"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/JamesWoodd/status/416574021983940608/photo/1",
      "source_status_id" : "416574021983940608",
      "indices" : [ "105", "127" ],
      "url" : "http://t.co/uCuW8dYa3C",
      "media_url" : "http://pbs.twimg.com/media/Bcf33ZxCIAAL7Zl.jpg",
      "id_str" : "416574021736472576",
      "source_user_id" : "282080510",
      "id" : "416574021736472576",
      "media_url_https" : "https://pbs.twimg.com/media/Bcf33ZxCIAAL7Zl.jpg",
      "source_user_id_str" : "282080510",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "640",
          "h" : "388",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "640",
          "h" : "388",
          "resize" : "fit"
        },
        "large" : {
          "w" : "640",
          "h" : "388",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "416574021983940608",
      "display_url" : "pic.twitter.com/uCuW8dYa3C"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "0",
  "id_str" : "422711557340925952",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "422711557340925952",
  "possibly_sensitive" : false,
  "created_at" : "Mon Jan 13 12:47:43 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @JamesWoodd: When you and your girlfriend break up and all those boys that were 'just mates' are like http://t.co/uCuW8dYa3C",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/JamesWoodd/status/416574021983940608/photo/1",
      "source_status_id" : "416574021983940608",
      "indices" : [ "105", "127" ],
      "url" : "http://t.co/uCuW8dYa3C",
      "media_url" : "http://pbs.twimg.com/media/Bcf33ZxCIAAL7Zl.jpg",
      "id_str" : "416574021736472576",
      "source_user_id" : "282080510",
      "id" : "416574021736472576",
      "media_url_https" : "https://pbs.twimg.com/media/Bcf33ZxCIAAL7Zl.jpg",
      "source_user_id_str" : "282080510",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "640",
          "h" : "388",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "640",
          "h" : "388",
          "resize" : "fit"
        },
        "large" : {
          "w" : "640",
          "h" : "388",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "416574021983940608",
      "display_url" : "pic.twitter.com/uCuW8dYa3C"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "422700122644824064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "422700122644824064",
  "created_at" : "Mon Jan 13 12:02:17 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Revenge is a dish, best served cold.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "422691308013359104",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "422691308013359104",
  "created_at" : "Mon Jan 13 11:27:15 +0000 2014",
  "favorited" : false,
  "full_text" : "Who's gon really win the Ballon d'Or 2013 title? I vote CR7!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "GOODMORNING",
      "indices" : [ "0", "12" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "12" ],
  "favorite_count" : "0",
  "id_str" : "422597538508988416",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "422597538508988416",
  "created_at" : "Mon Jan 13 05:14:39 +0000 2014",
  "favorited" : false,
  "full_text" : "#GOODMORNING",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "422595590229610496",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "422595590229610496",
  "created_at" : "Mon Jan 13 05:06:54 +0000 2014",
  "favorited" : false,
  "full_text" : "Itz MONDAY! Rising early make the road short... Jump outta bed!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "422381433236500480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "422381433236500480",
  "created_at" : "Sun Jan 12 14:55:55 +0000 2014",
  "favorited" : false,
  "full_text" : "When a person is down in the world, an ounce of help is sometimes better than a pound of preaching.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "49" ],
  "favorite_count" : "0",
  "id_str" : "421545401813311488",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "421545401813311488",
  "created_at" : "Fri Jan 10 07:33:50 +0000 2014",
  "favorited" : false,
  "full_text" : "He That Come To Equity Must Come With Clean Hands",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "30" ],
  "favorite_count" : "0",
  "id_str" : "421515346475233280",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "421515346475233280",
  "created_at" : "Fri Jan 10 05:34:24 +0000 2014",
  "favorited" : false,
  "full_text" : "PEOPLE PROTECT WHAT THEY LOVE.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "421513510594826240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "421513510594826240",
  "created_at" : "Fri Jan 10 05:27:06 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Count your age by friends, not years. Count your life by smiles, not tears.\n— John Lennon Quotes #LoveQ…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ETHICAL ONE",
      "screen_name" : "PsychographEd",
      "indices" : [ "3", "17" ],
      "id_str" : "58795639",
      "id" : "58795639"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "0",
  "id_str" : "421513303693987840",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "421513303693987840",
  "created_at" : "Fri Jan 10 05:26:17 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @PsychographEd: I need a hug and, if possible, a gun.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Common White Girl",
      "screen_name" : "damnitstrue",
      "indices" : [ "3", "15" ],
      "id_str" : "66714703",
      "id" : "66714703"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/damnitstrue/status/421506880134213632/photo/1",
      "source_status_id" : "421506880134213632",
      "indices" : [ "34", "56" ],
      "url" : "http://t.co/sLR5p9lQcx",
      "media_url" : "http://pbs.twimg.com/media/Bdl-RiwIMAAoPQx.jpg",
      "id_str" : "421506879987396608",
      "source_user_id" : "66714703",
      "id" : "421506879987396608",
      "media_url_https" : "https://pbs.twimg.com/media/Bdl-RiwIMAAoPQx.jpg",
      "source_user_id_str" : "66714703",
      "sizes" : {
        "large" : {
          "w" : "600",
          "h" : "540",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "600",
          "h" : "540",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "600",
          "h" : "540",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "421506880134213632",
      "display_url" : "pic.twitter.com/sLR5p9lQcx"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "0",
  "id_str" : "421513028866437121",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "421513028866437121",
  "possibly_sensitive" : false,
  "created_at" : "Fri Jan 10 05:25:12 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @damnitstrue: this is talent \uD83D\uDE33 http://t.co/sLR5p9lQcx",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/damnitstrue/status/421506880134213632/photo/1",
      "source_status_id" : "421506880134213632",
      "indices" : [ "34", "56" ],
      "url" : "http://t.co/sLR5p9lQcx",
      "media_url" : "http://pbs.twimg.com/media/Bdl-RiwIMAAoPQx.jpg",
      "id_str" : "421506879987396608",
      "source_user_id" : "66714703",
      "id" : "421506879987396608",
      "media_url_https" : "https://pbs.twimg.com/media/Bdl-RiwIMAAoPQx.jpg",
      "source_user_id_str" : "66714703",
      "sizes" : {
        "large" : {
          "w" : "600",
          "h" : "540",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "600",
          "h" : "540",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "600",
          "h" : "540",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "421506880134213632",
      "display_url" : "pic.twitter.com/sLR5p9lQcx"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "7" ],
  "favorite_count" : "0",
  "id_str" : "420629289646960640",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "420629289646960640",
  "created_at" : "Tue Jan 07 18:53:32 +0000 2014",
  "favorited" : false,
  "full_text" : "MARTINO",
  "lang" : "es"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Юлька Потапчук",
      "screen_name" : "AgwuComedy",
      "indices" : [ "3", "14" ],
      "id_str" : "164091471",
      "id" : "164091471"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "420410406771757056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "420410406771757056",
  "created_at" : "Tue Jan 07 04:23:46 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AgwuComedy: When you find a King, keep him. When you find a Queen, love &amp; protect her. Don't reshuffle ur card, cos U might end up pick…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Юлька Потапчук",
      "screen_name" : "AgwuComedy",
      "indices" : [ "3", "14" ],
      "id_str" : "164091471",
      "id" : "164091471"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "420410297174593536",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "420410297174593536",
  "created_at" : "Tue Jan 07 04:23:20 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AgwuComedy: Nowadays The evil that men do, surprises even the devil.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Юлька Потапчук",
      "screen_name" : "AgwuComedy",
      "indices" : [ "3", "14" ],
      "id_str" : "164091471",
      "id" : "164091471"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "420410165561524224",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "420410165561524224",
  "created_at" : "Tue Jan 07 04:22:48 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AgwuComedy: Lions sleep for 18hrs, while donkeys work 18hrs in a day. If hard work was d secret to success,a Donkey would have been d K…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "105" ],
  "favorite_count" : "0",
  "id_str" : "418793450503696384",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418793450503696384",
  "created_at" : "Thu Jan 02 17:18:34 +0000 2014",
  "favorited" : false,
  "full_text" : "Never ever take ibuprofen to cure hangover. On an empty stomach it can actually tear your stomach lining.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "knowledge",
      "screen_name" : "TheGoogleFactz",
      "indices" : [ "3", "18" ],
      "id_str" : "749952350",
      "id" : "749952350"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "418406759855063040",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418406759855063040",
  "created_at" : "Wed Jan 01 15:41:59 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Thegooglefactz: Wait 24 hours before getting mad and reacting. If it doesn't bother you in 24 hours, it probably isn't important enough…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Life Tips\uD83D\uDCA1",
      "screen_name" : "BestProAdvice",
      "indices" : [ "3", "17" ],
      "id_str" : "1305995330",
      "id" : "1305995330"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "418406582947708928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418406582947708928",
  "created_at" : "Wed Jan 01 15:41:17 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @BestProAdvice: The morning after New Years, eat eggs. Eggs have many proteins and enzymes that assist in making the process of getting …",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "418403898454708224",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418403898454708224",
  "created_at" : "Wed Jan 01 15:30:37 +0000 2014",
  "favorited" : false,
  "full_text" : "Every saint has a past. Every sinner has a future.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "MxhdAzri",
      "indices" : [ "3", "12" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "418394685066215424",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418394685066215424",
  "created_at" : "Wed Jan 01 14:54:00 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @MxhdAzri: I miss some of friend espicially you. ",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "12" ],
  "favorite_count" : "0",
  "id_str" : "418202833679552512",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418202833679552512",
  "created_at" : "Wed Jan 01 02:11:40 +0000 2014",
  "favorited" : false,
  "full_text" : "Gott Nytt Ar",
  "lang" : "sv"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheseDamnQuote/status/418169530393718784/photo/1",
      "source_status_id" : "418169530393718784",
      "indices" : [ "37", "59" ],
      "url" : "http://t.co/P8fP3VHhVG",
      "media_url" : "http://pbs.twimg.com/media/Bc2i-OLCMAAxQM6.jpg",
      "id_str" : "418169530255290368",
      "source_user_id" : "63896875",
      "id" : "418169530255290368",
      "media_url_https" : "https://pbs.twimg.com/media/Bc2i-OLCMAAxQM6.jpg",
      "source_user_id_str" : "63896875",
      "sizes" : {
        "large" : {
          "w" : "403",
          "h" : "403",
          "resize" : "fit"
        },
        "small" : {
          "w" : "403",
          "h" : "403",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "403",
          "h" : "403",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "418169530393718784",
      "display_url" : "pic.twitter.com/P8fP3VHhVG"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "418199865441910784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418199865441910784",
  "possibly_sensitive" : false,
  "created_at" : "Wed Jan 01 01:59:52 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: RT IF YOU AGREE. http://t.co/P8fP3VHhVG",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheseDamnQuote/status/418169530393718784/photo/1",
      "source_status_id" : "418169530393718784",
      "indices" : [ "37", "59" ],
      "url" : "http://t.co/P8fP3VHhVG",
      "media_url" : "http://pbs.twimg.com/media/Bc2i-OLCMAAxQM6.jpg",
      "id_str" : "418169530255290368",
      "source_user_id" : "63896875",
      "id" : "418169530255290368",
      "media_url_https" : "https://pbs.twimg.com/media/Bc2i-OLCMAAxQM6.jpg",
      "source_user_id_str" : "63896875",
      "sizes" : {
        "large" : {
          "w" : "403",
          "h" : "403",
          "resize" : "fit"
        },
        "small" : {
          "w" : "403",
          "h" : "403",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "403",
          "h" : "403",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "418169530393718784",
      "display_url" : "pic.twitter.com/P8fP3VHhVG"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "PeopleWhoMadeMy2013",
      "indices" : [ "0", "20" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "418196619402563584",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418196619402563584",
  "created_at" : "Wed Jan 01 01:46:58 +0000 2014",
  "favorited" : false,
  "full_text" : "#PeopleWhoMadeMy2013 All My Friends, Thank You So Much. Have A Fantastic 2014 :)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Ayanda Mtiyane",
      "screen_name" : "MtiyaneAyanda",
      "indices" : [ "0", "14" ],
      "id_str" : "1662909558",
      "id" : "1662909558"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "0",
  "id_str" : "418193553131839489",
  "in_reply_to_user_id" : "1662909558",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418193553131839489",
  "created_at" : "Wed Jan 01 01:34:47 +0000 2014",
  "favorited" : false,
  "full_text" : "@MtiyaneAyanda hiii! happy new year :)",
  "lang" : "en",
  "in_reply_to_screen_name" : "MtiyaneAyanda",
  "in_reply_to_user_id_str" : "1662909558"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "HappyNewYear",
      "indices" : [ "0", "13" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "14" ],
  "favorite_count" : "0",
  "id_str" : "418191893936476160",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418191893936476160",
  "created_at" : "Wed Jan 01 01:28:11 +0000 2014",
  "favorited" : false,
  "full_text" : "#HappyNewYear!",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "418191478847188992",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "418191478847188992",
  "created_at" : "Wed Jan 01 01:26:32 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Happy New Year 2014 everyone. May this new year bring peace and joy in your life and take you towards excellence. http…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/Funny_Truth/status/415715083352674304/photo/1",
      "source_status_id" : "415715083352674304",
      "indices" : [ "64", "86" ],
      "url" : "http://t.co/kkSUeaNCyP",
      "media_url" : "http://pbs.twimg.com/media/BcTqqm9CEAAAqjn.jpg",
      "id_str" : "415715083356868608",
      "source_user_id" : "296623811",
      "id" : "415715083356868608",
      "media_url_https" : "https://pbs.twimg.com/media/BcTqqm9CEAAAqjn.jpg",
      "source_user_id_str" : "296623811",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "291",
          "h" : "173",
          "resize" : "fit"
        },
        "large" : {
          "w" : "291",
          "h" : "173",
          "resize" : "fit"
        },
        "small" : {
          "w" : "291",
          "h" : "173",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "415715083352674304",
      "display_url" : "pic.twitter.com/kkSUeaNCyP"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "415825387831042048",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "415825387831042048",
  "possibly_sensitive" : false,
  "created_at" : "Wed Dec 25 12:44:32 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Merry Christmas Guys, Enjoy and Love everyone. http://t.co/kkSUeaNCyP",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/Funny_Truth/status/415715083352674304/photo/1",
      "source_status_id" : "415715083352674304",
      "indices" : [ "64", "86" ],
      "url" : "http://t.co/kkSUeaNCyP",
      "media_url" : "http://pbs.twimg.com/media/BcTqqm9CEAAAqjn.jpg",
      "id_str" : "415715083356868608",
      "source_user_id" : "296623811",
      "id" : "415715083356868608",
      "media_url_https" : "https://pbs.twimg.com/media/BcTqqm9CEAAAqjn.jpg",
      "source_user_id_str" : "296623811",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "291",
          "h" : "173",
          "resize" : "fit"
        },
        "large" : {
          "w" : "291",
          "h" : "173",
          "resize" : "fit"
        },
        "small" : {
          "w" : "291",
          "h" : "173",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "415715083352674304",
      "display_url" : "pic.twitter.com/kkSUeaNCyP"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "id_str" : "414664223026053120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414664223026053120",
  "created_at" : "Sun Dec 22 07:50:29 +0000 2013",
  "favorited" : false,
  "full_text" : "The dogs bark, but you keep walking - Mourinho",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "0",
  "id_str" : "414661429145645056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414661429145645056",
  "created_at" : "Sun Dec 22 07:39:23 +0000 2013",
  "favorited" : false,
  "full_text" : "In him was life, and that life was the light of men. - John1:4",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "124" ],
  "favorite_count" : "0",
  "id_str" : "414660823160979456",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414660823160979456",
  "created_at" : "Sun Dec 22 07:36:58 +0000 2013",
  "favorited" : false,
  "full_text" : "And we know that in all things God works 4 d good of those who love him, who av been called according 2 his purpose- Rom8:28",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "0",
  "id_str" : "414659808080711680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414659808080711680",
  "created_at" : "Sun Dec 22 07:32:56 +0000 2013",
  "favorited" : false,
  "full_text" : "4 GOD so loved d world dt he gave his one and only Son, dt whoever believes in him shall nt perish bt av eternal life.-John3:16",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "414341756113936385",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414341756113936385",
  "created_at" : "Sat Dec 21 10:29:07 +0000 2013",
  "favorited" : false,
  "full_text" : "You can never cross the ocean unless you have the courage to lose sight of shore. -Christopher Columbus",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "89" ],
  "favorite_count" : "0",
  "id_str" : "414340696238481408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414340696238481408",
  "created_at" : "Sat Dec 21 10:24:54 +0000 2013",
  "favorited" : false,
  "full_text" : "Your desire for success must always be greater than any obstacle that stands in your way.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "0",
  "id_str" : "414339922410360832",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414339922410360832",
  "created_at" : "Sat Dec 21 10:21:50 +0000 2013",
  "favorited" : false,
  "full_text" : "Pleasures of love last a moment but pain of love lasts a lifetime.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "414339450404356096",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414339450404356096",
  "created_at" : "Sat Dec 21 10:19:57 +0000 2013",
  "favorited" : false,
  "full_text" : "In the beginning GOD created the heavens and the earth. Gen. 1:1",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "414338364985589760",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "414338364985589760",
  "created_at" : "Sat Dec 21 10:15:38 +0000 2013",
  "favorited" : false,
  "full_text" : "Courtesy is as much a mark of a gentleman as courage - Theodore Roosevelt",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "414337806082007040",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "414337806082007040",
  "created_at" : "Sat Dec 21 10:13:25 +0000 2013",
  "favorited" : false,
  "full_text" : "When asking for help, appeal to people's self-interest not their mercy or gratitude",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "412488962046169088",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412488962046169088",
  "created_at" : "Mon Dec 16 07:46:46 +0000 2013",
  "favorited" : false,
  "full_text" : "Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "0",
  "id_str" : "412276942675517440",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412276942675517440",
  "created_at" : "Sun Dec 15 17:44:17 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Textiety is a condition in which an individual feels anxious after not receiving or sending any text messages.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "412104989113204736",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412104989113204736",
  "created_at" : "Sun Dec 15 06:21:00 +0000 2013",
  "favorited" : false,
  "full_text" : "The chief obstacle to the progress\nof the human race is the human\nrace.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "49" ],
  "favorite_count" : "0",
  "id_str" : "412104793750908928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412104793750908928",
  "created_at" : "Sun Dec 15 06:20:14 +0000 2013",
  "favorited" : false,
  "full_text" : "Desire nothing, give up all desires\nand be happy.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Quote",
      "indices" : [ "104", "110" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "#Quotes",
      "screen_name" : "OmarAlSalhi",
      "indices" : [ "3", "15" ],
      "id_str" : "72385532",
      "id" : "72385532"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "id_str" : "412103303355330561",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412103303355330561",
  "created_at" : "Sun Dec 15 06:14:18 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @OmarAlSalhi: You cannot teach a man anything; you can only help him find it within himself. Galileo #Quote",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "0",
  "id_str" : "412101266475454465",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412101266475454465",
  "created_at" : "Sun Dec 15 06:06:13 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Words are like bullets: when well aimed, they have a pretty hard effect.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ETHICAL ONE",
      "screen_name" : "PsychographEd",
      "indices" : [ "3", "17" ],
      "id_str" : "58795639",
      "id" : "58795639"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "412097516604125184",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412097516604125184",
  "created_at" : "Sun Dec 15 05:51:19 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @PsychographEd: Q: why did the chicken cross the road?\n\nA: who fucking cares!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "116" ],
  "favorite_count" : "0",
  "id_str" : "412089763660042240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412089763660042240",
  "created_at" : "Sun Dec 15 05:20:30 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: I'm trying to right my wrongs/ But it's funny the same wrongs help me write this song. - Kanye West",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/Funny_Truth/status/411949998884913152/photo/1",
      "source_status_id" : "411949998884913152",
      "indices" : [ "24", "46" ],
      "url" : "http://t.co/tqhA7fEkfK",
      "media_url" : "http://pbs.twimg.com/media/BbeKV2UCAAAXV9k.jpg",
      "id_str" : "411949998889107456",
      "source_user_id" : "296623811",
      "id" : "411949998889107456",
      "media_url_https" : "https://pbs.twimg.com/media/BbeKV2UCAAAXV9k.jpg",
      "source_user_id_str" : "296623811",
      "sizes" : {
        "small" : {
          "w" : "393",
          "h" : "472",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "393",
          "h" : "472",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "393",
          "h" : "472",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "411949998884913152",
      "display_url" : "pic.twitter.com/tqhA7fEkfK"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "id_str" : "412085923594403840",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412085923594403840",
  "possibly_sensitive" : false,
  "created_at" : "Sun Dec 15 05:05:15 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: LMAO.. http://t.co/tqhA7fEkfK",
  "lang" : "ht",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/Funny_Truth/status/411949998884913152/photo/1",
      "source_status_id" : "411949998884913152",
      "indices" : [ "24", "46" ],
      "url" : "http://t.co/tqhA7fEkfK",
      "media_url" : "http://pbs.twimg.com/media/BbeKV2UCAAAXV9k.jpg",
      "id_str" : "411949998889107456",
      "source_user_id" : "296623811",
      "id" : "411949998889107456",
      "media_url_https" : "https://pbs.twimg.com/media/BbeKV2UCAAAXV9k.jpg",
      "source_user_id_str" : "296623811",
      "sizes" : {
        "small" : {
          "w" : "393",
          "h" : "472",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "393",
          "h" : "472",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "393",
          "h" : "472",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "411949998884913152",
      "display_url" : "pic.twitter.com/tqhA7fEkfK"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "26", "32" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "412080220787982336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412080220787982336",
  "created_at" : "Sun Dec 15 04:42:35 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: It's the #Virgo way or the highway.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Kabs_Cebekhulu",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "412079260560809984",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "412079260560809984",
  "created_at" : "Sun Dec 15 04:38:46 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Kabs_Cebekhulu: Dont Kiss Behind The Garden Gate Love Is Blind But The Neighbours Aint..",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travel Scenes ✈️",
      "screen_name" : "TheWorldStories",
      "indices" : [ "3", "19" ],
      "id_str" : "284441324",
      "id" : "284441324"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheWorldStories/status/396871937588461568/photo/1",
      "source_status_id" : "396871937588461568",
      "indices" : [ "97", "119" ],
      "url" : "http://t.co/FMbjfDBHtF",
      "media_url" : "http://pbs.twimg.com/media/BYH47KWIUAAU8h_.jpg",
      "id_str" : "396871937458458624",
      "source_user_id" : "284441324",
      "id" : "396871937458458624",
      "media_url_https" : "https://pbs.twimg.com/media/BYH47KWIUAAU8h_.jpg",
      "source_user_id_str" : "284441324",
      "sizes" : {
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "590",
          "h" : "787",
          "resize" : "fit"
        },
        "large" : {
          "w" : "590",
          "h" : "787",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "396871937588461568",
      "display_url" : "pic.twitter.com/FMbjfDBHtF"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "411830056621977600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411830056621977600",
  "possibly_sensitive" : false,
  "created_at" : "Sat Dec 14 12:08:31 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheWorldStories: How to float. 1: Pour some water. 2: Step away from water. 3: Take a photo. http://t.co/FMbjfDBHtF",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheWorldStories/status/396871937588461568/photo/1",
      "source_status_id" : "396871937588461568",
      "indices" : [ "97", "119" ],
      "url" : "http://t.co/FMbjfDBHtF",
      "media_url" : "http://pbs.twimg.com/media/BYH47KWIUAAU8h_.jpg",
      "id_str" : "396871937458458624",
      "source_user_id" : "284441324",
      "id" : "396871937458458624",
      "media_url_https" : "https://pbs.twimg.com/media/BYH47KWIUAAU8h_.jpg",
      "source_user_id_str" : "284441324",
      "sizes" : {
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "590",
          "h" : "787",
          "resize" : "fit"
        },
        "large" : {
          "w" : "590",
          "h" : "787",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "396871937588461568",
      "display_url" : "pic.twitter.com/FMbjfDBHtF"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "0",
  "id_str" : "411828869893988352",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411828869893988352",
  "created_at" : "Sat Dec 14 12:03:48 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: If I ever get you, I'm keeping you. \uD83D\uDC4C\uD83D\uDE4F",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "148" ],
  "favorite_count" : "0",
  "id_str" : "411827284140912640",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411827284140912640",
  "created_at" : "Sat Dec 14 11:57:30 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Look at your problems as problems &amp; they'll continue to hold you down. See them as blessings in disguise &amp; that's what they…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "411749565566844928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411749565566844928",
  "created_at" : "Sat Dec 14 06:48:41 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: We don't lose friends, we just learn who our real ones are.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "411749503939911680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411749503939911680",
  "created_at" : "Sat Dec 14 06:48:26 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: It has been scientifically proven that the less you know, the more you think you know.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "go to @JensenKarp now",
      "screen_name" : "jensenclan88",
      "indices" : [ "3", "16" ],
      "id_str" : "1095876683746336768",
      "id" : "1095876683746336768"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "411748595701153792",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411748595701153792",
  "created_at" : "Sat Dec 14 06:44:49 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @JensenClan88: It’s racist that they made black licorice taste so bad.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Nonkulu94115960",
      "indices" : [ "3", "19" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "411747903838105600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411747903838105600",
  "created_at" : "Sat Dec 14 06:42:04 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Nonkulu94115960: U cnt always keep waiting 4 a better",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Kabs_Cebekhulu",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "135" ],
  "favorite_count" : "0",
  "id_str" : "411747721612386305",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411747721612386305",
  "created_at" : "Sat Dec 14 06:41:21 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Kabs_Cebekhulu: I Cut People Off With no hesitation Cant Trust Everybody Cant Love Everybody Cant Be friends With Everybody Fuck it",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "411746204780081152",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411746204780081152",
  "created_at" : "Sat Dec 14 06:35:19 +0000 2013",
  "favorited" : false,
  "full_text" : "Health is the greatest gift,\ncontentment the greatest wealth,\nfaithfulness the best relationship.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "411746031580491776",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411746031580491776",
  "created_at" : "Sat Dec 14 06:34:38 +0000 2013",
  "favorited" : false,
  "full_text" : "Try to be like the turtle - at ease in\nyour own shell.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "101" ],
  "favorite_count" : "0",
  "id_str" : "411745423662284800",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411745423662284800",
  "created_at" : "Sat Dec 14 06:32:13 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Everyone has a story. Everyone has gone through something that has  changed them.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "126" ],
  "favorite_count" : "0",
  "id_str" : "411745250152288256",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411745250152288256",
  "created_at" : "Sat Dec 14 06:31:32 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Deep voice is considered as a sex appeal in men but deep voiced men actually tend to have lower sperm counts.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wole Soyinka",
      "screen_name" : "MrWoleSoyinka",
      "indices" : [ "3", "17" ],
      "id_str" : "761869446923321345",
      "id" : "761869446923321345"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "411745030727286784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411745030727286784",
  "created_at" : "Sat Dec 14 06:30:39 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @MrWoleSoyinka: Don't judge a man until u've walked a mile in his shoes.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/gU9j9XPP78",
      "expanded_url" : "http://bit.ly/QEzUSu",
      "display_url" : "bit.ly/QEzUSu",
      "indices" : [ "81", "103" ]
    } ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "458956531057577984",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458956531057577984",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:12:18 +0000 2014",
  "favorited" : false,
  "full_text" : "How T.B Joshua’s anointing water saved us from the Nyanya bomb blast – Survivors http://t.co/gU9j9XPP78",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/kac6NuUIUG",
      "expanded_url" : "http://bit.ly/1jAn3rR",
      "display_url" : "bit.ly/1jAn3rR",
      "indices" : [ "85", "107" ]
    } ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "458956442993979392",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458956442993979392",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:11:57 +0000 2014",
  "favorited" : false,
  "full_text" : "Rapper Andre Johnson Cuts Off Own PENNIS Then Jumps Off Two-Storey Building [PHOTOS] http://t.co/kac6NuUIUG",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/ZT33T4u2NC",
      "expanded_url" : "http://bit.ly/1holjAv",
      "display_url" : "bit.ly/1holjAv",
      "indices" : [ "38", "60" ]
    } ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "458955655924436992",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458955655924436992",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:08:50 +0000 2014",
  "favorited" : false,
  "full_text" : "Daily Meditations: The Power Of Words http://t.co/ZT33T4u2NC",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/TElCMCsSBz",
      "expanded_url" : "http://bit.ly/1gQTwJO",
      "display_url" : "bit.ly/1gQTwJO",
      "indices" : [ "43", "65" ]
    } ]
  },
  "display_text_range" : [ "0", "65" ],
  "favorite_count" : "0",
  "id_str" : "458954557406842881",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458954557406842881",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:04:28 +0000 2014",
  "favorited" : false,
  "full_text" : "Atiku Abubakar Reacts On David Moyes' Sack http://t.co/TElCMCsSBz",
  "lang" : "tl"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/mTiEbFlbz9",
      "expanded_url" : "http://bit.ly/1jAkUfO",
      "display_url" : "bit.ly/1jAkUfO",
      "indices" : [ "104", "126" ]
    } ]
  },
  "display_text_range" : [ "0", "126" ],
  "favorite_count" : "0",
  "id_str" : "458954454835146752",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458954454835146752",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:04:03 +0000 2014",
  "favorited" : false,
  "full_text" : "‘Hoping for better days ahead’ – Psquare’s Peter Okoye Breaks Silence Since News Of Duo Split (DETAILS) http://t.co/mTiEbFlbz9",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/6igUeYe7aU",
      "expanded_url" : "http://bit.ly/1jAkINu",
      "display_url" : "bit.ly/1jAkINu",
      "indices" : [ "59", "81" ]
    } ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "458954315093135361",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458954315093135361",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:03:30 +0000 2014",
  "favorited" : false,
  "full_text" : "Bandits Steal 625 Cows From Grazing Camps In Kaduna, Abuja http://t.co/6igUeYe7aU",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/k0Kg1OU5yp",
      "expanded_url" : "http://bit.ly/1jAkDt7",
      "display_url" : "bit.ly/1jAkDt7",
      "indices" : [ "58", "80" ]
    } ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "458954242263613440",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458954242263613440",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 23 13:03:12 +0000 2014",
  "favorited" : false,
  "full_text" : "I’m Ready To Expose Sponsors Of Boko Haram – Adamawa Seer http://t.co/k0Kg1OU5yp",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Dapo Osuntuyi",
      "screen_name" : "dappyboy0489",
      "indices" : [ "3", "16" ],
      "id_str" : "262836675",
      "id" : "262836675"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "111" ],
  "favorite_count" : "0",
  "id_str" : "458953401502814208",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458953401502814208",
  "created_at" : "Wed Apr 23 12:59:52 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Dappyboy0489: Tom Cleverley has handed over his transfer request as Everton is set to buy him in the summer",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Dapo Osuntuyi",
      "screen_name" : "dappyboy0489",
      "indices" : [ "3", "16" ],
      "id_str" : "262836675",
      "id" : "262836675"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "458953353708703744",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "458953353708703744",
  "created_at" : "Wed Apr 23 12:59:41 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Dappyboy0489: David Moyes says Manchester United job was 'immense' as he thanks everyone BUT the players",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/EaRf3DJpfB",
      "expanded_url" : "http://www.411vibes.com/2014/04/see-health-benefits-of-cucumbers-must.html",
      "display_url" : "411vibes.com/2014/04/see-he…",
      "indices" : [ "49", "71" ]
    } ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "456745902258917376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456745902258917376",
  "possibly_sensitive" : false,
  "created_at" : "Thu Apr 17 10:48:03 +0000 2014",
  "favorited" : false,
  "full_text" : "SEE The Health Benefits Of Cucumbers (MUST READ) http://t.co/EaRf3DJpfB",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/r3H9wGq0vM",
      "expanded_url" : "http://www.411vibes.com/2014/04/former-miss-world-agbani-darego-stuns.html",
      "display_url" : "411vibes.com/2014/04/former…",
      "indices" : [ "61", "83" ]
    } ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "1",
  "id_str" : "456745608813228032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456745608813228032",
  "possibly_sensitive" : false,
  "created_at" : "Thu Apr 17 10:46:53 +0000 2014",
  "favorited" : false,
  "full_text" : "Former Miss World Agbani Darego stuns in make-up free photos http://t.co/r3H9wGq0vM",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/9RBh93VvcO",
      "expanded_url" : "http://bit.ly/1l6IAPu",
      "display_url" : "bit.ly/1l6IAPu",
      "indices" : [ "92", "114" ]
    } ]
  },
  "display_text_range" : [ "0", "114" ],
  "favorite_count" : "0",
  "id_str" : "456745396325597184",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456745396325597184",
  "possibly_sensitive" : false,
  "created_at" : "Thu Apr 17 10:46:03 +0000 2014",
  "favorited" : false,
  "full_text" : "Patience Jonathan Calls For Release Of Abducted Girls, Borno Govt. Offers N50M For Any Info http://t.co/9RBh93VvcO",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/IMrUcyqOwo",
      "expanded_url" : "http://www.411vibes.com/2014/04/photos-annie-idibia-returns-to-acting.html",
      "display_url" : "411vibes.com/2014/04/photos…",
      "indices" : [ "60", "82" ]
    } ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "456744848817913856",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456744848817913856",
  "possibly_sensitive" : false,
  "created_at" : "Thu Apr 17 10:43:52 +0000 2014",
  "favorited" : false,
  "full_text" : "PHOTOS: Annie Idibia Returns To Acting, Leaves Baby At Home http://t.co/IMrUcyqOwo",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/0ENSWuvYdt",
      "expanded_url" : "http://bit.ly/1m9xc4X",
      "display_url" : "bit.ly/1m9xc4X",
      "indices" : [ "88", "110" ]
    }, {
      "url" : "http://t.co/ea4Z4b5jKw",
      "expanded_url" : "http://www.thetrentonline.com/shes-12-hes-13-britains-youngest-ever-parents-pose-newborn-baby-photo/",
      "display_url" : "thetrentonline.com/shes-12-hes-13…",
      "indices" : [ "112", "134" ]
    } ]
  },
  "display_text_range" : [ "0", "134" ],
  "favorite_count" : "0",
  "id_str" : "456744572148670464",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456744572148670464",
  "possibly_sensitive" : false,
  "created_at" : "Thu Apr 17 10:42:46 +0000 2014",
  "favorited" : false,
  "full_text" : "She’s 12, He’s 13: Britain’s Youngest Ever Parents Pose With Their Newborn Baby (PHOTO) http://t.co/0ENSWuvYdt… http://t.co/ea4Z4b5jKw",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "id_str" : "456744290857664512",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456744290857664512",
  "created_at" : "Thu Apr 17 10:41:39 +0000 2014",
  "favorited" : false,
  "full_text" : "God's plan is bigger than your mistakes.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "456743963576532992",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456743963576532992",
  "created_at" : "Thu Apr 17 10:40:21 +0000 2014",
  "favorited" : false,
  "full_text" : "I'm not scared of commitment. I'm scared of who I commit to.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "456743857544515584",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456743857544515584",
  "created_at" : "Thu Apr 17 10:39:56 +0000 2014",
  "favorited" : false,
  "full_text" : "Snoop Doggs real name is Calvin Cordozar Broadus Jr.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "456743740451729408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456743740451729408",
  "created_at" : "Thu Apr 17 10:39:28 +0000 2014",
  "favorited" : false,
  "full_text" : "There's a bar in Ireland that opened in the year 900 A.D. and is still operational. It's named \"Sean's Bar\".",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "SARCASM!",
      "screen_name" : "FunnySayings",
      "indices" : [ "3", "16" ],
      "id_str" : "337502808",
      "id" : "337502808"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "456743625880121344",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456743625880121344",
  "created_at" : "Thu Apr 17 10:39:00 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @FunnySayings: school would be ok if it started at 2 in the afternoon and finished at 2 in the afternoon",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "456743568229400577",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456743568229400577",
  "created_at" : "Thu Apr 17 10:38:47 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: There will only be 7 planets left after I destroy Uranus.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "id_str" : "456569560951320577",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456569560951320577",
  "created_at" : "Wed Apr 16 23:07:20 +0000 2014",
  "favorited" : false,
  "full_text" : "A group of ferrets is called a business.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "456569509839511554",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456569509839511554",
  "created_at" : "Wed Apr 16 23:07:08 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: It's better to know and be disappointed than to never know and always wonder.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "456569507922731008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456569507922731008",
  "created_at" : "Wed Apr 16 23:07:08 +0000 2014",
  "favorited" : false,
  "full_text" : "Never say God I have a problem, say problem I have a God!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mana Ionescu",
      "screen_name" : "manamica",
      "indices" : [ "3", "12" ],
      "id_str" : "13520532",
      "id" : "13520532"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "456569400145895424",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456569400145895424",
  "created_at" : "Wed Apr 16 23:06:42 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @manamica: \"Be yourself; everyone else is already taken.\" - Oscar Wilde",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    }, {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "116", "129" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ {
      "url" : "http://t.co/3L0xSCWewM",
      "expanded_url" : "http://bit.ly/PQV3ca",
      "display_url" : "bit.ly/PQV3ca",
      "indices" : [ "89", "111" ]
    } ]
  },
  "display_text_range" : [ "0", "129" ],
  "favorite_count" : "0",
  "id_str" : "456477694406840321",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456477694406840321",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 16 17:02:17 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: Details Of Crimes Committed By Gaddafi Are Depicted In New Documentary http://t.co/3L0xSCWewM Via @AllAroundNig",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wole Soyinka",
      "screen_name" : "MrWoleSoyinka",
      "indices" : [ "3", "17" ],
      "id_str" : "761869446923321345",
      "id" : "761869446923321345"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "0",
  "id_str" : "411744828331163648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411744828331163648",
  "created_at" : "Sat Dec 14 06:29:51 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @MrWoleSoyinka: Be a lady first before u become the FIRST lady.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wole Soyinka",
      "screen_name" : "MrWoleSoyinka",
      "indices" : [ "3", "17" ],
      "id_str" : "761869446923321345",
      "id" : "761869446923321345"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "411744658164039680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411744658164039680",
  "created_at" : "Sat Dec 14 06:29:11 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @MrWoleSoyinka: Any money you can't forgive and forget do not borrow it out.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wole Soyinka",
      "screen_name" : "MrWoleSoyinka",
      "indices" : [ "3", "17" ],
      "id_str" : "761869446923321345",
      "id" : "761869446923321345"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "411744532171337728",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411744532171337728",
  "created_at" : "Sat Dec 14 06:28:40 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @MrWoleSoyinka: Happiness Dwells From Within. If You Think You're Sad, You'll Be Sad",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wole Soyinka",
      "screen_name" : "MrWoleSoyinka",
      "indices" : [ "3", "17" ],
      "id_str" : "761869446923321345",
      "id" : "761869446923321345"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "411744462529118208",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411744462529118208",
  "created_at" : "Sat Dec 14 06:28:24 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @MrWoleSoyinka: Pharaoh culdnt stop Moses, Saul culdnt stop David from d Throne, Satan culdnt stop Jesus, May no obstacle Stop u dis wee…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "114" ],
  "favorite_count" : "0",
  "id_str" : "411744059645251584",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411744059645251584",
  "created_at" : "Sat Dec 14 06:26:48 +0000 2013",
  "favorited" : false,
  "full_text" : "The best and most beautiful things\nin the world cannot be seen or\neven touched - they must be felt\nwith the heart.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "411743273766883328",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411743273766883328",
  "created_at" : "Sat Dec 14 06:23:40 +0000 2013",
  "favorited" : false,
  "full_text" : "Never wear anything that panics\nthe cat. ;)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "411742858220429312",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411742858220429312",
  "created_at" : "Sat Dec 14 06:22:01 +0000 2013",
  "favorited" : false,
  "full_text" : "The sky is the part of creation in\nwhich nature has done for the\nsake of pleasing man.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "0",
  "id_str" : "411742476987535360",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411742476987535360",
  "created_at" : "Sat Dec 14 06:20:30 +0000 2013",
  "favorited" : false,
  "full_text" : "Wisdom outweighs any wealth.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "411742085243744256",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411742085243744256",
  "created_at" : "Sat Dec 14 06:18:57 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: I love you... Don't ever question that.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "411741819987562496",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411741819987562496",
  "created_at" : "Sat Dec 14 06:17:54 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: It's hard to beat a person who never gives up.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OMGFacts",
      "screen_name" : "OMGFacts",
      "indices" : [ "3", "12" ],
      "id_str" : "77888423",
      "id" : "77888423"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "411741555138252800",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411741555138252800",
  "created_at" : "Sat Dec 14 06:16:51 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @OMGFacts: One person out of every 20 people is born with an extra rib.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wild Jessy",
      "screen_name" : "SlackBeelermdh",
      "indices" : [ "3", "18" ],
      "id_str" : "350763604",
      "id" : "350763604"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "411500653081415680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411500653081415680",
  "created_at" : "Fri Dec 13 14:19:35 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @SlackBeelermdh: Don't give up on things that make you smile.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "411499321150808064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411499321150808064",
  "created_at" : "Fri Dec 13 14:14:18 +0000 2013",
  "favorited" : false,
  "full_text" : "If the facts don't fit the\ntheory, change the facts.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "411498388530544640",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411498388530544640",
  "created_at" : "Fri Dec 13 14:10:35 +0000 2013",
  "favorited" : false,
  "full_text" : "Do not take life too\nseriously. You will never get\nout of it alive.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "411498106023206912",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411498106023206912",
  "created_at" : "Fri Dec 13 14:09:28 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Dimples are considered to be a \"facial muscle deformity.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "135" ],
  "favorite_count" : "0",
  "id_str" : "411497991602577408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411497991602577408",
  "created_at" : "Fri Dec 13 14:09:01 +0000 2013",
  "favorited" : false,
  "full_text" : "I believe that if life gives u\nlemons, u should make\nlemonade.And try to find\nsomebody whose life has\ngiven them vodka and have\na party",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "411496131797864448",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411496131797864448",
  "created_at" : "Fri Dec 13 14:01:37 +0000 2013",
  "favorited" : false,
  "full_text" : "Sometimes the heart sees\nwhat is invisible to the eye.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "411494058905726976",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411494058905726976",
  "created_at" : "Fri Dec 13 13:53:23 +0000 2013",
  "favorited" : false,
  "full_text" : "We are all here on earth\nto help others; what on\nearth the others are here\nfor I don't know.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "39" ],
  "favorite_count" : "0",
  "id_str" : "411493723034222595",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411493723034222595",
  "created_at" : "Fri Dec 13 13:52:03 +0000 2013",
  "favorited" : false,
  "full_text" : "The desire to write grows\nwith writing.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "411493651164831747",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411493651164831747",
  "created_at" : "Fri Dec 13 13:51:46 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: We was young and we was dumb, but we had heart. - Tupac",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "411487944848211968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411487944848211968",
  "created_at" : "Fri Dec 13 13:29:05 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: The answer lies within ourselves. If we can't find peace and happiness there, it's not going to come from the outside. - Te…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wild Jessy",
      "screen_name" : "SlackBeelermdh",
      "indices" : [ "3", "18" ],
      "id_str" : "350763604",
      "id" : "350763604"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "411486885744508928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411486885744508928",
  "created_at" : "Fri Dec 13 13:24:53 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @SlackBeelermdh: Stop over thinking, stop worrying, stop complaining. Life is too short for all that.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "411042331190890496",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411042331190890496",
  "created_at" : "Thu Dec 12 07:58:23 +0000 2013",
  "favorited" : false,
  "full_text" : "The only Zen you can find on the tops of\nmountains is the Zen you bring up there.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "411042069323714560",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411042069323714560",
  "created_at" : "Thu Dec 12 07:57:20 +0000 2013",
  "favorited" : false,
  "full_text" : "The finest steel has to go through the hottest\nfire.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "id_str" : "411039367105626112",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411039367105626112",
  "created_at" : "Thu Dec 12 07:46:36 +0000 2013",
  "favorited" : false,
  "full_text" : "Quarrels end, but words once spoken never die.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Male Thoughts",
      "screen_name" : "TheComedyHumor",
      "indices" : [ "3", "18" ],
      "id_str" : "32688098",
      "id" : "32688098"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "411037661030539264",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "411037661030539264",
  "created_at" : "Thu Dec 12 07:39:49 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheComedyHumor: Things to do today:\n\n1) Get up.\n\n2) Survive.\n\n3) Go back to bed",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "410520313110466560",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "410520313110466560",
  "created_at" : "Tue Dec 10 21:24:04 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Minds are like parachutes - they only function when open. -Thomas Dewar",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "105" ],
  "favorite_count" : "0",
  "id_str" : "410519581657415680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "410519581657415680",
  "created_at" : "Tue Dec 10 21:21:10 +0000 2013",
  "favorited" : false,
  "full_text" : "Don’t let life discourage you; everyone who got where he is\nhad to begin where he was. — Richard L. Evans",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Kabs_Cebekhulu",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "410516997508964352",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "410516997508964352",
  "created_at" : "Tue Dec 10 21:10:53 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Kabs_Cebekhulu: FEAR- Forget Err'Thang And Run",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "85" ],
  "favorite_count" : "0",
  "id_str" : "410515343489380352",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "410515343489380352",
  "created_at" : "Tue Dec 10 21:04:19 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: Being a person is getting too complicated. Time to be a unicorn.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "id_str" : "410515062110306304",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "410515062110306304",
  "created_at" : "Tue Dec 10 21:03:12 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: You’re like the lyrics to my favorite song, hard to forget and always on my mind.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "11" ],
  "favorite_count" : "0",
  "id_str" : "409797509209673728",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "409797509209673728",
  "created_at" : "Sun Dec 08 21:31:54 +0000 2013",
  "favorited" : false,
  "full_text" : "All iz well",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "408957034034655232",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408957034034655232",
  "created_at" : "Fri Dec 06 13:52:09 +0000 2013",
  "favorited" : false,
  "full_text" : "Second chances aren't always a guarantee, so use your first chance wisely.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "45" ],
  "favorite_count" : "0",
  "id_str" : "408925564003950592",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408925564003950592",
  "created_at" : "Fri Dec 06 11:47:06 +0000 2013",
  "favorited" : false,
  "full_text" : "If you love someone, dont let them slip away.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "408919677667393536",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408919677667393536",
  "created_at" : "Fri Dec 06 11:23:43 +0000 2013",
  "favorited" : false,
  "full_text" : "\"You play my heart like it's a game\" - Demi Lovato",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "408906176227975168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408906176227975168",
  "created_at" : "Fri Dec 06 10:30:04 +0000 2013",
  "favorited" : false,
  "full_text" : "Never break down for someone who won't stand up for you...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Common White Girl",
      "screen_name" : "damnitstrue",
      "indices" : [ "3", "15" ],
      "id_str" : "66714703",
      "id" : "66714703"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "85" ],
  "favorite_count" : "0",
  "id_str" : "408870462987321345",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408870462987321345",
  "created_at" : "Fri Dec 06 08:08:09 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @damnitstrue: We all have a friend who always thinks of everything in a dirty way.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "117" ],
  "favorite_count" : "0",
  "id_str" : "408816366112997377",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408816366112997377",
  "created_at" : "Fri Dec 06 04:33:11 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: By being yourself, you put something wonderful in the world that was not there before. - Edwin Elliot",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "408732556398706688",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408732556398706688",
  "created_at" : "Thu Dec 05 23:00:09 +0000 2013",
  "favorited" : false,
  "full_text" : "Never underestimate the pain of a\nperson, everyone is struggling. Just\nsome people are better at hiding it\nthan others.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "84" ],
  "favorite_count" : "0",
  "id_str" : "408732469215895552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408732469215895552",
  "created_at" : "Thu Dec 05 22:59:49 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: There isn’t a word in the dictionary to describe how good you look.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "36" ],
  "favorite_count" : "0",
  "id_str" : "408575201153384448",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "408575201153384448",
  "created_at" : "Thu Dec 05 12:34:53 +0000 2013",
  "favorited" : false,
  "full_text" : "A goal without a plan is just a wish",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "408570670575284224",
  "id_str" : "408571520131166208",
  "in_reply_to_user_id" : "2187949042",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408571520131166208",
  "in_reply_to_status_id" : "408570670575284224",
  "created_at" : "Thu Dec 05 12:20:15 +0000 2013",
  "favorited" : false,
  "full_text" : "I'm   fine   thanx...   @nonkulu94115960",
  "lang" : "en",
  "in_reply_to_screen_name" : "Nonkuh_Memela",
  "in_reply_to_user_id_str" : "2187949042"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "407987283619745792",
  "id_str" : "408566734598057984",
  "in_reply_to_user_id" : "1896623816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408566734598057984",
  "in_reply_to_status_id" : "407987283619745792",
  "created_at" : "Thu Dec 05 12:01:14 +0000 2013",
  "favorited" : false,
  "full_text" : "@kabs_cebekhulu :)   ;)",
  "lang" : "und",
  "in_reply_to_user_id_str" : "1896623816"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "KaBs_Cebekhulu",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "408566379608948737",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408566379608948737",
  "created_at" : "Thu Dec 05 11:59:50 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KaBs_Cebekhulu: I Think Like An Adult But Run Around like A Free Child :)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "408539508565868544",
  "id_str" : "408566164235636736",
  "in_reply_to_user_id" : "2187949042",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408566164235636736",
  "in_reply_to_status_id" : "408539508565868544",
  "created_at" : "Thu Dec 05 11:58:59 +0000 2013",
  "favorited" : false,
  "full_text" : "@nonkulu94115960 hi,  how   are   you   doing?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Nonkuh_Memela",
  "in_reply_to_user_id_str" : "2187949042"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "modemusic",
      "indices" : [ "104", "114" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Neeggaboy",
      "indices" : [ "3", "13" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "126" ],
  "favorite_count" : "0",
  "id_str" : "408539476353630208",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408539476353630208",
  "created_at" : "Thu Dec 05 10:12:56 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Neeggaboy: I'm standing tall, I deserve a tallership.. my haterz falling, they deserve a fallership #modemusic DNA-RECORDS",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Neeggaboy",
      "indices" : [ "3", "13" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "408539301061099520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408539301061099520",
  "created_at" : "Thu Dec 05 10:12:14 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Neeggaboy: When she ignores you, she wants you to give her attention.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "33" ],
  "favorite_count" : "0",
  "id_str" : "408223276956393472",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408223276956393472",
  "created_at" : "Wed Dec 04 13:16:28 +0000 2013",
  "favorited" : false,
  "full_text" : "As you think, so shall you become",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "45" ],
  "favorite_count" : "0",
  "id_str" : "408223105182867457",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "408223105182867457",
  "created_at" : "Wed Dec 04 13:15:47 +0000 2013",
  "favorited" : false,
  "full_text" : "Questions exist so that they can be answered.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "id_str" : "407986563050917888",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407986563050917888",
  "created_at" : "Tue Dec 03 21:35:51 +0000 2013",
  "favorited" : false,
  "full_text" : "In God I trust.. GOODNYT...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "407985542765510656",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407985542765510656",
  "created_at" : "Tue Dec 03 21:31:48 +0000 2013",
  "favorited" : false,
  "full_text" : "Nothing should hold a man back from his destiny, future starts now - Akolade Moses",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "407984464099147776",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407984464099147776",
  "created_at" : "Tue Dec 03 21:27:30 +0000 2013",
  "favorited" : false,
  "full_text" : "Success is like wild animal, if you dont tame it, it can tear you - Familugba Seun",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "33" ],
  "favorite_count" : "0",
  "id_str" : "407964957607997440",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407964957607997440",
  "created_at" : "Tue Dec 03 20:10:00 +0000 2013",
  "favorited" : false,
  "full_text" : "Odontophobia is the fear of teeth",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "25" ],
  "favorite_count" : "0",
  "id_str" : "407964243733266432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407964243733266432",
  "created_at" : "Tue Dec 03 20:07:09 +0000 2013",
  "favorited" : false,
  "full_text" : "....forever and always...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "407958532701814784",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "407958532701814784",
  "created_at" : "Tue Dec 03 19:44:28 +0000 2013",
  "favorited" : false,
  "full_text" : "Music is powerful enough to change a persons perception of the world.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "407956576344211457",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407956576344211457",
  "created_at" : "Tue Dec 03 19:36:41 +0000 2013",
  "favorited" : false,
  "full_text" : "In him was life, and that life was the light of men. John 1:4",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "407955806026752000",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407955806026752000",
  "created_at" : "Tue Dec 03 19:33:38 +0000 2013",
  "favorited" : false,
  "full_text" : "laughter is the brush that sweeps away the cobwebs of your heart. - Mort Walker",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "407952469856370688",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407952469856370688",
  "created_at" : "Tue Dec 03 19:20:22 +0000 2013",
  "favorited" : false,
  "full_text" : "you are more likely to memorize what you've written, if you wrote in blue ink",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "22" ],
  "favorite_count" : "0",
  "id_str" : "407949937864085504",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407949937864085504",
  "created_at" : "Tue Dec 03 19:10:19 +0000 2013",
  "favorited" : false,
  "full_text" : "never go to bed angry.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "0",
  "id_str" : "407945268815208449",
  "in_reply_to_user_id" : "1896623816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407945268815208449",
  "created_at" : "Tue Dec 03 18:51:46 +0000 2013",
  "favorited" : false,
  "full_text" : "@KaBs_Cebekhulu lolz... Im one too ;-)",
  "lang" : "en",
  "in_reply_to_screen_name" : "Kabs_Cebekhulu",
  "in_reply_to_user_id_str" : "1896623816"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "0", "6" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "407942195397029888",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407942195397029888",
  "created_at" : "Tue Dec 03 18:39:33 +0000 2013",
  "favorited" : false,
  "full_text" : "#Virgo's can be very testy and short fused. You don't want to annoy one",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "407863922109472768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407863922109472768",
  "created_at" : "Tue Dec 03 13:28:31 +0000 2013",
  "favorited" : false,
  "full_text" : "Even fools seem smart when they are quiet - Proverb 17:28",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "102" ],
  "favorite_count" : "0",
  "id_str" : "407858593321713665",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407858593321713665",
  "created_at" : "Tue Dec 03 13:07:20 +0000 2013",
  "favorited" : false,
  "full_text" : "The human body has 7 trillion nerves and some people manage to get on every single fucking one of them",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "407854751154728960",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "407854751154728960",
  "created_at" : "Tue Dec 03 12:52:04 +0000 2013",
  "favorited" : false,
  "full_text" : "You must be an adverb, because you sure do modify me!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "0",
  "id_str" : "407853369169285120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407853369169285120",
  "created_at" : "Tue Dec 03 12:46:35 +0000 2013",
  "favorited" : false,
  "full_text" : "Lose yourself in nature and find peace",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "407850133876113408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407850133876113408",
  "created_at" : "Tue Dec 03 12:33:44 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Dear whoever is reading this, you are beautiful and perfect in every way. Smile, because you're too amazing to be so sa…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "32" ],
  "favorite_count" : "0",
  "id_str" : "407844974957690880",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407844974957690880",
  "created_at" : "Tue Dec 03 12:13:14 +0000 2013",
  "favorited" : false,
  "full_text" : "There's more to life than riches",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Tweets  ☔️\uD83C\uDF28☃️",
      "screen_name" : "iQuoteComedy",
      "indices" : [ "3", "16" ],
      "id_str" : "27022925",
      "id" : "27022925"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "407734283004936192",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407734283004936192",
  "created_at" : "Tue Dec 03 04:53:23 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @iQuoteComedy: youre as annoying as an app that turns sideways when you lie down",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "407734132915978240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407734132915978240",
  "created_at" : "Tue Dec 03 04:52:47 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: There are five types of fear. 1. terror 2: panic 3. 14 missed calls from mom 4: username or password is incorrect 5. w…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mother Teresa",
      "screen_name" : "StMotherTheresa",
      "indices" : [ "3", "19" ],
      "id_str" : "35274401",
      "id" : "35274401"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "124" ],
  "favorite_count" : "0",
  "id_str" : "407729457508536320",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407729457508536320",
  "created_at" : "Tue Dec 03 04:34:12 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @StMotherTheresa: \"If you are humble nothing will touch you, neither praise nor disgrace, because you know what you are.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "136" ],
  "favorite_count" : "0",
  "id_str" : "407727779958910977",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407727779958910977",
  "created_at" : "Tue Dec 03 04:27:32 +0000 2013",
  "favorited" : false,
  "full_text" : "Dont feel sad over someone who\ngave up on you, feel sorry for them\nbecause they gave up on someone\nwho would have never given up on\nthem",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "89" ],
  "favorite_count" : "0",
  "id_str" : "407726926602575873",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407726926602575873",
  "created_at" : "Tue Dec 03 04:24:09 +0000 2013",
  "favorited" : false,
  "full_text" : "Ignore the negative things you can't\nchange. Change the negative things\nyou can't ignore.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "68" ],
  "favorite_count" : "0",
  "id_str" : "407365079097946112",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407365079097946112",
  "created_at" : "Mon Dec 02 04:26:17 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Thantophobia, the fear of losing someone you love.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgos",
      "indices" : [ "19", "26" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ZodiacFact",
      "screen_name" : "ZodiacFacts",
      "indices" : [ "3", "15" ],
      "id_str" : "125786481",
      "id" : "125786481"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "407358212997132288",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407358212997132288",
  "created_at" : "Mon Dec 02 03:59:00 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ZodiacFacts: A #Virgos Biggest Insecurities: Lack in self-esteem and being useless.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "407357953709461505",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407357953709461505",
  "created_at" : "Mon Dec 02 03:57:59 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Avoy! - An expression of fear; surprise.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Emyzz14",
      "indices" : [ "3", "11" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "407352367617941504",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407352367617941504",
  "created_at" : "Mon Dec 02 03:35:47 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Emyzz14: sometimes couples need to reassure their partner what y'all want.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "407349241217306624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407349241217306624",
  "created_at" : "Mon Dec 02 03:23:21 +0000 2013",
  "favorited" : false,
  "full_text" : "Keep your friends close, but the people who have a chance at becoming famous closer",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "common penis™",
      "screen_name" : "CommonCock",
      "indices" : [ "3", "14" ],
      "id_str" : "1234375411",
      "id" : "1234375411"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "407224432285855744",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407224432285855744",
  "created_at" : "Sun Dec 01 19:07:25 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @CommonCock: Life is like a penis, very simple, relaxed and just hanging freely. It's women who make it hard",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "52", "58" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Ｖｉｒｇｏ",
      "screen_name" : "VirgoNation",
      "indices" : [ "3", "15" ],
      "id_str" : "271219664",
      "id" : "271219664"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "407220700051566592",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407220700051566592",
  "created_at" : "Sun Dec 01 18:52:35 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @VirgoNation: Just one stupid comment can piss a #Virgo off.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "RIPPAULWALKER",
      "indices" : [ "0", "14" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "14" ],
  "favorite_count" : "0",
  "id_str" : "407081655254282240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407081655254282240",
  "created_at" : "Sun Dec 01 09:40:04 +0000 2013",
  "favorited" : false,
  "full_text" : "#RIPPAULWALKER",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Paul Walker",
      "screen_name" : "RealPaulWalker",
      "indices" : [ "3", "18" ],
      "id_str" : "197034645",
      "id" : "197034645"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "407080170630021120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "407080170630021120",
  "created_at" : "Sun Dec 01 09:34:10 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @RealPaulWalker: It's with a heavy heart that we must confirm Paul Walker passed away today in a tragic car accident...MORE: http://t.co…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "KaBs_Cebekhulu",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "406778239794044929",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406778239794044929",
  "created_at" : "Sat Nov 30 13:34:24 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KaBs_Cebekhulu: Be Strong Enough To Wαlk αwαy From Things or People Thαt Cαnt Put α Smile On Your Fαce No mαtter how Close You αre To t…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Hustling Boss",
      "screen_name" : "BossHustling",
      "indices" : [ "3", "16" ],
      "id_str" : "1070271646697775104",
      "id" : "1070271646697775104"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "406777635952263168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406777635952263168",
  "created_at" : "Sat Nov 30 13:32:00 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BossHustling: I may not be there yet, but I'm closer than I was yesterday.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "129" ],
  "favorite_count" : "0",
  "id_str" : "406777544491274242",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406777544491274242",
  "created_at" : "Sat Nov 30 13:31:38 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Forgiving others can help you to move on from the past and release yourself from negative emotions and thoughts.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Retarded Mom",
      "screen_name" : "unusuaifactpage",
      "indices" : [ "3", "19" ],
      "id_str" : "2478045696",
      "id" : "2478045696"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "406777160234328064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406777160234328064",
  "created_at" : "Sat Nov 30 13:30:07 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @UnusuaIFactPage: When a person cries and the first drop of tears comes from the right eye; It's happiness. If it's from the left, It's …",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "45" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "406104543383269377",
  "id_str" : "406776929866375168",
  "in_reply_to_user_id" : "1896623816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406776929866375168",
  "in_reply_to_status_id" : "406104543383269377",
  "created_at" : "Sat Nov 30 13:29:12 +0000 2013",
  "favorited" : false,
  "full_text" : "@kabs_cebekhulu sick? Have yew been to a doc?",
  "lang" : "en",
  "in_reply_to_user_id_str" : "1896623816"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "39" ],
  "favorite_count" : "0",
  "id_str" : "406038382675243008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406038382675243008",
  "created_at" : "Thu Nov 28 12:34:28 +0000 2013",
  "favorited" : false,
  "full_text" : "The less you know, the more you believe",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "111" ],
  "favorite_count" : "0",
  "id_str" : "406036280129372160",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406036280129372160",
  "created_at" : "Thu Nov 28 12:26:07 +0000 2013",
  "favorited" : false,
  "full_text" : "Dear God, I wanna take a minute, not to ask for anything from you. But simply to say thank you, for all I have.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "0",
  "id_str" : "406035597426720768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406035597426720768",
  "created_at" : "Thu Nov 28 12:23:24 +0000 2013",
  "favorited" : false,
  "full_text" : "All that we are is a result of what we have thought",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "42" ],
  "favorite_count" : "0",
  "id_str" : "406032403212554241",
  "in_reply_to_user_id" : "1896623816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406032403212554241",
  "created_at" : "Thu Nov 28 12:10:43 +0000 2013",
  "favorited" : false,
  "full_text" : "@KaBs_Cebekhulu thanx... I'm good &amp; u?",
  "lang" : "en",
  "in_reply_to_user_id_str" : "1896623816"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "88" ],
  "favorite_count" : "0",
  "id_str" : "406032115890130944",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "406032115890130944",
  "created_at" : "Thu Nov 28 12:09:34 +0000 2013",
  "favorited" : false,
  "full_text" : "Your desire for success must always be greater than any obstacle that stands in your way",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "id_str" : "405824918232657921",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "405824918232657921",
  "created_at" : "Wed Nov 27 22:26:15 +0000 2013",
  "favorited" : false,
  "full_text" : "Learn to forgive and let go",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "405510556364591104",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "405510556364591104",
  "created_at" : "Wed Nov 27 01:37:05 +0000 2013",
  "favorited" : false,
  "full_text" : "Quote ...people find it far easier to forgive others for being wrong than being right. - - J. K. Rowling",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "22" ],
  "favorite_count" : "0",
  "id_str" : "404929151582625792",
  "in_reply_to_user_id" : "1896623816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "404929151582625792",
  "created_at" : "Mon Nov 25 11:06:47 +0000 2013",
  "favorited" : false,
  "full_text" : "@kabs_cebekhulu ff baQ",
  "lang" : "en",
  "in_reply_to_user_id_str" : "1896623816"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "116" ],
  "favorite_count" : "0",
  "id_str" : "404927818653782016",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "404927818653782016",
  "created_at" : "Mon Nov 25 11:01:29 +0000 2013",
  "favorited" : false,
  "full_text" : "U may shoot me with ur words u\nmay cut me wit ur eyes u may kill me wit ur hatefulness\nbut still like air, I\"ll riSe",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "403550638178836480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403550638178836480",
  "created_at" : "Thu Nov 21 15:49:04 +0000 2013",
  "favorited" : false,
  "full_text" : "Note to self: \"dont worry, if it's suppose to happen, it will.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "403258883697016832",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403258883697016832",
  "created_at" : "Wed Nov 20 20:29:44 +0000 2013",
  "favorited" : false,
  "full_text" : "Every saint has a past. Every sinner has a future.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "68" ],
  "favorite_count" : "0",
  "id_str" : "403258415742742528",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403258415742742528",
  "created_at" : "Wed Nov 20 20:27:53 +0000 2013",
  "favorited" : false,
  "full_text" : "I get mad, I get worried, I get curious. That's only because I care!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "403251961224769537",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403251961224769537",
  "created_at" : "Wed Nov 20 20:02:14 +0000 2013",
  "favorited" : false,
  "full_text" : "when you give thanks for everything in your life- you become a magnet for blessing! - Paula white",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "403024368466685952",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403024368466685952",
  "created_at" : "Wed Nov 20 04:57:51 +0000 2013",
  "favorited" : false,
  "full_text" : "Nobody who ever gave his best regretted it. - George Halas",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "95" ],
  "favorite_count" : "0",
  "id_str" : "403024137339555840",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403024137339555840",
  "created_at" : "Wed Nov 20 04:56:56 +0000 2013",
  "favorited" : false,
  "full_text" : "You'll be surprised to know how far you can go from the point where you thought it was the end.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "101" ],
  "favorite_count" : "0",
  "id_str" : "403022675712692224",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403022675712692224",
  "created_at" : "Wed Nov 20 04:51:08 +0000 2013",
  "favorited" : false,
  "full_text" : "I DONT SLOW DOWN, I DONT GIVE UP......I KEEP MOVING FORWARD AND WALK IN THE GRACE AND LOVE OF JESUS.…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "403022159054123008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403022159054123008",
  "created_at" : "Wed Nov 20 04:49:05 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: I hate to see you go, but I love watching you leave.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "17", "23" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "403022017815121920",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "403022017815121920",
  "created_at" : "Wed Nov 20 04:48:31 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: #Virgo needs to learn how to relax and let life happen spontaneously.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "StanJames",
      "indices" : [ "45", "55" ]
    }, {
      "text" : "twitter92",
      "indices" : [ "102", "112" ]
    }, {
      "text" : "FreeBet",
      "indices" : [ "113", "121" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Betting Offers",
      "screen_name" : "Freebetnow",
      "indices" : [ "3", "14" ],
      "id_str" : "1399846022",
      "id" : "1399846022"
    } ],
    "urls" : [ {
      "url" : "http://t.co/yVr3o64qoG",
      "expanded_url" : "http://bit.ly/STANJAMES",
      "display_url" : "bit.ly/STANJAMES",
      "indices" : [ "79", "101" ]
    } ]
  },
  "display_text_range" : [ "0", "121" ],
  "favorite_count" : "0",
  "id_str" : "402963023729790976",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402963023729790976",
  "possibly_sensitive" : false,
  "created_at" : "Wed Nov 20 00:54:06 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Freebetnow: BET £10 GET A EXTRA £10 with #StanJames - Click Here Sign Up - http://t.co/yVr3o64qoG #twitter92 #FreeBet",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ⒹⒿ ₮.Ṁ♨ᾗ€¥(LEGAL NOW",
      "screen_name" : "MasiveFyahSound",
      "indices" : [ "3", "19" ],
      "id_str" : "42021937",
      "id" : "42021937"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "402962166246297600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402962166246297600",
  "created_at" : "Wed Nov 20 00:50:41 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @MasiveFyahSound: TEACHER JUST ASK THIS NIGGA IF HE LIL BRO CUT HE HAIR LOL",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/Q6strtfVph",
      "expanded_url" : "http://tl.gd/mv93g7",
      "display_url" : "tl.gd/mv93g7",
      "indices" : [ "107", "129" ]
    } ]
  },
  "display_text_range" : [ "0", "129" ],
  "favorite_count" : "0",
  "id_str" : "402961833461829633",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402961833461829633",
  "possibly_sensitive" : false,
  "created_at" : "Wed Nov 20 00:49:22 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @MrOsuofia   Half naked girls are hot,while well dressed girls are beautiful...Hell is hot,while (cont) http://t.co/Q6strtfVph",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "402942983261409280",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402942983261409280",
  "created_at" : "Tue Nov 19 23:34:28 +0000 2013",
  "favorited" : false,
  "full_text" : "Continuous effort! not strength or intelligence, is the key to unlocking your potential. - Winston Churchill",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "89" ],
  "favorite_count" : "0",
  "id_str" : "402908420170608640",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402908420170608640",
  "created_at" : "Tue Nov 19 21:17:07 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Life is happy enough when you see every single thing optimistically.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "402907922394796032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402907922394796032",
  "created_at" : "Tue Nov 19 21:15:09 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Can I have a picture of you so I can show Santa what I want for Christmas?",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Melyssa Moniz",
      "screen_name" : "melyssamoniz",
      "indices" : [ "3", "16" ],
      "id_str" : "276271616",
      "id" : "276271616"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "402907876832055297",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402907876832055297",
  "created_at" : "Tue Nov 19 21:14:58 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @MelyssaMoniz: I believe the only way we will heal ourselves and others is to make the choice to relate.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Rafaqat Ali #WWW.ALRATV.UK",
      "screen_name" : "rafu007",
      "indices" : [ "3", "11" ],
      "id_str" : "7278922",
      "id" : "7278922"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "402907805310787584",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402907805310787584",
  "created_at" : "Tue Nov 19 21:14:41 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @rafu007: It is the Spiritual Teacher who maintains the Spiritual System in the religion.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "fastone_36",
      "indices" : [ "3", "14" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "402907661710397441",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402907661710397441",
  "created_at" : "Tue Nov 19 21:14:06 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @fastone_36: - It's really nice when you can just think about someone, and smile...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "CuteLoveMsgs",
      "indices" : [ "3", "16" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "402907577832730624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402907577832730624",
  "created_at" : "Tue Nov 19 21:13:46 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @CuteLoveMsgs: Reading old messages and realizing how much you miss that person.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "115" ],
  "favorite_count" : "0",
  "id_str" : "402893615003090944",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402893615003090944",
  "created_at" : "Tue Nov 19 20:18:17 +0000 2013",
  "favorited" : false,
  "full_text" : "You don't change people's mind by the words you speak, but you inspire change in their hearts by the life you live.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LIFE QUOTES",
      "screen_name" : "ItsLifeFact",
      "indices" : [ "3", "15" ],
      "id_str" : "396086694",
      "id" : "396086694"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "402893450846404608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402893450846404608",
  "created_at" : "Tue Nov 19 20:17:38 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ItsLifeFact: Don't say what you don't mean.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "tete_namaste",
      "indices" : [ "3", "16" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "402893361520340992",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402893361520340992",
  "created_at" : "Tue Nov 19 20:17:17 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @tete_namaste: \"What is in our deal, also can not do it.\" Aristoteles",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "fake9JAnews",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ {
      "url" : "http://t.co/nqe3oNdZFD",
      "expanded_url" : "http://bit.ly/17ETepE",
      "display_url" : "bit.ly/17ETepE",
      "indices" : [ "105", "127" ]
    } ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "0",
  "id_str" : "402893237876441088",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402893237876441088",
  "possibly_sensitive" : false,
  "created_at" : "Tue Nov 19 20:16:47 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @fake9JAnews: Patience Jonathan To Start Her Own Reality Tv Series ” THE REAL HOUSEWIVES OF ASO ROCK” http://t.co/nqe3oNdZFD",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "402663119119736832",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402663119119736832",
  "created_at" : "Tue Nov 19 05:02:23 +0000 2013",
  "favorited" : false,
  "full_text" : "\"If you don't have passion for something,y you shouldn't be doing it in the first place\" - Lee Alexander McQueen",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Naija Tunez \uD83E\uDD85\uD83C\uDDF3\uD83C\uDDEC\uD83C\uDFB5",
      "screen_name" : "NaijaTunez",
      "indices" : [ "3", "14" ],
      "id_str" : "709117160",
      "id" : "709117160"
    }, {
      "name" : "IDj At #SolidFm #RaveFm #RainbowFm IG @Djchascolee",
      "screen_name" : "djchascolee",
      "indices" : [ "101", "113" ],
      "id_str" : "147753831",
      "id" : "147753831"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "402398972268265473",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402398972268265473",
  "created_at" : "Mon Nov 18 11:32:45 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @NaijaTuneZ: Turnable,Radio,Club &amp; Mr ShutDownPartyDj,Multiple Award Winner,Rainbow 94.1FM Dj @Djchascolee 4Bookings:PIN 2959635A #Event…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "oneofmyfavouritemovieIs",
      "indices" : [ "0", "24" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "402378447278067713",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402378447278067713",
  "created_at" : "Mon Nov 18 10:11:12 +0000 2013",
  "favorited" : false,
  "full_text" : "#oneofmyfavouritemovieIs Vampire dairies...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "115" ],
  "favorite_count" : "0",
  "id_str" : "402376699507404800",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402376699507404800",
  "created_at" : "Mon Nov 18 10:04:15 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: \"What do you do when you can't control your anger?\"\n\n\"Let your anger out, but then let it go.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "402376468409622528",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402376468409622528",
  "created_at" : "Mon Nov 18 10:03:20 +0000 2013",
  "favorited" : false,
  "full_text" : "Knowledge without wisdom is like water in the sand",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "NotCommonFactz",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "402374228902961152",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402374228902961152",
  "created_at" : "Mon Nov 18 09:54:26 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @NotCommonFactz: If you want to feel good about yourself, you first have to give yourself something to feel good about. Actions define s…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "MorningRuns",
      "indices" : [ "52", "64" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Naija102.7",
      "screen_name" : "Naija102FM",
      "indices" : [ "3", "14" ],
      "id_str" : "338301147",
      "id" : "338301147"
    }, {
      "name" : "PRAIZ \uD83D\uDC51",
      "screen_name" : "Praiz8",
      "indices" : [ "27", "34" ],
      "id_str" : "126571944",
      "id" : "126571944"
    }, {
      "name" : "AwiloLongomba",
      "screen_name" : "AwiloLongomba",
      "indices" : [ "37", "51" ],
      "id_str" : "1630890110",
      "id" : "1630890110"
    }, {
      "name" : "Godwin Aruwayo",
      "screen_name" : "GodwinAruwayo",
      "indices" : [ "67", "81" ],
      "id_str" : "226840142",
      "id" : "226840142"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "402374089656254464",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "402374089656254464",
  "created_at" : "Mon Nov 18 09:53:53 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Naija102FM: Np-Oshe by @Praiz8 t @AwiloLongomba #MorningRuns w @GodwinAruwayo @sabinaNP @ushbebecomedian",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "20" ],
  "favorite_count" : "0",
  "id_str" : "401748098189639680",
  "in_reply_to_user_id" : "1255680978",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401748098189639680",
  "created_at" : "Sat Nov 16 16:26:25 +0000 2013",
  "favorited" : false,
  "full_text" : "@Emyzz14 ff back ;-)",
  "lang" : "en",
  "in_reply_to_screen_name" : "RigoVibes",
  "in_reply_to_user_id_str" : "1255680978"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/Funny_Truth/status/401564459753164800/photo/1",
      "source_status_id" : "401564459753164800",
      "indices" : [ "37", "59" ],
      "url" : "http://t.co/b1nlcu4vxG",
      "media_url" : "http://pbs.twimg.com/media/BZKkv6JCUAIfwP0.jpg",
      "id_str" : "401564459757359106",
      "source_user_id" : "296623811",
      "id" : "401564459757359106",
      "media_url_https" : "https://pbs.twimg.com/media/BZKkv6JCUAIfwP0.jpg",
      "source_user_id_str" : "296623811",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "500",
          "h" : "386",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "500",
          "h" : "386",
          "resize" : "fit"
        },
        "small" : {
          "w" : "500",
          "h" : "386",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "401564459753164800",
      "display_url" : "pic.twitter.com/b1nlcu4vxG"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "401740921731317760",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401740921731317760",
  "possibly_sensitive" : false,
  "created_at" : "Sat Nov 16 15:57:54 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Life is too short.. http://t.co/b1nlcu4vxG",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/Funny_Truth/status/401564459753164800/photo/1",
      "source_status_id" : "401564459753164800",
      "indices" : [ "37", "59" ],
      "url" : "http://t.co/b1nlcu4vxG",
      "media_url" : "http://pbs.twimg.com/media/BZKkv6JCUAIfwP0.jpg",
      "id_str" : "401564459757359106",
      "source_user_id" : "296623811",
      "id" : "401564459757359106",
      "media_url_https" : "https://pbs.twimg.com/media/BZKkv6JCUAIfwP0.jpg",
      "source_user_id_str" : "296623811",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "500",
          "h" : "386",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "500",
          "h" : "386",
          "resize" : "fit"
        },
        "small" : {
          "w" : "500",
          "h" : "386",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "401564459753164800",
      "display_url" : "pic.twitter.com/b1nlcu4vxG"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Positive Vibes",
      "screen_name" : "Positivevibe101",
      "indices" : [ "3", "19" ],
      "id_str" : "834370320",
      "id" : "834370320"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "401740455068844032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401740455068844032",
  "created_at" : "Sat Nov 16 15:56:03 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @positivevibe101: surround yourself with people who bring out the best in you",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "401651307829682176",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401651307829682176",
  "created_at" : "Sat Nov 16 10:01:48 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Ever tried, ever failed. Never mind. Try again. Fail better.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Charly H.mac Dippsy",
      "screen_name" : "Hicez_cgp",
      "indices" : [ "0", "10" ],
      "id_str" : "1439544385",
      "id" : "1439544385"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "401631608236965888",
  "id_str" : "401648356163731456",
  "in_reply_to_user_id" : "1439544385",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401648356163731456",
  "in_reply_to_status_id" : "401631608236965888",
  "created_at" : "Sat Nov 16 09:50:05 +0000 2013",
  "favorited" : false,
  "full_text" : "@hicez_cgp k, what's for this sunny morning?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Hicez_cgp",
  "in_reply_to_user_id_str" : "1439544385"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ "91", "98" ]
    }, {
      "text" : "lovequotes",
      "indices" : [ "99", "110" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "id_str" : "401647863421083648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401647863421083648",
  "created_at" : "Sat Nov 16 09:48:07 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek You can turn off the sun, but I`m still gonna shine... #quotes #lovequotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Charly H.mac Dippsy",
      "screen_name" : "Hicez_cgp",
      "indices" : [ "0", "10" ],
      "id_str" : "1439544385",
      "id" : "1439544385"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "33" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "401626786502811648",
  "id_str" : "401629971225264128",
  "in_reply_to_user_id" : "1439544385",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401629971225264128",
  "in_reply_to_status_id" : "401626786502811648",
  "created_at" : "Sat Nov 16 08:37:01 +0000 2013",
  "favorited" : false,
  "full_text" : "@hicez_cgp on a low key bro... u?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Hicez_cgp",
  "in_reply_to_user_id_str" : "1439544385"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Charly H.mac Dippsy",
      "screen_name" : "Hicez_cgp",
      "indices" : [ "0", "10" ],
      "id_str" : "1439544385",
      "id" : "1439544385"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "18" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "400890707122343936",
  "id_str" : "401625453355888640",
  "in_reply_to_user_id" : "1439544385",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401625453355888640",
  "in_reply_to_status_id" : "400890707122343936",
  "created_at" : "Sat Nov 16 08:19:04 +0000 2013",
  "favorited" : false,
  "full_text" : "@hicez_cgp yeah...",
  "lang" : "en",
  "in_reply_to_screen_name" : "Hicez_cgp",
  "in_reply_to_user_id_str" : "1439544385"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "0",
  "id_str" : "401524197408923649",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401524197408923649",
  "created_at" : "Sat Nov 16 01:36:43 +0000 2013",
  "favorited" : false,
  "full_text" : "Im like an iphone. I lose energy without doing anything",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "0",
  "id_str" : "401523439468814336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401523439468814336",
  "created_at" : "Sat Nov 16 01:33:42 +0000 2013",
  "favorited" : false,
  "full_text" : "If u dont appreciate me, somebody els will. As simple as that!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "41" ],
  "favorite_count" : "0",
  "id_str" : "401523016246771712",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401523016246771712",
  "created_at" : "Sat Nov 16 01:32:01 +0000 2013",
  "favorited" : false,
  "full_text" : "If you're struggling, you're progressing.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "36" ],
  "favorite_count" : "0",
  "id_str" : "401522729691930624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401522729691930624",
  "created_at" : "Sat Nov 16 01:30:53 +0000 2013",
  "favorited" : false,
  "full_text" : "Its never too late to do whats right",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Angel_of_my_life",
      "indices" : [ "0", "17" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "17" ],
  "favorite_count" : "0",
  "id_str" : "401521943184416768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401521943184416768",
  "created_at" : "Sat Nov 16 01:27:45 +0000 2013",
  "favorited" : false,
  "full_text" : "#Angel_of_my_life",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "45" ],
  "favorite_count" : "0",
  "id_str" : "401521028196995072",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401521028196995072",
  "created_at" : "Sat Nov 16 01:24:07 +0000 2013",
  "favorited" : false,
  "full_text" : "EVEN the nicest person's patience has a limit",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Emilie Johnson",
      "screen_name" : "HammerOfFacts",
      "indices" : [ "3", "17" ],
      "id_str" : "3392494853",
      "id" : "3392494853"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "401474994393186305",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401474994393186305",
  "created_at" : "Fri Nov 15 22:21:12 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @HammerOfFacts: Grades don't always measure intelligence and age doesn't always define maturity.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "0",
  "id_str" : "401472906560942080",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401472906560942080",
  "created_at" : "Fri Nov 15 22:12:54 +0000 2013",
  "favorited" : false,
  "full_text" : "only God can judge us... ;-)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "401471865002008576",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401471865002008576",
  "created_at" : "Fri Nov 15 22:08:46 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Factsionary: There's a website called \" WhatIsThatSong \" that will find any song that you hear on TV but don't know what they name of i…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "PRAIZ \uD83D\uDC51",
      "screen_name" : "Praiz8",
      "indices" : [ "0", "7" ],
      "id_str" : "126571944",
      "id" : "126571944"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "401471687587155968",
  "in_reply_to_user_id" : "126571944",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401471687587155968",
  "created_at" : "Fri Nov 15 22:08:03 +0000 2013",
  "favorited" : false,
  "full_text" : "@Praiz8 thumbs up for oshe.... Great!",
  "lang" : "en",
  "in_reply_to_screen_name" : "Praiz8",
  "in_reply_to_user_id_str" : "126571944"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "401468188598493184",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401468188598493184",
  "created_at" : "Fri Nov 15 21:54:09 +0000 2013",
  "favorited" : false,
  "full_text" : "If your love was all i had in this life, well that would be enough - JUSTIN TIMBERLAKE",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Charly H.mac Dippsy",
      "screen_name" : "Hicez_cgp",
      "indices" : [ "0", "10" ],
      "id_str" : "1439544385",
      "id" : "1439544385"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "400890707122343936",
  "id_str" : "401465451856658433",
  "in_reply_to_user_id" : "1439544385",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401465451856658433",
  "in_reply_to_status_id" : "400890707122343936",
  "created_at" : "Fri Nov 15 21:43:17 +0000 2013",
  "favorited" : false,
  "full_text" : "@hicez_cgp yeah, There is a light at the end of every tunnel",
  "lang" : "en",
  "in_reply_to_screen_name" : "Hicez_cgp",
  "in_reply_to_user_id_str" : "1439544385"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "401452743279534081",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "401452743279534081",
  "created_at" : "Fri Nov 15 20:52:47 +0000 2013",
  "favorited" : false,
  "full_text" : "Look at the stars, look how they shine for you and everything you do - COLDPLAY",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "bigger_than_life",
      "indices" : [ "5", "22" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "24" ],
  "favorite_count" : "0",
  "id_str" : "400890046456545280",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "400890046456545280",
  "created_at" : "Thu Nov 14 07:36:49 +0000 2013",
  "favorited" : false,
  "full_text" : "I am #bigger_than_life !",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "LifeCheates",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "125" ],
  "favorite_count" : "0",
  "id_str" : "400880808719695873",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "400880808719695873",
  "created_at" : "Thu Nov 14 07:00:07 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LifeCheates: Lemon juice with a pinch of salt (warm) every morning lowers cholesterol levels and brings down your weight.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "LifeCheates",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "125" ],
  "favorite_count" : "0",
  "id_str" : "400878716865085441",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "400878716865085441",
  "created_at" : "Thu Nov 14 06:51:48 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LifeCheates: Daydreaming is good for your brain -- It makes you more creative but in some cases, it can cause depression.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "85" ],
  "favorite_count" : "0",
  "id_str" : "400875806764695552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "400875806764695552",
  "created_at" : "Thu Nov 14 06:40:14 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: It doesn't matter what people say, always be the person you are.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "400874137947623424",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "400874137947623424",
  "created_at" : "Thu Nov 14 06:33:37 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Just like my blog, you are quality.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Sarcasm",
      "screen_name" : "ComedyPosts",
      "indices" : [ "3", "15" ],
      "id_str" : "64019328",
      "id" : "64019328"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "0",
  "id_str" : "400873182212534272",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "400873182212534272",
  "created_at" : "Thu Nov 14 06:29:49 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ComedyPosts: The only math I ever want to do consists of counting my money when I'm rich.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "id_str" : "400233851148316672",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "400233851148316672",
  "created_at" : "Tue Nov 12 12:09:20 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: To get even with an enemy you must do the one thing they hate most, Be happy!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "399936083116695552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "399936083116695552",
  "created_at" : "Mon Nov 11 16:26:07 +0000 2013",
  "favorited" : false,
  "full_text" : "There's a drop of\ngreatness in every\nwiseman...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "399935854279671809",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "399935854279671809",
  "created_at" : "Mon Nov 11 16:25:12 +0000 2013",
  "favorited" : false,
  "full_text" : "When you finally realize\nyou didn't matter at all to\nsomeone, you begin to\nwonder if you matter to\nanyone.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "399532164825767936",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "399532164825767936",
  "created_at" : "Sun Nov 10 13:41:05 +0000 2013",
  "favorited" : false,
  "full_text" : "Never make someone a priority, when all you are to them is an option.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "id_str" : "398875399968813056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "398875399968813056",
  "created_at" : "Fri Nov 08 18:11:20 +0000 2013",
  "favorited" : false,
  "full_text" : "Congrats Nigeria! Thumbs up",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "34" ],
  "favorite_count" : "0",
  "id_str" : "398721352267755520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "398721352267755520",
  "created_at" : "Fri Nov 08 07:59:12 +0000 2013",
  "favorited" : false,
  "full_text" : "Individuality can not make us tall",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "398654918317191168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "398654918317191168",
  "created_at" : "Fri Nov 08 03:35:13 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: A person often meets his destiny on the road he took to avoid it. - Jean de La Fontaine",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "398654800809574400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "398654800809574400",
  "created_at" : "Fri Nov 08 03:34:45 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: The average amount of time a woman can keep a secret is just 47 hours and 26 minutes.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "id_str" : "398647363650453504",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "398647363650453504",
  "created_at" : "Fri Nov 08 03:05:12 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Don't forget to smile :)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "id_str" : "398541996228640768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "398541996228640768",
  "created_at" : "Thu Nov 07 20:06:31 +0000 2013",
  "favorited" : false,
  "full_text" : "Think positive thoughts, say\npositive words.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "398540879025418240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "398540879025418240",
  "created_at" : "Thu Nov 07 20:02:04 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: You can do anything, but not everything.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "396521910030176256",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "396521910030176256",
  "created_at" : "Sat Nov 02 06:19:25 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: Life aint always what it seems to be, and words can't express what you mean to me. - Diddy",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "396521773274910720",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "396521773274910720",
  "created_at" : "Sat Nov 02 06:18:52 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: You know the streets made me and I don�t give a damn if you hate me. - Lil Wayne",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "396396722504491008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "396396722504491008",
  "created_at" : "Fri Nov 01 22:01:58 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: Reality is wrong. Dreams are for real. - Tupac",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "76" ],
  "favorite_count" : "0",
  "id_str" : "395144437136752640",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "395144437136752640",
  "created_at" : "Tue Oct 29 11:05:49 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: You’re like a rare candy. You take me to a whole new level.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Bae",
      "screen_name" : "GirlfriendNotes",
      "indices" : [ "3", "19" ],
      "id_str" : "332788870",
      "id" : "332788870"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "89" ],
  "favorite_count" : "0",
  "id_str" : "395116245949108225",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "395116245949108225",
  "created_at" : "Tue Oct 29 09:13:48 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @GirlfriendNotes: Keep it real with the people around you no matter how fake they are.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "3", "13" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "395115058499682304",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "395115058499682304",
  "created_at" : "Tue Oct 29 09:09:05 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Leeleeyen: Don't look back unless you plan to go that way.\nHenry D. Thoreau",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "101" ],
  "favorite_count" : "0",
  "id_str" : "395114723127332864",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "395114723127332864",
  "created_at" : "Tue Oct 29 09:07:45 +0000 2013",
  "favorited" : false,
  "full_text" : "There are some things children cannot know, because once they learn\nthem they are no longer children.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Health & Nutrition",
      "screen_name" : "HealthBeWealth",
      "indices" : [ "3", "18" ],
      "id_str" : "611825336",
      "id" : "611825336"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "109" ],
  "favorite_count" : "0",
  "id_str" : "395071939707805697",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "395071939707805697",
  "created_at" : "Tue Oct 29 06:17:45 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @HealthBeWealth: Your mind will quit 100 times before your body ever does. Feel the pain and do it anyway.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "id_str" : "394939426024869888",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394939426024869888",
  "created_at" : "Mon Oct 28 21:31:11 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Smiling is contagious.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "394939264640622592",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394939264640622592",
  "created_at" : "Mon Oct 28 21:30:32 +0000 2013",
  "favorited" : false,
  "full_text" : "Police Quote: \"In God we trust, all others are suspects.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "76" ],
  "favorite_count" : "0",
  "id_str" : "394937388792688640",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394937388792688640",
  "created_at" : "Mon Oct 28 21:23:05 +0000 2013",
  "favorited" : false,
  "full_text" : "Age is a question of mind over matter. If you\ndon’t mind, it doesn’t matter.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "CuteLoveMsgs",
      "indices" : [ "3", "16" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "394934845358354432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394934845358354432",
  "created_at" : "Mon Oct 28 21:12:59 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @CuteLoveMsgs: You talk to me with words, and I look at you with feelings.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "394934590076231681",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394934590076231681",
  "created_at" : "Mon Oct 28 21:11:58 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: Do you ever wish you had a second chance to meet someone again for the first time?",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "394571061846867969",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394571061846867969",
  "created_at" : "Sun Oct 27 21:07:26 +0000 2013",
  "favorited" : false,
  "full_text" : "Happiness is not defined in things, status, words or even success, but it’s\na feeling you want to share with the world.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "394457372774526977",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394457372774526977",
  "created_at" : "Sun Oct 27 13:35:41 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: Sarcasm is the best answer to a stupid question.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Common White Girl",
      "screen_name" : "damnitstrue",
      "indices" : [ "3", "15" ],
      "id_str" : "66714703",
      "id" : "66714703"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "394352193613996032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394352193613996032",
  "created_at" : "Sun Oct 27 06:37:44 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @damnitstrue: Life's too short.. too short to live it as a bad person.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "394350150191026176",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394350150191026176",
  "created_at" : "Sun Oct 27 06:29:37 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: Bitches on my stick but my name ain�t Harry Potter. - Lil Wayne",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "134" ],
  "favorite_count" : "0",
  "id_str" : "394349528087674881",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394349528087674881",
  "created_at" : "Sun Oct 27 06:27:08 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: The places that Ive been, the things that I have seen - what you have as nightmares, are what I have as dreams. - DMX",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "394348988486279169",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394348988486279169",
  "created_at" : "Sun Oct 27 06:25:00 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Efficiency is doing things right; effectiveness is doing the right things. - Peter Drucker",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "394348676044185600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394348676044185600",
  "created_at" : "Sun Oct 27 06:23:45 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Choose a job you love, &amp; you will never have to work a day in your life. - Confucius",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "0",
  "id_str" : "394122965362544640",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394122965362544640",
  "created_at" : "Sat Oct 26 15:26:52 +0000 2013",
  "favorited" : false,
  "full_text" : "Stop complaining and just appreciate the life you have.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "394122776719523841",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "394122776719523841",
  "created_at" : "Sat Oct 26 15:26:07 +0000 2013",
  "favorited" : false,
  "full_text" : "You don’t need to be smart, good looking, or wealthy to make someone\nhappy.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "393831672283537409",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393831672283537409",
  "created_at" : "Fri Oct 25 20:09:22 +0000 2013",
  "favorited" : false,
  "full_text" : "The greatest failure is to achieve success as a fraud.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "393831199543549952",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393831199543549952",
  "created_at" : "Fri Oct 25 20:07:29 +0000 2013",
  "favorited" : false,
  "full_text" : "Never give up on what you really want",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "0",
  "id_str" : "393830983234887680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393830983234887680",
  "created_at" : "Fri Oct 25 20:06:38 +0000 2013",
  "favorited" : false,
  "full_text" : "Don't make a promise that you're not willing to stand by",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "393827196986740736",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393827196986740736",
  "created_at" : "Fri Oct 25 19:51:35 +0000 2013",
  "favorited" : false,
  "full_text" : "Feelings of jealousy weakens the immune system.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "70" ],
  "favorite_count" : "0",
  "id_str" : "393476509836386304",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393476509836386304",
  "created_at" : "Thu Oct 24 20:38:05 +0000 2013",
  "favorited" : false,
  "full_text" : "If you're not willing to put in the effort, don't expect it\nin return.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "393475359414308864",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393475359414308864",
  "created_at" : "Thu Oct 24 20:33:30 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Marry someone who is ambitious, happy, healthy and has a sense of humor, this will add 5 to 10 years to your life expecta…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "102" ],
  "favorite_count" : "0",
  "id_str" : "393475125439234049",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393475125439234049",
  "created_at" : "Thu Oct 24 20:32:34 +0000 2013",
  "favorited" : false,
  "full_text" : "Are oranges named orange because they’re orange or is\norange called orange because oranges are orange?",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "NotCommonFactz",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "393470745033994240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393470745033994240",
  "created_at" : "Thu Oct 24 20:15:10 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @NotCommonFactz: \"Groaking\" is act of watching people eat food hoping they'll offer you some.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "393468633289998336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "393468633289998336",
  "created_at" : "Thu Oct 24 20:06:47 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Forget about Spiderman, Superman, and Batman. I’ll be your man.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "392212600039018496",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "392212600039018496",
  "created_at" : "Mon Oct 21 08:55:45 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Your smile is the most beautiful curve on your body.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "392186710983204864",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "392186710983204864",
  "created_at" : "Mon Oct 21 07:12:53 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: The most dangerous people aren't the ones who get in your face and make threats, but the ones that stand back stare an…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "391871131654705152",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "391871131654705152",
  "created_at" : "Sun Oct 20 10:18:53 +0000 2013",
  "favorited" : false,
  "full_text" : "\"By learning you will teach, by teaching you will learn.\" -Latin proverb",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "133" ],
  "favorite_count" : "0",
  "id_str" : "391870732013027328",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "391870732013027328",
  "created_at" : "Sun Oct 20 10:17:17 +0000 2013",
  "favorited" : false,
  "full_text" : "Everyone has a story left untold, never start judging someone like you know them back\nto front cos the truth is, you probably don't!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "390934602451124225",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390934602451124225",
  "created_at" : "Thu Oct 17 20:17:27 +0000 2013",
  "favorited" : false,
  "full_text" : "I can’t hide a bad mood from people who know me well.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "3", "13" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "390816067364614145",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390816067364614145",
  "created_at" : "Thu Oct 17 12:26:26 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Leeleeyen: Sometimes, we need to be hurt in order to grow. We must lose in order to gain. Sometimes, some lessons are learned best thro…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "PObahiagbon",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "390815734609489920",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390815734609489920",
  "created_at" : "Thu Oct 17 12:25:06 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @PObahiagbon: A shame some of us would rather shoot the messenger than listen to the message.. He who is without sin, may he step up... …",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "120" ],
  "favorite_count" : "0",
  "id_str" : "390813557434372096",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390813557434372096",
  "created_at" : "Thu Oct 17 12:16:27 +0000 2013",
  "favorited" : false,
  "full_text" : "Past is experience,Presnt is experimnt.Future is expectation!!! Use ur experience in\nur experimnts 2 gt ur expectations.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "95" ],
  "favorite_count" : "0",
  "id_str" : "390812603909693441",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390812603909693441",
  "created_at" : "Thu Oct 17 12:12:40 +0000 2013",
  "favorited" : false,
  "full_text" : "Love me without restriction,trust me without fear,want me without demand,accept me\nfor who I AM",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Female Notes",
      "screen_name" : "itsmindbiowing",
      "indices" : [ "3", "18" ],
      "id_str" : "4819165870",
      "id" : "4819165870"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "390221930093363202",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390221930093363202",
  "created_at" : "Tue Oct 15 21:05:32 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ItsMindBIowing: You will never find time for anything. If you want time, you must make it.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Shower Thoughts",
      "screen_name" : "TheWeirdWorld",
      "indices" : [ "3", "17" ],
      "id_str" : "487736815",
      "id" : "487736815"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "390210515756392448",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390210515756392448",
  "created_at" : "Tue Oct 15 20:20:11 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheWeirdWorld: There are at least 7 people in the world who look exactly like you. There's a 10% chance that you'll meet one of them in…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "45" ],
  "favorite_count" : "0",
  "id_str" : "390210307400171520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390210307400171520",
  "created_at" : "Tue Oct 15 20:19:21 +0000 2013",
  "favorited" : false,
  "full_text" : "The time is always right to do what is right.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Rob Greer",
      "screen_name" : "robbygreer",
      "indices" : [ "3", "14" ],
      "id_str" : "913744615",
      "id" : "913744615"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "390208443833126912",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390208443833126912",
  "created_at" : "Tue Oct 15 20:11:57 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @RobbyGreer: Don't forget your worth. Once you do, you lose what you deserve.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Shower Thoughts",
      "screen_name" : "TheWeirdWorld",
      "indices" : [ "3", "17" ],
      "id_str" : "487736815",
      "id" : "487736815"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "390208287079403522",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "390208287079403522",
  "created_at" : "Tue Oct 15 20:11:20 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheWeirdWorld: Don’t be afraid of death, be afraid of an unlived life.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Autocorrects",
      "screen_name" : "autocorrects",
      "indices" : [ "3", "16" ],
      "id_str" : "1131975179859505157",
      "id" : "1131975179859505157"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "133" ],
  "favorite_count" : "0",
  "id_str" : "389761634396143616",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "389761634396143616",
  "created_at" : "Mon Oct 14 14:36:29 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @autocorrects: I advise you, don't mess with me, I know karate, kung fu, judo, tae kwon do, jujitsu, and 28 other dangerous words.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LIFE QUOTES",
      "screen_name" : "ItsLifeFact",
      "indices" : [ "3", "15" ],
      "id_str" : "396086694",
      "id" : "396086694"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "389480529134764032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "389480529134764032",
  "created_at" : "Sun Oct 13 19:59:29 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ItsLifeFact: No matter how many times I say I don't care, I still do care.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "114" ],
  "favorite_count" : "0",
  "id_str" : "389480317855084544",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "389480317855084544",
  "created_at" : "Sun Oct 13 19:58:38 +0000 2013",
  "favorited" : false,
  "full_text" : "Sometimes it's better to stop trying to make sense of things. Life isn't\nclear cut, there are always gray areas...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "388777542817050624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "388777542817050624",
  "created_at" : "Fri Oct 11 21:26:04 +0000 2013",
  "favorited" : false,
  "full_text" : "Cheating on a good girl is like throwing away a diamond and picking up a\nrock.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "388775317629702144",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "388775317629702144",
  "created_at" : "Fri Oct 11 21:17:13 +0000 2013",
  "favorited" : false,
  "full_text" : "You Can Do It if You Believe You Can!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "388769461123051520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "388769461123051520",
  "created_at" : "Fri Oct 11 20:53:57 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Count your blessings and give thanks to the Lord God.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Rich Simmonds",
      "screen_name" : "RichSimmondsZA",
      "indices" : [ "3", "18" ],
      "id_str" : "292819455",
      "id" : "292819455"
    }, {
      "name" : "Partners4Possibility",
      "screen_name" : "PfP4SA",
      "indices" : [ "93", "100" ],
      "id_str" : "919598036",
      "id" : "919598036"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "100" ],
  "favorite_count" : "0",
  "id_str" : "388766411369095168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "388766411369095168",
  "created_at" : "Fri Oct 11 20:41:50 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @RichSimmondsZA: \"By learning you will teach, by teaching you will learn.\" -Latin proverb @PfP4SA",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "24" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "382425659395829760",
  "id_str" : "384616445759733760",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "384616445759733760",
  "in_reply_to_status_id" : "382425659395829760",
  "created_at" : "Mon Sep 30 09:51:21 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen m missing you",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "destiny",
      "indices" : [ "35", "43" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "382937021544931328",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "382937021544931328",
  "created_at" : "Wed Sep 25 18:37:55 +0000 2013",
  "favorited" : false,
  "full_text" : "God is my chauffeur, take me to my #destiny",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "382421791022383104",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "382421791022383104",
  "created_at" : "Tue Sep 24 08:30:34 +0000 2013",
  "favorited" : false,
  "full_text" : "Darkness isn't the absence of light...\nit's the absence of you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "381900455187861504",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "381900455187861504",
  "created_at" : "Sun Sep 22 21:58:58 +0000 2013",
  "favorited" : false,
  "full_text" : "Take all d glory,Take all the honour,i live to worship oh awesome God",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "381898293225459712",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "381898293225459712",
  "created_at" : "Sun Sep 22 21:50:23 +0000 2013",
  "favorited" : false,
  "full_text" : "To settle an argument, think of what is right, not who is right.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "380301677666246659",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "380301677666246659",
  "created_at" : "Wed Sep 18 12:06:00 +0000 2013",
  "favorited" : false,
  "full_text" : "I act like I don't notice shit. But believe me, I\nnotice everything. í ½í¸",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Laughing",
      "screen_name" : "ComedyTruth",
      "indices" : [ "3", "15" ],
      "id_str" : "102862303",
      "id" : "102862303"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "380054440767946752",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "380054440767946752",
  "created_at" : "Tue Sep 17 19:43:34 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ComedyTruth: I respect those that tell me the truth, no matter how hard it is.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "379687183403470848",
  "id_str" : "380050999001743360",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "380050999001743360",
  "in_reply_to_status_id" : "379687183403470848",
  "created_at" : "Tue Sep 17 19:29:53 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen missing you too!",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "mistakes",
      "indices" : [ "35", "44" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "378933947654504448",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "378933947654504448",
  "created_at" : "Sat Sep 14 17:31:08 +0000 2013",
  "favorited" : false,
  "full_text" : "No matter who you are, you've made #mistakes. So, don't judge\npeople by theirs.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "378933775612518400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "378933775612518400",
  "created_at" : "Sat Sep 14 17:30:27 +0000 2013",
  "favorited" : false,
  "full_text" : "When you make a mistake, admit it. If you don't, you only make\nmatters worse.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "id_str" : "378925184687681536",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "378925184687681536",
  "created_at" : "Sat Sep 14 16:56:18 +0000 2013",
  "favorited" : false,
  "full_text" : "There's only one corner of the universe you can be certain of\nimproving, and that's your own self.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "378914341976039424",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "378914341976039424",
  "created_at" : "Sat Sep 14 16:13:13 +0000 2013",
  "favorited" : false,
  "full_text" : "I'm in constant competition with myself...a little sleep a lil\nslumber...in pursuit of better days ahead!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "people",
      "indices" : [ "5", "12" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "378913881198178304",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "378913881198178304",
  "created_at" : "Sat Sep 14 16:11:23 +0000 2013",
  "favorited" : false,
  "full_text" : "Keep #people in your life who lift you up, not tear you down",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "378912507882377216",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "378912507882377216",
  "created_at" : "Sat Sep 14 16:05:56 +0000 2013",
  "favorited" : false,
  "full_text" : "Accept me at my strongest, support me at my weakest.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "378911350661324800",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "378911350661324800",
  "created_at" : "Sat Sep 14 16:01:20 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: The most precious possession that ever comes to a man in this world is a woman's heart.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "123" ],
  "favorite_count" : "0",
  "id_str" : "378330260460167168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "378330260460167168",
  "created_at" : "Fri Sep 13 01:32:17 +0000 2013",
  "favorited" : false,
  "full_text" : "like you because I can never stay mad at\nyou, I can't stand not talking to you and I can't\nstand the thought of losing you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "376080674505392128",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "376080674505392128",
  "created_at" : "Fri Sep 06 20:33:14 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: I hear you're good at algebra.....Will you replace my eX without asking Y?",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://www.twitlonger.com\" rel=\"nofollow\">Twitlonger</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/rCYfg0omz6",
      "expanded_url" : "http://tl.gd/n_1rm9g3u",
      "display_url" : "tl.gd/n_1rm9g3u",
      "indices" : [ "113", "135" ]
    } ]
  },
  "display_text_range" : [ "0", "135" ],
  "favorite_count" : "0",
  "id_str" : "375489615131852800",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "375489615131852800",
  "possibly_sensitive" : false,
  "created_at" : "Thu Sep 05 05:24:35 +0000 2013",
  "favorited" : false,
  "full_text" : "Happy Birthday to Me! I wish myself many more years of joy, love, laughter, health and prosperity. I wish (cont) http://t.co/rCYfg0omz6",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "id_str" : "374405238125363200",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "374405238125363200",
  "created_at" : "Mon Sep 02 05:35:39 +0000 2013",
  "favorited" : false,
  "full_text" : "don't go around fire expectin' not to sweat.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "happynewmonth",
      "indices" : [ "0", "14" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "14" ],
  "favorite_count" : "0",
  "id_str" : "374049640590503936",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "374049640590503936",
  "created_at" : "Sun Sep 01 06:02:38 +0000 2013",
  "favorited" : false,
  "full_text" : "#happynewmonth",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "374049125714493440",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "374049125714493440",
  "created_at" : "Sun Sep 01 06:00:35 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: At one point in your life you either have the thing you want or the reasons why you don’t -Andy Roddick",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "374049059759075328",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "374049059759075328",
  "created_at" : "Sun Sep 01 06:00:20 +0000 2013",
  "favorited" : false,
  "full_text" : "People change, things go wrong, shit happens, but life goes\non.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "knowledge",
      "screen_name" : "TheGoogleFactz",
      "indices" : [ "3", "18" ],
      "id_str" : "749952350",
      "id" : "749952350"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "85" ],
  "favorite_count" : "0",
  "id_str" : "374041499907809280",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "374041499907809280",
  "created_at" : "Sun Sep 01 05:30:17 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Thegooglefactz: Whenever you're feeling down, remember, you're the sperm that won",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "374041410283921408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "374041410283921408",
  "created_at" : "Sun Sep 01 05:29:56 +0000 2013",
  "favorited" : false,
  "full_text" : "Kill them with success and bury them with a smile.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "133" ],
  "favorite_count" : "0",
  "id_str" : "373952013081792512",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "373952013081792512",
  "created_at" : "Sat Aug 31 23:34:42 +0000 2013",
  "favorited" : false,
  "full_text" : "I'm not perfect. I'll annoy you, tick you off but put all\nthat aside, You'll never find someone who cares and loves\nyou more than me.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "126" ],
  "favorite_count" : "0",
  "id_str" : "373951821783760896",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "373951821783760896",
  "created_at" : "Sat Aug 31 23:33:56 +0000 2013",
  "favorited" : false,
  "full_text" : "Don't be mad when someone else starts to appreciate the\nperson you took for granted. What you won't do, someone\nelse will#LIFE",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "373951659959128066",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "373951659959128066",
  "created_at" : "Sat Aug 31 23:33:18 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Are you a light switch? Cause I want to turn you on!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "373951442799038464",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "373951442799038464",
  "created_at" : "Sat Aug 31 23:32:26 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: I don’t need my magic carpet to take you over, sideways and under.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "120" ],
  "favorite_count" : "0",
  "id_str" : "373951138498105344",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "373951138498105344",
  "created_at" : "Sat Aug 31 23:31:13 +0000 2013",
  "favorited" : false,
  "full_text" : "When some1 is so sweet 2 u dont expect dat they will be\nlike dat all d time...bcos even d sweetest chocolate also\nexpire",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "id_str" : "373950731478253568",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "373950731478253568",
  "created_at" : "Sat Aug 31 23:29:36 +0000 2013",
  "favorited" : false,
  "full_text" : "The prettiest smiles hide the deepest secrets. The prettiest\neyes have cried the most tears.And the kindest hearts\nhave felt the most pain",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "111" ],
  "favorite_count" : "0",
  "id_str" : "373902119394631680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "373902119394631680",
  "created_at" : "Sat Aug 31 20:16:26 +0000 2013",
  "favorited" : false,
  "full_text" : "Do what you think is right, not what people think is right.\nIn the end, it's you who goes through it, not them.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "373190322232123393",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "373190322232123393",
  "created_at" : "Thu Aug 29 21:08:01 +0000 2013",
  "favorited" : false,
  "full_text" : "Be real, be happy, be unique, be true, be honest, be humble, be true to yourself.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "25" ],
  "favorite_count" : "0",
  "id_str" : "372603664101154817",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "372603664101154817",
  "created_at" : "Wed Aug 28 06:16:50 +0000 2013",
  "favorited" : false,
  "full_text" : "Real feelings dont change",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "NotCommonFactz",
      "indices" : [ "3", "18" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "372603086805532673",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "372603086805532673",
  "created_at" : "Wed Aug 28 06:14:33 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @NotCommonFactz: Consuming chocolate was once considered a temptation of the devil.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "theproblemwithakwaibomis",
      "indices" : [ "0", "25" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "133" ],
  "favorite_count" : "0",
  "id_str" : "372602780986245120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "372602780986245120",
  "created_at" : "Wed Aug 28 06:13:20 +0000 2013",
  "favorited" : false,
  "full_text" : "#theproblemwithakwaibomis that the state hasn't\ngot a leader with the economic acumen to\nliberate the people from economic servitude.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    }, {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "102", "115" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ {
      "url" : "http://t.co/dUMdDzofvQ",
      "expanded_url" : "http://bit.ly/1itJlLa",
      "display_url" : "bit.ly/1itJlLa",
      "indices" : [ "75", "97" ]
    } ]
  },
  "display_text_range" : [ "0", "115" ],
  "favorite_count" : "0",
  "id_str" : "456477668360212481",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456477668360212481",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 16 17:02:11 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: Photos from Julius Agwu’s birthday celebration yesterday http://t.co/dUMdDzofvQ Via @AllAroundNig",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/H2lhCICpyS",
      "expanded_url" : "http://www.411vibes.com/2014/04/uganda-to-deport-british-man-charged-in.html",
      "display_url" : "411vibes.com/2014/04/uganda…",
      "indices" : [ "48", "70" ]
    } ]
  },
  "display_text_range" : [ "0", "70" ],
  "favorite_count" : "0",
  "id_str" : "456085576975122434",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456085576975122434",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 15:04:09 +0000 2014",
  "favorited" : false,
  "full_text" : "UGANDA To Deport British Man Charged In Gay S3x http://t.co/H2lhCICpyS",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/D0wyjplCnj",
      "expanded_url" : "http://bit.ly/Q9KCAr",
      "display_url" : "bit.ly/Q9KCAr",
      "indices" : [ "71", "93" ]
    } ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "0",
  "id_str" : "456085452651778049",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456085452651778049",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 15:03:40 +0000 2014",
  "favorited" : false,
  "full_text" : "Meet The 55yrs old Black Lady Who Looks Like A 20yrs old Girl (PHOTOS) http://t.co/D0wyjplCnj",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/OLWUzQzMmi",
      "expanded_url" : "http://bit.ly/1ktIEGm",
      "display_url" : "bit.ly/1ktIEGm",
      "indices" : [ "70", "92" ]
    } ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "456084681730322433",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456084681730322433",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 15:00:36 +0000 2014",
  "favorited" : false,
  "full_text" : "Dear Fans, This Is How You Made Pharrell William Cry On Oprah [WATCH] http://t.co/OLWUzQzMmi",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/PdcCdTc71x",
      "expanded_url" : "http://www.411vibes.com/2014/04/ladies-men-have-spoken-see-their.html",
      "display_url" : "411vibes.com/2014/04/ladies…",
      "indices" : [ "55", "77" ]
    } ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "456084082544611329",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456084082544611329",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 14:58:13 +0000 2014",
  "favorited" : false,
  "full_text" : "Ladies, The Men Have Spoken: See Their Message To You! http://t.co/PdcCdTc71x",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/eYgYYBhCTh",
      "expanded_url" : "http://bit.ly/1hHVMIp",
      "display_url" : "bit.ly/1hHVMIp",
      "indices" : [ "59", "81" ]
    } ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "456083988088913920",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456083988088913920",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 14:57:51 +0000 2014",
  "favorited" : false,
  "full_text" : "Ladies, You Don’t Have To Tell Your Man Everything… Really http://t.co/eYgYYBhCTh",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/AmPmWbK2cB",
      "expanded_url" : "http://bit.ly/Q9J8WU",
      "display_url" : "bit.ly/Q9J8WU",
      "indices" : [ "91", "113" ]
    } ]
  },
  "display_text_range" : [ "0", "113" ],
  "favorite_count" : "0",
  "id_str" : "456083805548597248",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456083805548597248",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 14:57:07 +0000 2014",
  "favorited" : false,
  "full_text" : "13-Year-Old Mongolian Girl Is An Huntress Who Catches Foxes With Her Golden Eagle (PHOTOS) http://t.co/AmPmWbK2cB",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/RSfjKFUCrW",
      "expanded_url" : "http://bit.ly/1eEgtVa",
      "display_url" : "bit.ly/1eEgtVa",
      "indices" : [ "112", "134" ]
    } ]
  },
  "display_text_range" : [ "0", "134" ],
  "favorite_count" : "0",
  "id_str" : "456083667216252928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456083667216252928",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 14:56:34 +0000 2014",
  "favorited" : false,
  "full_text" : "‘Today is a good day to tell you… I love you’: Pistorius Sobs As He Reads Val’s Card From Reeva (PHOTOS, VIDEO) http://t.co/RSfjKFUCrW",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/oH7wdSZQoO",
      "expanded_url" : "http://j.mp/1gBdzix",
      "display_url" : "j.mp/1gBdzix",
      "indices" : [ "85", "107" ]
    }, {
      "url" : "http://t.co/oH7wdSZQoO",
      "expanded_url" : "http://j.mp/1gBdzix",
      "display_url" : "j.mp/1gBdzix",
      "indices" : [ "108", "130" ]
    } ]
  },
  "display_text_range" : [ "0", "130" ],
  "favorite_count" : "0",
  "id_str" : "456083086401613824",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456083086401613824",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 14:54:16 +0000 2014",
  "favorited" : false,
  "full_text" : "[DailyPost] Lagos toll gate battle: Lawyer alleges assassination attempt on his life http://t.co/oH7wdSZQoO http://t.co/oH7wdSZQoO",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "456082850907824128",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456082850907824128",
  "created_at" : "Tue Apr 15 14:53:19 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: If I had a garden I'd put your two lips and my two lips together.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    }, {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "125", "138" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ {
      "url" : "http://t.co/hFJZGMn2fK",
      "expanded_url" : "http://bit.ly/1hvP9rv",
      "display_url" : "bit.ly/1hvP9rv",
      "indices" : [ "98", "120" ]
    } ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "id_str" : "456082434669694976",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456082434669694976",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 15 14:51:40 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: Please Forgive Us ––Pope Francis Cries Out Over Séxual Abuse In Catholic Church http://t.co/hFJZGMn2fK Via @AllAroundNig",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "456080687326855168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456080687326855168",
  "created_at" : "Tue Apr 15 14:44:44 +0000 2014",
  "favorited" : false,
  "full_text" : "Don't make someone a priority if you're just their option.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "0",
  "id_str" : "456080659388567553",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456080659388567553",
  "created_at" : "Tue Apr 15 14:44:37 +0000 2014",
  "favorited" : false,
  "full_text" : "True love and loyal friends are two of the hardest things to find.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LIFE QUOTES",
      "screen_name" : "ItsLifeFact",
      "indices" : [ "3", "15" ],
      "id_str" : "396086694",
      "id" : "396086694"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "456080637200728065",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456080637200728065",
  "created_at" : "Tue Apr 15 14:44:32 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @ItsLifeFact: It's amazing how stupid you can be when you're in love.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Male Thoughts",
      "screen_name" : "SteveStfler",
      "indices" : [ "3", "15" ],
      "id_str" : "102325442",
      "id" : "102325442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "456080456190947328",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456080456190947328",
  "created_at" : "Tue Apr 15 14:43:48 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @SteveStfler: I think the guy who invented ties was trying to commit suicide then he saw himself in the mirror &amp; thought... \n\"Wait, this…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Male Thoughts",
      "screen_name" : "SteveStfler",
      "indices" : [ "3", "15" ],
      "id_str" : "102325442",
      "id" : "102325442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "114" ],
  "favorite_count" : "0",
  "id_str" : "456080444782813184",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456080444782813184",
  "created_at" : "Tue Apr 15 14:43:46 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @SteveStfler: Dudes be like, \"I only talk to one girl.\" \n\nAND THAT STATUS BE HAVING 15 BITCHES FEELING SPECIAL.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LIFE QUOTES",
      "screen_name" : "ItsLifeFact",
      "indices" : [ "3", "15" ],
      "id_str" : "396086694",
      "id" : "396086694"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "0",
  "id_str" : "456080429704282112",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456080429704282112",
  "created_at" : "Tue Apr 15 14:43:42 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @ItsLifeFact: We've been through a lot together.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "456080426961207296",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456080426961207296",
  "created_at" : "Tue Apr 15 14:43:42 +0000 2014",
  "favorited" : false,
  "full_text" : "I’d rather live my life knowing that I’m not perfect, than spending my whole life pretending to be.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "456079781751443456",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079781751443456",
  "created_at" : "Tue Apr 15 14:41:08 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: No man is above mistake, few have the courage to admit they're wrong",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "109" ],
  "favorite_count" : "0",
  "id_str" : "456079710074978305",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079710074978305",
  "created_at" : "Tue Apr 15 14:40:51 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: When a lamb decides to play in the midst of lions, is there any future to expect from him?b",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "102" ],
  "favorite_count" : "0",
  "id_str" : "456079707390615552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079707390615552",
  "created_at" : "Tue Apr 15 14:40:50 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: Since all lizards lie on their bellies, we cannot tell which one has a stomach ache.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "456079697613692929",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079697613692929",
  "created_at" : "Tue Apr 15 14:40:48 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: Be Humble. Your Salary is Someone's Tithe.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "456079666026401792",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079666026401792",
  "created_at" : "Tue Apr 15 14:40:40 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: She Who prepares burnt dodo for her husband shall face the wrath of her mother-in-law.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "456079655691636736",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079655691636736",
  "created_at" : "Tue Apr 15 14:40:38 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: He who use nylon in place of condom must have money for abortion.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "AllAroundNigeria.com",
      "screen_name" : "AllAroundNig",
      "indices" : [ "3", "16" ],
      "id_str" : "2435169497",
      "id" : "2435169497"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "456079651459579904",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079651459579904",
  "created_at" : "Tue Apr 15 14:40:37 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AllAroundNig: The greatest threat to freedom is the absence of criticism..",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "372601612503490560",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "372601612503490560",
  "created_at" : "Wed Aug 28 06:08:41 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Rule your mind or it will rule you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "372214096784916480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "372214096784916480",
  "created_at" : "Tue Aug 27 04:28:50 +0000 2013",
  "favorited" : false,
  "full_text" : "You only live once, but if you do it right once is\nenough.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "l2m",
      "indices" : [ "94", "98" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "id_str" : "371858460927066112",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "371858460927066112",
  "created_at" : "Mon Aug 26 04:55:40 +0000 2013",
  "favorited" : false,
  "full_text" : "\"I don't want to lose you now, I'm looking\nright at the other half of me\" - Justin\nTimberlake #l2m",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "371131603097223168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "371131603097223168",
  "created_at" : "Sat Aug 24 04:47:24 +0000 2013",
  "favorited" : false,
  "full_text" : "Never give up, great things take time",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "70" ],
  "favorite_count" : "0",
  "id_str" : "371130736658886656",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "371130736658886656",
  "created_at" : "Sat Aug 24 04:43:57 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: I got my hand on the game. I make a grip. - Lil Wayne",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "25", "31" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "371129980157435904",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "371129980157435904",
  "created_at" : "Sat Aug 24 04:40:57 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: Because #Virgo has high standards, going through all the shit in life is tiring.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "22" ],
  "favorite_count" : "0",
  "id_str" : "371129559770746881",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "371129559770746881",
  "created_at" : "Sat Aug 24 04:39:16 +0000 2013",
  "favorited" : false,
  "full_text" : "Nothing Is Impossible!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "371127722388762624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "371127722388762624",
  "created_at" : "Sat Aug 24 04:31:58 +0000 2013",
  "favorited" : false,
  "full_text" : "actions and reactions must not be basically determined by actions of others",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "371127116420902912",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "371127116420902912",
  "created_at" : "Sat Aug 24 04:29:34 +0000 2013",
  "favorited" : false,
  "full_text" : "every man take the limits of his own field of vision for the limits of the world",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "proactive",
      "indices" : [ "3", "13" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "371124455604371458",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "371124455604371458",
  "created_at" : "Sat Aug 24 04:19:00 +0000 2013",
  "favorited" : false,
  "full_text" : "Be #proactive and well prepared in life because as it said, \"rising early make the road short\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "0",
  "id_str" : "369748873151279104",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "369748873151279104",
  "created_at" : "Tue Aug 20 09:12:55 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: Got an angel by my side all my demons always beggin' me to ride. - Nate Dogg",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "17", "23" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "369528666780598272",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "369528666780598272",
  "created_at" : "Mon Aug 19 18:37:54 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: #Virgo' are a pain in the ass.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "future",
      "indices" : [ "35", "42" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "369528584441839616",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "369528584441839616",
  "created_at" : "Mon Aug 19 18:37:34 +0000 2013",
  "favorited" : false,
  "full_text" : "never be afraid to trust an unkown #future to a known God",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Faith",
      "indices" : [ "0", "6" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "369528066785026048",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "369528066785026048",
  "created_at" : "Mon Aug 19 18:35:31 +0000 2013",
  "favorited" : false,
  "full_text" : "#Faith is not the belief that God will do what you want. It is the belief that God will do what is right",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "smile",
      "indices" : [ "2", "8" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "368648178855198721",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "368648178855198721",
  "created_at" : "Sat Aug 17 08:19:09 +0000 2013",
  "favorited" : false,
  "full_text" : "A #smile makes us look younger while laughter makes us\nfeel healthier.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "disappointed",
      "indices" : [ "17", "30" ]
    }, {
      "text" : "lesson",
      "indices" : [ "64", "71" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "123" ],
  "favorite_count" : "0",
  "id_str" : "368646010714603520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "368646010714603520",
  "created_at" : "Sat Aug 17 08:10:32 +0000 2013",
  "favorited" : false,
  "full_text" : "Even you've been #disappointed or lied, as know\nthat you have a #lesson learned that make you up\none level more than others",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Common White Girl",
      "screen_name" : "damnitstrue",
      "indices" : [ "3", "15" ],
      "id_str" : "66714703",
      "id" : "66714703"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "368203512473468929",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "368203512473468929",
  "created_at" : "Fri Aug 16 02:52:12 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @damnitstrue: Friendship isn't about who you've known the longest. It's about who walked into your life, said \"I'm here for you\" and pro…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "368126806077227008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "368126806077227008",
  "created_at" : "Thu Aug 15 21:47:24 +0000 2013",
  "favorited" : false,
  "full_text" : "Man without wife is like fifty without five",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "something",
      "indices" : [ "22", "32" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "id_str" : "368088194237345792",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "368088194237345792",
  "created_at" : "Thu Aug 15 19:13:58 +0000 2013",
  "favorited" : false,
  "full_text" : "Everyone you meet has #something to teach you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "13", "23" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "367369881152655360",
  "id_str" : "367503038359289856",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367503038359289856",
  "in_reply_to_status_id" : "367369881152655360",
  "created_at" : "Wed Aug 14 04:28:46 +0000 2013",
  "favorited" : false,
  "full_text" : "Okay, ekaaro @leeleeyen",
  "lang" : "tl",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "September1752",
      "indices" : [ "0", "14" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "14" ],
  "favorite_count" : "0",
  "id_str" : "367060603187527680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367060603187527680",
  "created_at" : "Mon Aug 12 23:10:42 +0000 2013",
  "favorited" : false,
  "full_text" : "#September1752",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "prayer",
      "indices" : [ "0", "7" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "15" ],
  "favorite_count" : "0",
  "id_str" : "367053653322252288",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367053653322252288",
  "created_at" : "Mon Aug 12 22:43:05 +0000 2013",
  "favorited" : false,
  "full_text" : "#prayer changes",
  "lang" : "fr"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "367051984240922624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367051984240922624",
  "created_at" : "Mon Aug 12 22:36:27 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: The average man will spend a year of his life staring at women.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "130" ],
  "favorite_count" : "0",
  "id_str" : "367051640396075008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367051640396075008",
  "created_at" : "Mon Aug 12 22:35:05 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: In time I learned a few lessons, never fall for riches - apologizes to my TRUE sisters; far from bitches. - Tupac",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "367051073884004352",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367051073884004352",
  "created_at" : "Mon Aug 12 22:32:50 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: You know you're in love when you can't fall asleep because reality is finally better than your dreams.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Rob Greer",
      "screen_name" : "robbygreer",
      "indices" : [ "3", "14" ],
      "id_str" : "913744615",
      "id" : "913744615"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "367050251930456064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367050251930456064",
  "created_at" : "Mon Aug 12 22:29:34 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @RobbyGreer: Never give up. Always find a reason to keep trying.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "3", "13" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "32" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "367048191612846080",
  "id_str" : "367050168459612160",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367050168459612160",
  "in_reply_to_status_id" : "367048191612846080",
  "created_at" : "Mon Aug 12 22:29:14 +0000 2013",
  "favorited" : false,
  "full_text" : "Hi @leeleeyen, how was your day?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "singing",
      "indices" : [ "48", "56" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "0",
  "id_str" : "367048505233539072",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367048505233539072",
  "created_at" : "Mon Aug 12 22:22:37 +0000 2013",
  "favorited" : false,
  "full_text" : "You're beautiful, you're beautiful. Its true... #singing",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Common White Girl",
      "screen_name" : "damnitstrue",
      "indices" : [ "3", "15" ],
      "id_str" : "66714703",
      "id" : "66714703"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "367047957449019392",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "367047957449019392",
  "created_at" : "Mon Aug 12 22:20:27 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @damnitstrue: You are my only love because with you my life is so complete.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "364476772525830144",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364476772525830144",
  "created_at" : "Mon Aug 05 20:03:28 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: Let the losers worry about losin. - T.I.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "364471072722546688",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364471072722546688",
  "created_at" : "Mon Aug 05 19:40:49 +0000 2013",
  "favorited" : false,
  "full_text" : "I have P.M.A \n(Positive Mental Attitude)\nI'm Positive\nI'm Mental\nand I know I have Attitude",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "364469017417105408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364469017417105408",
  "created_at" : "Mon Aug 05 19:32:39 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Are you from Korea? Because you could be my Seoul mate.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "lovequotes",
      "indices" : [ "113", "124" ]
    }, {
      "text" : "quotes",
      "indices" : [ "125", "132" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "132" ],
  "favorite_count" : "0",
  "id_str" : "364270049072545792",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364270049072545792",
  "created_at" : "Mon Aug 05 06:22:02 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Age is a question of mind over matter. If you don’t mind, it doesn’t matter. #lovequotes #quotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "39" ],
  "favorite_count" : "0",
  "id_str" : "364251604020498432",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364251604020498432",
  "created_at" : "Mon Aug 05 05:08:44 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen, ekaaro ololufe mi, seji re?",
  "lang" : "ht",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "17", "23" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "364244647775711232",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364244647775711232",
  "created_at" : "Mon Aug 05 04:41:06 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: #Virgo: Modest, Shy &amp; Romantic.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "364182954764812291",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364182954764812291",
  "created_at" : "Mon Aug 05 00:35:57 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: The only domestic animal not mentioned in the Bible is the cat.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "364182870144712706",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364182870144712706",
  "created_at" : "Mon Aug 05 00:35:37 +0000 2013",
  "favorited" : false,
  "full_text" : "you set my heart on fire, fill it with love, made me a man, I'm glad you're back!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Cuz I'm High",
      "screen_name" : "CuzImHigh",
      "indices" : [ "3", "13" ],
      "id_str" : "488182826",
      "id" : "488182826"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "116" ],
  "favorite_count" : "0",
  "id_str" : "364179636906766337",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364179636906766337",
  "created_at" : "Mon Aug 05 00:22:46 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @CuzImHigh: “I smoke a blunt to take the pain out, and if I wasn't high I'd probably blow my brains out.” - Tupac",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "137" ],
  "favorite_count" : "0",
  "id_str" : "364179542648160258",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364179542648160258",
  "created_at" : "Mon Aug 05 00:22:23 +0000 2013",
  "favorited" : false,
  "full_text" : "Care doesn't need powerful eyes or a cute voice or a\nlovely face.. It always needs a beautiful, responsible heart\nwith affection forever.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Common White Girl",
      "screen_name" : "damnitstrue",
      "indices" : [ "3", "15" ],
      "id_str" : "66714703",
      "id" : "66714703"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/damnitstrue/status/364177751646806018/photo/1",
      "source_status_id" : "364177751646806018",
      "indices" : [ "47", "69" ],
      "url" : "http://t.co/zwfHHvthzW",
      "media_url" : "http://pbs.twimg.com/media/BQ3RvFJCIAAKaFw.jpg",
      "id_str" : "364177751651000320",
      "source_user_id" : "66714703",
      "id" : "364177751651000320",
      "media_url_https" : "https://pbs.twimg.com/media/BQ3RvFJCIAAKaFw.jpg",
      "source_user_id_str" : "66714703",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "559",
          "h" : "500",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "559",
          "h" : "500",
          "resize" : "fit"
        },
        "large" : {
          "w" : "559",
          "h" : "500",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "364177751646806018",
      "display_url" : "pic.twitter.com/zwfHHvthzW"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "364178968175312896",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364178968175312896",
  "possibly_sensitive" : false,
  "created_at" : "Mon Aug 05 00:20:06 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @damnitstrue: the best time to kiss a girl: http://t.co/zwfHHvthzW",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/damnitstrue/status/364177751646806018/photo/1",
      "source_status_id" : "364177751646806018",
      "indices" : [ "47", "69" ],
      "url" : "http://t.co/zwfHHvthzW",
      "media_url" : "http://pbs.twimg.com/media/BQ3RvFJCIAAKaFw.jpg",
      "id_str" : "364177751651000320",
      "source_user_id" : "66714703",
      "id" : "364177751651000320",
      "media_url_https" : "https://pbs.twimg.com/media/BQ3RvFJCIAAKaFw.jpg",
      "source_user_id_str" : "66714703",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "559",
          "h" : "500",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "559",
          "h" : "500",
          "resize" : "fit"
        },
        "large" : {
          "w" : "559",
          "h" : "500",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "364177751646806018",
      "display_url" : "pic.twitter.com/zwfHHvthzW"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/DtX57OLAGH",
      "expanded_url" : "http://twitpic.com/d6jptj",
      "display_url" : "twitpic.com/d6jptj",
      "indices" : [ "39", "61" ]
    } ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "364178240224501762",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364178240224501762",
  "possibly_sensitive" : false,
  "created_at" : "Mon Aug 05 00:17:13 +0000 2013",
  "favorited" : false,
  "full_text" : "wishing you all a wonderful week ahead http://t.co/DtX57OLAGH",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "364098514189840384",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364098514189840384",
  "created_at" : "Sun Aug 04 19:00:25 +0000 2013",
  "favorited" : false,
  "full_text" : "behind my smiles is where i keep my pains, you think you\nknow me???? you know nothing abt my terrible\ncharacter.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Smile",
      "indices" : [ "0", "6" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "364016869717843968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364016869717843968",
  "created_at" : "Sun Aug 04 13:35:59 +0000 2013",
  "favorited" : false,
  "full_text" : "#Smile is a way to get success,\nSmile is to win the hearts.\nSmile improves ur personality.\nSo, keep smiling.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "0",
  "id_str" : "364016280099389440",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364016280099389440",
  "created_at" : "Sun Aug 04 13:33:38 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Your laugh is the cutest thing.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Unrevealed Facts",
      "screen_name" : "unrevealedfacts",
      "indices" : [ "3", "19" ],
      "id_str" : "377385959",
      "id" : "377385959"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "364016219030315008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "364016219030315008",
  "created_at" : "Sun Aug 04 13:33:24 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @UnrevealedFacts: Once you begin to dislike someone, everything they do tends to annoy you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "39" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363905364518912000",
  "id_str" : "363917649438588928",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363917649438588928",
  "in_reply_to_status_id" : "363905364518912000",
  "created_at" : "Sun Aug 04 07:01:43 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen okay, sorry abt that sweetie",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "lovequotes",
      "indices" : [ "120", "131" ]
    }, {
      "text" : "quotes",
      "indices" : [ "132", "139" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "363904518666194944",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363904518666194944",
  "created_at" : "Sun Aug 04 06:09:32 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek The faithful see the invisible, believe the incredible and receive the impossible.. #lovequotes #quotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Sherwood Juliann",
      "screen_name" : "Sherwoodbhow",
      "indices" : [ "0", "13" ],
      "id_str" : "1643745278",
      "id" : "1643745278"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "26" ],
  "favorite_count" : "0",
  "id_str" : "363904290689384448",
  "in_reply_to_user_id" : "1643745278",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363904290689384448",
  "created_at" : "Sun Aug 04 06:08:38 +0000 2013",
  "favorited" : false,
  "full_text" : "@sherwoodbhow, is it real?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Sherwoodbhow",
  "in_reply_to_user_id_str" : "1643745278"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "22", "32" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "363904006844076032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363904006844076032",
  "created_at" : "Sun Aug 04 06:07:30 +0000 2013",
  "favorited" : false,
  "full_text" : "Lol... You know what? @leeleeyen Sleeping early is very healthy!! Your body will have more time to rest ;-)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363895637701431296",
  "id_str" : "363900567690543105",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363900567690543105",
  "in_reply_to_status_id" : "363895637701431296",
  "created_at" : "Sun Aug 04 05:53:50 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen yeah, i slept very early last night... ;-)",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "G Facts",
      "screen_name" : "GoogleFacts",
      "indices" : [ "3", "15" ],
      "id_str" : "559675462",
      "id" : "559675462"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "88" ],
  "favorite_count" : "0",
  "id_str" : "363899906479493120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363899906479493120",
  "created_at" : "Sun Aug 04 05:51:13 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @GoogleFacts: A 2.5 GB disk drive in 1980 was the size of a fridge. Price: US$40,000.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "29" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363892007258697728",
  "id_str" : "363899424734314497",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363899424734314497",
  "in_reply_to_status_id" : "363892007258697728",
  "created_at" : "Sun Aug 04 05:49:18 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen outta bed already?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "19" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363896643059712001",
  "id_str" : "363898226531110912",
  "in_reply_to_user_id" : "259258056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363898226531110912",
  "in_reply_to_status_id" : "363896643059712001",
  "created_at" : "Sun Aug 04 05:44:32 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen thanx...",
  "lang" : "en",
  "in_reply_to_screen_name" : "sorXCode",
  "in_reply_to_user_id_str" : "259258056"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363896236455108608",
  "id_str" : "363896643059712001",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363896643059712001",
  "in_reply_to_status_id" : "363896236455108608",
  "created_at" : "Sun Aug 04 05:38:15 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen , yeah, thats good night... Sorry i didnt say that last night",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "363895107734732800",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363895107734732800",
  "created_at" : "Sun Aug 04 05:32:09 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: In ancient China marijuana was used to treat absent-mindedness.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363892007258697728",
  "id_str" : "363894965690449920",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363894965690449920",
  "in_reply_to_status_id" : "363892007258697728",
  "created_at" : "Sun Aug 04 05:31:35 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen ekaaro ololufe mi, seji re?",
  "lang" : "ht",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Rob Greer",
      "screen_name" : "robbygreer",
      "indices" : [ "3", "14" ],
      "id_str" : "913744615",
      "id" : "913744615"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "89" ],
  "favorite_count" : "0",
  "id_str" : "363890856186900480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363890856186900480",
  "created_at" : "Sun Aug 04 05:15:15 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @RobbyGreer: It is not wanting to win that makes you a winner; it is refusing to fail.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "363890670253408257",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363890670253408257",
  "created_at" : "Sun Aug 04 05:14:31 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: All I need in this life of sin is me and my girlfriend - Down to ride to the bloody end, just me and my girlfriend. - Tupac",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "princess",
      "screen_name" : "sayingsforgirls",
      "indices" : [ "3", "19" ],
      "id_str" : "256986185",
      "id" : "256986185"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "363890573243342848",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363890573243342848",
  "created_at" : "Sun Aug 04 05:14:08 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @SayingsForGirls: We fear rejection, want attention, crave affection and dream of perfection.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "friendshipday",
      "indices" : [ "40", "54" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/xNQFxlMyWQ",
      "expanded_url" : "http://twitpic.com/d6e0jj",
      "display_url" : "twitpic.com/d6e0jj",
      "indices" : [ "56", "78" ]
    } ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "363890415742615552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363890415742615552",
  "possibly_sensitive" : false,
  "created_at" : "Sun Aug 04 05:13:30 +0000 2013",
  "favorited" : false,
  "full_text" : "Friends make the world go 'Round. Happy #friendshipday! http://t.co/xNQFxlMyWQ",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Friendshipday",
      "indices" : [ "6", "20" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/hFFIWHD6Qr",
      "expanded_url" : "http://twitpic.com/d6dz5m",
      "display_url" : "twitpic.com/d6dz5m",
      "indices" : [ "24", "46" ]
    } ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "id_str" : "363888679720202240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363888679720202240",
  "possibly_sensitive" : false,
  "created_at" : "Sun Aug 04 05:06:36 +0000 2013",
  "favorited" : false,
  "full_text" : "Happy #Friendshipday!!! http://t.co/hFFIWHD6Qr",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "363873539075878912",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363873539075878912",
  "created_at" : "Sun Aug 04 04:06:26 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Those who look like they are worth trusting sometimes aren't.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "363779678534131712",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363779678534131712",
  "created_at" : "Sat Aug 03 21:53:28 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Conquer your bad habits or they will conquer you. - Rob Gilbert",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LargerThanWords™",
      "screen_name" : "TheLifeDiaries",
      "indices" : [ "3", "18" ],
      "id_str" : "207426991",
      "id" : "207426991"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "121" ],
  "favorite_count" : "0",
  "id_str" : "363715573941022720",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363715573941022720",
  "created_at" : "Sat Aug 03 17:38:45 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheLifeDiaries: Love is a combination of care, commitment, communication, loyalty, responsibility, respect and trust.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Motherteresa",
      "indices" : [ "112", "125" ]
    }, {
      "text" : "gooddeeds",
      "indices" : [ "126", "136" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mother Teresa",
      "screen_name" : "StMotherTheresa",
      "indices" : [ "3", "19" ],
      "id_str" : "35274401",
      "id" : "35274401"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "136" ],
  "favorite_count" : "0",
  "id_str" : "363424206174040064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363424206174040064",
  "created_at" : "Fri Aug 02 22:20:57 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @StMotherTheresa: “I can do things you cannot, you can do things I cannot; together we can do great things.” #Motherteresa #gooddeeds",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "363422456796942336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363422456796942336",
  "created_at" : "Fri Aug 02 22:14:00 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Factsionary: Peanut butter is an excellent cleaner for leather furniture. Just rub a small amount on and work it in in a circular motio…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "LargerThanWords",
      "indices" : [ "100", "116" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "116" ],
  "favorite_count" : "0",
  "id_str" : "363421276142333952",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363421276142333952",
  "created_at" : "Fri Aug 02 22:09:18 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: Be who you want to be, go where you want to go, and love who you want to love. #LargerThanWords",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "reminisce",
      "indices" : [ "70", "80" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "#OjaDaddy",
      "screen_name" : "IamReminisce",
      "indices" : [ "81", "94" ],
      "id_str" : "45863020",
      "id" : "45863020"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "363419335311638528",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363419335311638528",
  "created_at" : "Fri Aug 02 22:01:36 +0000 2013",
  "favorited" : false,
  "full_text" : "Music always helps, no matter what you're going through. listening to #reminisce @Iamreminisce",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363415401155538944",
  "id_str" : "363418082355589121",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363418082355589121",
  "in_reply_to_status_id" : "363415401155538944",
  "created_at" : "Fri Aug 02 21:56:37 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen Aries?? the Aries-Virgo bond has always and will always be a strong one... luv ya bby",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "39" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363415111421399040",
  "id_str" : "363416036919767040",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363416036919767040",
  "in_reply_to_status_id" : "363415111421399040",
  "created_at" : "Fri Aug 02 21:48:29 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen all thanx to you ﹙&gt;3&lt;﹚",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "19" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363414546704121856",
  "id_str" : "363415133898293248",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363415133898293248",
  "in_reply_to_status_id" : "363414546704121856",
  "created_at" : "Fri Aug 02 21:44:54 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen (｡’▽’｡)♡",
  "lang" : "und",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "iLyricsPost",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "0",
  "id_str" : "363414537720299521",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363414537720299521",
  "created_at" : "Fri Aug 02 21:42:32 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @iLyricsPost: \"Everything you do is magic.\" - One Direction",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "63", "73" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "363413382906380289",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363413382906380289",
  "created_at" : "Fri Aug 02 21:37:57 +0000 2013",
  "favorited" : false,
  "full_text" : "One of the greatest feelings is knowing you made someone smile @leeleeyen",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "34" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363403752793190400",
  "id_str" : "363411489236844545",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363411489236844545",
  "in_reply_to_status_id" : "363403752793190400",
  "created_at" : "Fri Aug 02 21:30:25 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen the best effect I guess",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "16" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363404772990140416",
  "id_str" : "363411299230683136",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363411299230683136",
  "in_reply_to_status_id" : "363404772990140416",
  "created_at" : "Fri Aug 02 21:29:40 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen （＾_＾）",
  "lang" : "und",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "19" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363405717002137600",
  "id_str" : "363410647268077568",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363410647268077568",
  "in_reply_to_status_id" : "363405717002137600",
  "created_at" : "Fri Aug 02 21:27:04 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen yeah, u?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Ｖｉｒｇｏ",
      "screen_name" : "VirgoNation",
      "indices" : [ "3", "15" ],
      "id_str" : "271219664",
      "id" : "271219664"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "123" ],
  "favorite_count" : "0",
  "id_str" : "363404501232795648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363404501232795648",
  "created_at" : "Fri Aug 02 21:02:39 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @VirgoNation: People constantly fall in and out of love, but Virgos will only truly love a few people in their lifetime.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "363404276401721344",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363404276401721344",
  "created_at" : "Fri Aug 02 21:01:45 +0000 2013",
  "favorited" : false,
  "full_text" : "I am not a genius; I am what a genius wants to be.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "•",
      "screen_name" : "FlirtyWords",
      "indices" : [ "3", "15" ],
      "id_str" : "2860112704",
      "id" : "2860112704"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "363402876930228224",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363402876930228224",
  "created_at" : "Fri Aug 02 20:56:12 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @FlirtyWords: I'll ignore every one of them because I only want you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "17" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363052201729474560",
  "id_str" : "363053881162756096",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363053881162756096",
  "in_reply_to_status_id" : "363052201729474560",
  "created_at" : "Thu Aug 01 21:49:25 +0000 2013",
  "favorited" : false,
  "full_text" : "@Leeleeyen oda ro",
  "lang" : "pt",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "BrainyQuote",
      "screen_name" : "BrainyQuote",
      "indices" : [ "3", "15" ],
      "id_str" : "29573746",
      "id" : "29573746"
    } ],
    "urls" : [ {
      "url" : "http://t.co/VH1Hn0Uo22",
      "expanded_url" : "http://www.brainyquote.com/quotes/authors/w/william_r_alger.html",
      "display_url" : "brainyquote.com/quotes/authors…",
      "indices" : [ "94", "116" ]
    } ]
  },
  "display_text_range" : [ "0", "116" ],
  "favorite_count" : "0",
  "id_str" : "363050243790999552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363050243790999552",
  "possibly_sensitive" : false,
  "created_at" : "Thu Aug 01 21:34:57 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BrainyQuote: He who has no wish to be happier is the happiest of men. - William R. Alger  http://t.co/VH1Hn0Uo22",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "363048640170192896",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363048640170192896",
  "created_at" : "Thu Aug 01 21:28:35 +0000 2013",
  "favorited" : false,
  "full_text" : "@Leeleeyen, I'm in babe",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "101", "111" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "111" ],
  "favorite_count" : "0",
  "id_str" : "363041394446708738",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363041394446708738",
  "created_at" : "Thu Aug 01 20:59:48 +0000 2013",
  "favorited" : false,
  "full_text" : "Trust is like an eraser, It gets smaller &amp; smaller after every mistake... can i have your trust? @leeleeyen",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "25" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363039142089068544",
  "id_str" : "363040216699138048",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363040216699138048",
  "in_reply_to_status_id" : "363039142089068544",
  "created_at" : "Thu Aug 01 20:55:07 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen im fooled! •_°",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "35" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363036408648589312",
  "id_str" : "363038563497439233",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363038563497439233",
  "in_reply_to_status_id" : "363036408648589312",
  "created_at" : "Thu Aug 01 20:48:33 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen  if I may know, who? ;-)",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "forever",
      "indices" : [ "39", "47" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "48" ],
  "favorite_count" : "0",
  "id_str" : "363030607527292929",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363030607527292929",
  "created_at" : "Thu Aug 01 20:16:56 +0000 2013",
  "favorited" : false,
  "full_text" : "Let’s be nothing because nothing lasts #forever.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Lilian mwandira",
      "screen_name" : "leeleeyen",
      "indices" : [ "0", "10" ],
      "id_str" : "2507880693",
      "id" : "2507880693"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "363028784426921984",
  "id_str" : "363029305083047936",
  "in_reply_to_user_id" : "1181208025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363029305083047936",
  "in_reply_to_status_id" : "363028784426921984",
  "created_at" : "Thu Aug 01 20:11:45 +0000 2013",
  "favorited" : false,
  "full_text" : "@leeleeyen that's  what im doing right now babe",
  "lang" : "en",
  "in_reply_to_screen_name" : "Royale_Chick",
  "in_reply_to_user_id_str" : "1181208025"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "id_str" : "363026351197925376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "363026351197925376",
  "created_at" : "Thu Aug 01 20:00:01 +0000 2013",
  "favorited" : false,
  "full_text" : "Don't give up on things that make you smile.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "together",
      "indices" : [ "27", "36" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "361546208344416256",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "361546208344416256",
  "created_at" : "Sun Jul 28 17:58:27 +0000 2013",
  "favorited" : false,
  "full_text" : "Alone we can do so little; #together we can do so much. -Helen Keller",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "id_str" : "361002587446714368",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "361002587446714368",
  "created_at" : "Sat Jul 27 05:58:18 +0000 2013",
  "favorited" : false,
  "full_text" : "\"To the world you may be an icon, a revolutionary, a billionaire; but to the Angel of Death you're just another name on\nthe list\" Good mrn",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "354338770306338816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "354338770306338816",
  "created_at" : "Mon Jul 08 20:38:40 +0000 2013",
  "favorited" : false,
  "full_text" : "straight like 6 o'clock, hear ya haterz screaming but I dnt give a f**k... lmao",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "100" ],
  "favorite_count" : "0",
  "id_str" : "351721540812939266",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "351721540812939266",
  "created_at" : "Mon Jul 01 15:18:44 +0000 2013",
  "favorited" : false,
  "full_text" : "Ds life z a precious gift, so dnt get 2 crazy,it's nt worth d risk, u gotta take things easy Y.O.L.O",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "17", "23" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "id_str" : "342879226283831296",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "342879226283831296",
  "created_at" : "Fri Jun 07 05:42:32 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: #Virgo's are investigators. They never fully trust anyone and are always looking for the bad.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "0",
  "id_str" : "342734721391931392",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "342734721391931392",
  "created_at" : "Thu Jun 06 20:08:19 +0000 2013",
  "favorited" : false,
  "full_text" : "pain is temporary , quitting last 4eva",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "princess",
      "indices" : [ "56", "65" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "65" ],
  "favorite_count" : "0",
  "id_str" : "341784010718076928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "341784010718076928",
  "created_at" : "Tue Jun 04 05:10:32 +0000 2013",
  "favorited" : false,
  "full_text" : "Went to bed thinking of you, even now you're on my mind #princess",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "newmusics",
      "indices" : [ "49", "59" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "341783121718558722",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "341783121718558722",
  "created_at" : "Tue Jun 04 05:07:00 +0000 2013",
  "favorited" : false,
  "full_text" : "Tired of listening to old songs, wanna listen to #newmusics",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "mid",
      "indices" : [ "5", "9" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "340689171154870274",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "340689171154870274",
  "created_at" : "Sat Jun 01 04:40:02 +0000 2013",
  "favorited" : false,
  "full_text" : "It's #mid-year, Happy new month! Goodness and mercy shall follow us all the days of our life (amen)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "value",
      "indices" : [ "61", "67" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "339571628499415044",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "339571628499415044",
  "created_at" : "Wed May 29 02:39:19 +0000 2013",
  "favorited" : false,
  "full_text" : "Never take your heart on a journey without your brain. Place #value on yourself.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Killa Quotes",
      "screen_name" : "KillaQuotes",
      "indices" : [ "3", "15" ],
      "id_str" : "156917110",
      "id" : "156917110"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "134" ],
  "favorite_count" : "0",
  "id_str" : "338531853378134016",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "338531853378134016",
  "created_at" : "Sun May 26 05:47:38 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @KillaQuotes: The places that Ive been, the things that I have seen - what you have as nightmares, are what I have as dreams. - DMX",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "youshouldbeslapped",
      "indices" : [ "0", "19" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "id_str" : "338531706120327168",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "338531706120327168",
  "created_at" : "Sun May 26 05:47:03 +0000 2013",
  "favorited" : false,
  "full_text" : "#youshouldbeslapped if u call men in black uniform, checking cars particulars by the road side on your way to a neighboring town soldiers.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "UCLfinal",
      "indices" : [ "61", "70" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "338402878987333632",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "338402878987333632",
  "created_at" : "Sat May 25 21:15:08 +0000 2013",
  "favorited" : false,
  "full_text" : "***yawns*** really tired, can't believe I stayed up late for #UCLfinal (Itz worth it though)... Oh! Tomorrow is Sunday!! Going to bed now!!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "UCLfinal",
      "indices" : [ "21", "30" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "UEFA Champions League",
      "screen_name" : "ChampionsLeague",
      "indices" : [ "3", "19" ],
      "id_str" : "627673190",
      "id" : "627673190"
    }, {
      "name" : "FC Bayern München",
      "screen_name" : "FCBayern",
      "indices" : [ "39", "48" ],
      "id_str" : "773069256",
      "id" : "773069256"
    }, {
      "name" : "Borussia Dortmund",
      "screen_name" : "BVB",
      "indices" : [ "53", "57" ],
      "id_str" : "165699676",
      "id" : "165699676"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "338398093785579521",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "338398093785579521",
  "created_at" : "Sat May 25 20:56:07 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ChampionsLeague: #UCLfinal result: @FCBayern 2-1 @BVB",
  "lang" : "lt"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "UCLfinal",
      "indices" : [ "60", "69" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "UEFA Champions League",
      "screen_name" : "ChampionsLeague",
      "indices" : [ "3", "19" ],
      "id_str" : "627673190",
      "id" : "627673190"
    }, {
      "name" : "FC Bayern München",
      "screen_name" : "FCBayern",
      "indices" : [ "37", "46" ],
      "id_str" : "773069256",
      "id" : "773069256"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "338398001485721602",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "338398001485721602",
  "created_at" : "Sat May 25 20:55:45 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ChampionsLeague: Congratulations @FCBayern! The 2012/13 #UCLfinal winners.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UEFA Champions League",
      "screen_name" : "ChampionsLeague",
      "indices" : [ "3", "19" ],
      "id_str" : "627673190",
      "id" : "627673190"
    }, {
      "name" : "FC Bayern München",
      "screen_name" : "FCBayern",
      "indices" : [ "46", "55" ],
      "id_str" : "773069256",
      "id" : "773069256"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/ChampionsLeague/status/338397159827316738/photo/1",
      "source_status_id" : "338397159827316738",
      "indices" : [ "79", "101" ],
      "url" : "http://t.co/ZWRxGv5Cpy",
      "media_url" : "http://pbs.twimg.com/media/BLI6bIkCIAIyWeu.jpg",
      "id_str" : "338397159835705346",
      "source_user_id" : "627673190",
      "id" : "338397159835705346",
      "media_url_https" : "https://pbs.twimg.com/media/BLI6bIkCIAIyWeu.jpg",
      "source_user_id_str" : "627673190",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "479",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1444",
          "h" : "2048",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "846",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "338397159827316738",
      "display_url" : "pic.twitter.com/ZWRxGv5Cpy"
    } ],
    "hashtags" : [ {
      "text" : "UCLfinal",
      "indices" : [ "58", "67" ]
    } ]
  },
  "display_text_range" : [ "0", "101" ],
  "favorite_count" : "0",
  "id_str" : "338397689890877441",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "338397689890877441",
  "possibly_sensitive" : false,
  "created_at" : "Sat May 25 20:54:31 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ChampionsLeague: Jupp Heynckes celebrates @FCBayern's #UCLfinal triumph... http://t.co/ZWRxGv5Cpy",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/ChampionsLeague/status/338397159827316738/photo/1",
      "source_status_id" : "338397159827316738",
      "indices" : [ "79", "101" ],
      "url" : "http://t.co/ZWRxGv5Cpy",
      "media_url" : "http://pbs.twimg.com/media/BLI6bIkCIAIyWeu.jpg",
      "id_str" : "338397159835705346",
      "source_user_id" : "627673190",
      "id" : "338397159835705346",
      "media_url_https" : "https://pbs.twimg.com/media/BLI6bIkCIAIyWeu.jpg",
      "source_user_id_str" : "627673190",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "479",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1444",
          "h" : "2048",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "846",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "338397159827316738",
      "display_url" : "pic.twitter.com/ZWRxGv5Cpy"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Bayern",
      "indices" : [ "0", "7" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "0",
  "id_str" : "338396554203381760",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "338396554203381760",
  "created_at" : "Sat May 25 20:50:00 +0000 2013",
  "favorited" : false,
  "full_text" : "#Bayern Munich win champions league!!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Arjen_Robben",
      "indices" : [ "0", "13" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "338395773492416512",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "338395773492416512",
  "created_at" : "Sat May 25 20:46:54 +0000 2013",
  "favorited" : false,
  "full_text" : "#Arjen_Robben scores the crucial goal",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "myheart",
      "indices" : [ "35", "43" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "338206244038901760",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "338206244038901760",
  "created_at" : "Sat May 25 08:13:46 +0000 2013",
  "favorited" : false,
  "full_text" : "You're the lyrics to the melody of #myheart",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "337427918735155200",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "337427918735155200",
  "created_at" : "Thu May 23 04:40:59 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Masklophobia is the fear of seeing huge animal mascots.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "cool",
      "indices" : [ "11", "16" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Charly H.mac Dippsy",
      "screen_name" : "Hicez_cgp",
      "indices" : [ "0", "10" ],
      "id_str" : "1439544385",
      "id" : "1439544385"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "22" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "337424111879979008",
  "id_str" : "337427583228600321",
  "in_reply_to_user_id" : "1439544385",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "337427583228600321",
  "in_reply_to_status_id" : "337424111879979008",
  "created_at" : "Thu May 23 04:39:39 +0000 2013",
  "favorited" : false,
  "full_text" : "@hicez_cgp #cool (*.*)",
  "lang" : "und",
  "in_reply_to_screen_name" : "Hicez_cgp",
  "in_reply_to_user_id_str" : "1439544385"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ "0", "11" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "42" ],
  "favorite_count" : "0",
  "id_str" : "337120249004580864",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "337120249004580864",
  "created_at" : "Wed May 22 08:18:25 +0000 2013",
  "favorited" : false,
  "full_text" : "#nowplaying Say Goodbye Hollywood - Eminem",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "128" ],
  "favorite_count" : "0",
  "id_str" : "337096139977404416",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "337096139977404416",
  "created_at" : "Wed May 22 06:42:37 +0000 2013",
  "favorited" : false,
  "full_text" : "The 3 C's in life; Choice, Chance, Change. You must make the Choice, to take the Chance, if you want anything in life to Change.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Tweets™",
      "screen_name" : "Lmao",
      "indices" : [ "3", "8" ],
      "id_str" : "237634998",
      "id" : "237634998"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "337090700896247808",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "337090700896247808",
  "created_at" : "Wed May 22 06:21:00 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Lmao: Shout Out to all the beautiful women who don't need to dress half naked to get a man's attention. Stay classy! The rest of you, c…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "336957420565827585",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "336957420565827585",
  "created_at" : "Tue May 21 21:31:24 +0000 2013",
  "favorited" : false,
  "full_text" : "Love doesn't make the world go round; love is what makes the ride worthwhile - Elizabeth Browning",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "336512246509346817",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "336512246509346817",
  "created_at" : "Mon May 20 16:02:26 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Factsionary: Honey is the only food that will not rot. A jar of honey may remain edible for over 3000 years.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "nevergiveup",
      "indices" : [ "0", "12" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "id_str" : "336511783160393728",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "336511783160393728",
  "created_at" : "Mon May 20 16:00:35 +0000 2013",
  "favorited" : false,
  "full_text" : "#nevergiveup on your dreams",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ "3", "12" ],
      "id_str" : "500704345",
      "id" : "500704345"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "124" ],
  "favorite_count" : "0",
  "id_str" : "336094721434853376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "336094721434853376",
  "created_at" : "Sun May 19 12:23:20 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Pontifex: The Holy Spirit transforms and renews us, creates harmony and unity, and gives us courage and joy for mission.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "truefriendswillalways",
      "indices" : [ "0", "22" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "336094307876495360",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "336094307876495360",
  "created_at" : "Sun May 19 12:21:41 +0000 2013",
  "favorited" : false,
  "full_text" : "#truefriendswillalways have your back",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ "0", "11" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "0",
  "id_str" : "336093702684540928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "336093702684540928",
  "created_at" : "Sun May 19 12:19:17 +0000 2013",
  "favorited" : false,
  "full_text" : "#nowplaying As long as you love me - backstreetboys",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "334894220815003648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "334894220815003648",
  "created_at" : "Thu May 16 04:52:58 +0000 2013",
  "favorited" : false,
  "full_text" : "Italian: Dio vi benedica tutti.\nEnglish: God bless you all.",
  "lang" : "it"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "0",
  "id_str" : "334534468134137856",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "334534468134137856",
  "created_at" : "Wed May 15 05:03:27 +0000 2013",
  "favorited" : false,
  "full_text" : "Good people do bad things. Learn to forgive and move on.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "334396779665694722",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "334396779665694722",
  "created_at" : "Tue May 14 19:56:19 +0000 2013",
  "favorited" : false,
  "full_text" : "If GOD is all you have, then you have all you need",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "impossible",
      "indices" : [ "10", "21" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "24" ],
  "favorite_count" : "0",
  "id_str" : "334015023737348096",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "334015023737348096",
  "created_at" : "Mon May 13 18:39:22 +0000 2013",
  "favorited" : false,
  "full_text" : "Never say #impossible...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "333977978008662017",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "333977978008662017",
  "created_at" : "Mon May 13 16:12:09 +0000 2013",
  "favorited" : false,
  "full_text" : "Our memories aren't that reliable. What we remember is usually altered by our emotions and other thoughts at that time.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "333977507143495682",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "333977507143495682",
  "created_at" : "Mon May 13 16:10:17 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Factsionary: 70% of people suffer from allodoxaphobia, the fear of annoying others.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "CuteLoveMsgs",
      "indices" : [ "3", "16" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "333974677124947968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "333974677124947968",
  "created_at" : "Mon May 13 15:59:02 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @CuteLoveMsgs: One day you'll be just a memory to people, so make sure you're a good one.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "29" ],
  "favorite_count" : "0",
  "id_str" : "333463580198440960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "333463580198440960",
  "created_at" : "Sun May 12 06:08:07 +0000 2013",
  "favorited" : false,
  "full_text" : "Shits happen but life goes on",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "333190491556429825",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "333190491556429825",
  "created_at" : "Sat May 11 12:02:58 +0000 2013",
  "favorited" : false,
  "full_text" : "You've got my focus divided like a fraction - skales",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "SONGLYRlCS",
      "indices" : [ "3", "14" ],
      "id_str" : "2378813269",
      "id" : "2378813269"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "333189809730359297",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "333189809730359297",
  "created_at" : "Sat May 11 12:00:15 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @SONGLYRlCS: \"I wanna live, not just survive.\" - The Cab",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "NeverGiveUp",
      "indices" : [ "0", "12" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "36" ],
  "favorite_count" : "0",
  "id_str" : "332934249583886336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "332934249583886336",
  "created_at" : "Fri May 10 19:04:45 +0000 2013",
  "favorited" : false,
  "full_text" : "#NeverGiveUp, great things take time",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "34" ],
  "favorite_count" : "0",
  "id_str" : "332220983836569600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "332220983836569600",
  "created_at" : "Wed May 08 19:50:29 +0000 2013",
  "favorited" : false,
  "full_text" : "I really love you come what may...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "332217595656822784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "332217595656822784",
  "created_at" : "Wed May 08 19:37:01 +0000 2013",
  "favorited" : false,
  "full_text" : "When the going gets tough, only the tough get going...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "G Facts",
      "screen_name" : "GoogleFacts",
      "indices" : [ "3", "15" ],
      "id_str" : "559675462",
      "id" : "559675462"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "0",
  "id_str" : "331104490348486657",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "331104490348486657",
  "created_at" : "Sun May 05 17:53:56 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @GoogleFacts: When dreaming, your body is paralyzed.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "@mostlymgc",
      "screen_name" : "ADMlRABLE",
      "indices" : [ "3", "13" ],
      "id_str" : "2954077855",
      "id" : "2954077855"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "101" ],
  "favorite_count" : "0",
  "id_str" : "331104423730356227",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "331104423730356227",
  "created_at" : "Sun May 05 17:53:40 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @ADMlRABLE: To be honest, I don't have much to offer. But I'll still give you everything I've got.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Boo ",
      "screen_name" : "AdorabIeBoo",
      "indices" : [ "3", "15" ],
      "id_str" : "1460051552",
      "id" : "1460051552"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "331104308730929153",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "331104308730929153",
  "created_at" : "Sun May 05 17:53:13 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @AdorabIeBoo: i'm not lazy i just dont wanna do anything.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "avemaria",
      "indices" : [ "0", "9" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "0",
  "id_str" : "330930263741849600",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "330930263741849600",
  "created_at" : "Sun May 05 06:21:37 +0000 2013",
  "favorited" : false,
  "full_text" : "#avemaria, gratia plena, dominus tecum, benedicta tu...",
  "lang" : "es"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "PObahiagbon",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "330805303580962817",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "330805303580962817",
  "created_at" : "Sat May 04 22:05:05 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @PObahiagbon: A bit like Khan wanting to fight Flyod... Disaster",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Philosophy Muse",
      "screen_name" : "philosophy_muse",
      "indices" : [ "3", "19" ],
      "id_str" : "533832747",
      "id" : "533832747"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "84" ],
  "favorite_count" : "0",
  "id_str" : "330718019212947458",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "330718019212947458",
  "created_at" : "Sat May 04 16:18:14 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Philosophy_Muse: Sometimes the easiest thing is also the hardest: to disconnect.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Остапушкинa Лия",
      "screen_name" : "I_GO_DYE",
      "indices" : [ "3", "12" ],
      "id_str" : "2813824506",
      "id" : "2813824506"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "0",
  "id_str" : "330717646595174400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "330717646595174400",
  "created_at" : "Sat May 04 16:16:46 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @I_GO_DYE: Saw a Lady 2day who bleached so much..... She looked brighter than her Future..",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Lemon",
      "indices" : [ "0", "6" ]
    }, {
      "text" : "immune_function",
      "indices" : [ "77", "93" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "330626349553303552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "330626349553303552",
  "created_at" : "Sat May 04 10:13:59 +0000 2013",
  "favorited" : false,
  "full_text" : "#Lemon enhances iron absorption in the body; iron plays an important role in #immune_function.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "330567999289438208",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "330567999289438208",
  "created_at" : "Sat May 04 06:22:07 +0000 2013",
  "favorited" : false,
  "full_text" : "Itz gon be more fun if there's a day btw saturday and sunday...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "BadDecisions",
      "indices" : [ "0", "13" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "330425523459211266",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "330425523459211266",
  "created_at" : "Fri May 03 20:55:58 +0000 2013",
  "favorited" : false,
  "full_text" : "#BadDecisions aren't always bad because sometimes they become great stories...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Shocking Facts",
      "screen_name" : "ShockingFacts_",
      "indices" : [ "3", "18" ],
      "id_str" : "2374534730",
      "id" : "2374534730"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "0",
  "id_str" : "330337763075440643",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "330337763075440643",
  "created_at" : "Fri May 03 15:07:14 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @shockingfacts_: Hugging helps lower blood pressure.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "hope",
      "indices" : [ "53", "58" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "329978873594916864",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "329978873594916864",
  "created_at" : "Thu May 02 15:21:08 +0000 2013",
  "favorited" : false,
  "full_text" : "Even on a cloudy day, the sun is shinning somewhere. #hope",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Itzinyou",
      "indices" : [ "0", "9" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "9" ],
  "favorite_count" : "0",
  "id_str" : "329971505360412673",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "329971505360412673",
  "created_at" : "Thu May 02 14:51:52 +0000 2013",
  "favorited" : false,
  "full_text" : "#Itzinyou",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "329848331419398144",
  "id_str" : "329850411995525120",
  "in_reply_to_user_id" : "486118647",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "329850411995525120",
  "in_reply_to_status_id" : "329848331419398144",
  "created_at" : "Thu May 02 06:50:41 +0000 2013",
  "favorited" : false,
  "full_text" : "@neeggaboy Itz been ages, where've you been?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Moboboy123",
  "in_reply_to_user_id_str" : "486118647"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "22" ],
  "favorite_count" : "0",
  "id_str" : "329839812951564288",
  "in_reply_to_user_id" : "486118647",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "329839812951564288",
  "created_at" : "Thu May 02 06:08:34 +0000 2013",
  "favorited" : false,
  "full_text" : "@neeggaboy, what's up?",
  "lang" : "en",
  "in_reply_to_screen_name" : "Moboboy123",
  "in_reply_to_user_id_str" : "486118647"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "329838345876299776",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "329838345876299776",
  "created_at" : "Thu May 02 06:02:44 +0000 2013",
  "favorited" : false,
  "full_text" : "Your best is not your limit and your limit is not your best, just put your best in your limit...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "happynewmonth",
      "indices" : [ "67", "81" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "329460946592468992",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "329460946592468992",
  "created_at" : "Wed May 01 05:03:05 +0000 2013",
  "favorited" : false,
  "full_text" : "may ur dreams come true this month. may all ur wishes be fulfilled #happynewmonth",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "17", "23" ]
    }, {
      "text" : "Virgo",
      "indices" : [ "79", "85" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "329317334865027075",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "329317334865027075",
  "created_at" : "Tue Apr 30 19:32:25 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: #Virgo only enjoys sex when it is with someone who has gained #Virgo's confidence.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "0",
  "id_str" : "327891761940795392",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "327891761940795392",
  "created_at" : "Fri Apr 26 21:07:42 +0000 2013",
  "favorited" : false,
  "full_text" : "Club tonight, JAMB tomorrow... Lmao!!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "wakingup",
      "indices" : [ "0", "9" ]
    }, {
      "text" : "thankGod",
      "indices" : [ "40", "49" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "49" ],
  "favorite_count" : "0",
  "id_str" : "327628700113854464",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "327628700113854464",
  "created_at" : "Fri Apr 26 03:42:23 +0000 2013",
  "favorited" : false,
  "full_text" : "#wakingup to see eveything is okay... I #thankGod",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "0",
  "id_str" : "327442554503172096",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "327442554503172096",
  "created_at" : "Thu Apr 25 15:22:43 +0000 2013",
  "favorited" : false,
  "full_text" : "shit! Itz raining already!! Going to bed noW!!! ;-)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "327438468168970240",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "327438468168970240",
  "created_at" : "Thu Apr 25 15:06:28 +0000 2013",
  "favorited" : false,
  "full_text" : "Falling in love produces the same type of high as doing cocaine",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "26" ],
  "favorite_count" : "0",
  "id_str" : "327437096417644544",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "327437096417644544",
  "created_at" : "Thu Apr 25 15:01:01 +0000 2013",
  "favorited" : false,
  "full_text" : "I just can't get enough...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "excellence",
      "indices" : [ "13", "24" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "324730817580507136",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "324730817580507136",
  "created_at" : "Thu Apr 18 03:47:14 +0000 2013",
  "favorited" : false,
  "full_text" : "The price of #excellence is discipline; the cost of mediocrity is disappointment",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "6" ],
  "favorite_count" : "0",
  "id_str" : "319570625855361025",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "319570625855361025",
  "created_at" : "Wed Apr 03 22:02:29 +0000 2013",
  "favorited" : false,
  "full_text" : "Gdhhsg",
  "lang" : "in"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "famous",
      "indices" : [ "115", "122" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Neeggaboy",
      "indices" : [ "3", "13" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "128" ],
  "favorite_count" : "0",
  "id_str" : "308939059340902402",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "308939059340902402",
  "created_at" : "Tue Mar 05 13:56:26 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @Neeggaboy: Can you sleep all day \n      And still get paid ??? \nNigga's neeggaboy is herer let the game begins #famous mode#",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLUWAG♥LDIE",
      "screen_name" : "GoldieHarvey",
      "indices" : [ "110", "123" ],
      "id_str" : "67554233",
      "id" : "67554233"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "1",
  "id_str" : "302325790928953344",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "302325790928953344",
  "created_at" : "Fri Feb 15 07:57:40 +0000 2013",
  "favorited" : false,
  "full_text" : "On earth you hustle, pray that you find a place to rest in heaven, though its dawning of a new day, ama light @GoldieHarvey a candle.. R.I.P",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Ally Emma",
      "screen_name" : "deerlungs",
      "indices" : [ "3", "13" ],
      "id_str" : "484897859",
      "id" : "484897859"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "0",
  "id_str" : "289608986590838784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "289608986590838784",
  "created_at" : "Fri Jan 11 05:45:37 +0000 2013",
  "favorited" : false,
  "full_text" : "RT @deerlungs: \"If you want to leave, you can. I'll remember you, though. I remember everyone who leaves.\" \n— Lilo &amp; Stitch",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "1" ],
  "favorite_count" : "0",
  "id_str" : "279035893917036546",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "279035893917036546",
  "created_at" : "Thu Dec 13 01:31:56 +0000 2012",
  "favorited" : false,
  "full_text" : "2",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "inspire_us",
      "indices" : [ "48", "59" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "277641741539098624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "277641741539098624",
  "created_at" : "Sun Dec 09 05:12:04 +0000 2012",
  "favorited" : false,
  "full_text" : "Neva fear standing up for things you belive in. #inspire_us",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "18" ],
  "favorite_count" : "0",
  "id_str" : "238578761254195200",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "238578761254195200",
  "created_at" : "Thu Aug 23 10:09:43 +0000 2012",
  "favorited" : false,
  "full_text" : "Strong walls shake",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Nigeria Newsdesk",
      "screen_name" : "NigeriaNewsdesk",
      "indices" : [ "0", "16" ],
      "id_str" : "91316071",
      "id" : "91316071"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "109" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "207150628219265024",
  "id_str" : "207157922956967937",
  "in_reply_to_user_id" : "91316071",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "207157922956967937",
  "in_reply_to_status_id" : "207150628219265024",
  "created_at" : "Mon May 28 17:14:32 +0000 2012",
  "favorited" : false,
  "full_text" : "@nigerianewsdesk lol... Funny. Hw will tm b able to say amen, cos tz like saying amen to their source of ***₹",
  "lang" : "en",
  "in_reply_to_screen_name" : "NigeriaNewsdesk",
  "in_reply_to_user_id_str" : "91316071"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "207156888272519169",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "207156888272519169",
  "created_at" : "Mon May 28 17:10:25 +0000 2012",
  "favorited" : false,
  "full_text" : "My leather is so soft, my top is so soft...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "182285334527213568",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "182285334527213568",
  "created_at" : "Wed Mar 21 01:59:45 +0000 2012",
  "favorited" : false,
  "full_text" : "Kiss me and you will see how important i am",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mozat.com\" rel=\"nofollow\">Mozat for tweets</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "11" ],
  "favorite_count" : "0",
  "id_str" : "174396823711121408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "174396823711121408",
  "created_at" : "Tue Feb 28 07:33:37 +0000 2012",
  "favorited" : false,
  "full_text" : "K@girlnotes",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mozat.com\" rel=\"nofollow\">Mozat for tweets</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Girl Notes♔",
      "screen_name" : "GirlNotes",
      "indices" : [ "3", "13" ],
      "id_str" : "227121370",
      "id" : "227121370"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "174396618643218432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "174396618643218432",
  "created_at" : "Tue Feb 28 07:32:48 +0000 2012",
  "favorited" : false,
  "full_text" : "RT @girlnotes: My life. My choices. My problems. My mistakes. My lessons. Not your business. Mind your own problems before you talk abou ...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Girl Notes♔",
      "screen_name" : "GirlNotes",
      "indices" : [ "0", "10" ],
      "id_str" : "227121370",
      "id" : "227121370"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "171300706542825472",
  "id_str" : "171303001653395456",
  "in_reply_to_user_id" : "227121370",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "171303001653395456",
  "in_reply_to_status_id" : "171300706542825472",
  "created_at" : "Sun Feb 19 18:39:52 +0000 2012",
  "favorited" : false,
  "full_text" : "@girlnotes really difficult!",
  "lang" : "en",
  "in_reply_to_screen_name" : "GirlNotes",
  "in_reply_to_user_id_str" : "227121370"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "170829062963605505",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "170829062963605505",
  "created_at" : "Sat Feb 18 11:16:37 +0000 2012",
  "favorited" : false,
  "full_text" : "Have you hugged an idiot today? Me neither, come here!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "NeverTellAGirl",
      "indices" : [ "0", "15" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "170828040287420416",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "170828040287420416",
  "created_at" : "Sat Feb 18 11:12:33 +0000 2012",
  "favorited" : false,
  "full_text" : "#NeverTellAGirl you've been in love before.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "NeverTellAGirl",
      "indices" : [ "0", "15" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "0",
  "id_str" : "170827274105532416",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "170827274105532416",
  "created_at" : "Sat Feb 18 11:09:30 +0000 2012",
  "favorited" : false,
  "full_text" : "#NeverTellAGirl you play WoW",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "myfavmichaeljacksonsongs",
      "indices" : [ "91", "116" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "136" ],
  "favorite_count" : "0",
  "id_str" : "165850999125311489",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "165850999125311489",
  "created_at" : "Sat Feb 04 17:35:34 +0000 2012",
  "favorited" : false,
  "full_text" : "...if you wanna make the world a better place, take a look at yourself and make the change #myfavmichaeljacksonsongs (MAN IN THE MIRROR)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "165849439766978561",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "165849439766978561",
  "created_at" : "Sat Feb 04 17:29:22 +0000 2012",
  "favorited" : false,
  "full_text" : "I don't drink milk. Milk is for babies, when you grow up, you gotta drink beer!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mozat.com\" rel=\"nofollow\">Mozat for tweets</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/5AQLamKW",
      "expanded_url" : "http://mozat.com.My",
      "display_url" : "mozat.com.My",
      "indices" : [ "60", "80" ]
    } ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "165617356847071233",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "165617356847071233",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 04 02:07:09 +0000 2012",
  "favorited" : false,
  "full_text" : "I am tweeting from my Phone via mozat. Get it for free from http://t.co/5AQLamKW Pin is M1131GF.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "32" ],
  "favorite_count" : "0",
  "id_str" : "164389049497436160",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "164389049497436160",
  "created_at" : "Tue Jan 31 16:46:18 +0000 2012",
  "favorited" : false,
  "full_text" : "chatting with a f**king dumb-ass",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "HowCome",
      "indices" : [ "0", "8" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "0",
  "id_str" : "152997456227991552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "152997456227991552",
  "created_at" : "Sat Dec 31 06:20:10 +0000 2011",
  "favorited" : false,
  "full_text" : "#HowCome people say i'm crazy when they're obuviously nuts.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "I Speak Female",
      "screen_name" : "ispeakfemale",
      "indices" : [ "0", "13" ],
      "id_str" : "208973682",
      "id" : "208973682"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "22" ],
  "favorite_count" : "0",
  "id_str" : "133418203710885888",
  "in_reply_to_user_id" : "208973682",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "133418203710885888",
  "created_at" : "Mon Nov 07 05:39:13 +0000 2011",
  "favorited" : false,
  "full_text" : "@ispeakfemale, i'm 15!",
  "lang" : "und",
  "in_reply_to_screen_name" : "ispeakfemale",
  "in_reply_to_user_id_str" : "208973682"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "I Speak Female",
      "screen_name" : "ispeakfemale",
      "indices" : [ "0", "13" ],
      "id_str" : "208973682",
      "id" : "208973682"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "21" ],
  "favorite_count" : "0",
  "id_str" : "133417779566092288",
  "in_reply_to_user_id" : "208973682",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "133417779566092288",
  "created_at" : "Mon Nov 07 05:37:32 +0000 2011",
  "favorited" : false,
  "full_text" : "@ispeakfemale, i'm 15",
  "lang" : "und",
  "in_reply_to_screen_name" : "ispeakfemale",
  "in_reply_to_user_id_str" : "208973682"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Ahmed",
      "screen_name" : "Life_Quotesx",
      "indices" : [ "0", "13" ],
      "id_str" : "151139985",
      "id" : "151139985"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "36" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "102958762230423553",
  "id_str" : "102964429775319041",
  "in_reply_to_user_id" : "151139985",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "102964429775319041",
  "in_reply_to_status_id" : "102958762230423553",
  "created_at" : "Mon Aug 15 04:46:47 +0000 2011",
  "favorited" : false,
  "full_text" : "@Life_Quotesx ur quotes are awesome!",
  "lang" : "en",
  "in_reply_to_screen_name" : "Life_Quotesx",
  "in_reply_to_user_id_str" : "151139985"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "0",
  "id_str" : "102962220580876288",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "102962220580876288",
  "created_at" : "Mon Aug 15 04:38:00 +0000 2011",
  "favorited" : false,
  "full_text" : "Pls friends tell me the difference between complete and finish",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://www.snaptu.com\" rel=\"nofollow\">Snaptu</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "16" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "82627674043990016",
  "id_str" : "82698692502618112",
  "in_reply_to_user_id" : "75692158",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "82698692502618112",
  "in_reply_to_status_id" : "82627674043990016",
  "created_at" : "Mon Jun 20 06:37:59 +0000 2011",
  "favorited" : false,
  "full_text" : "@ImDrQuotes Yeah",
  "lang" : "en",
  "in_reply_to_screen_name" : "LADIESIFWT",
  "in_reply_to_user_id_str" : "75692158"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "MrRetweets",
      "screen_name" : "MrRetweets",
      "indices" : [ "0", "11" ],
      "id_str" : "282986225",
      "id" : "282986225"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "11" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "55261436024328192",
  "id_str" : "55273037339176960",
  "in_reply_to_user_id" : "116709307",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "55273037339176960",
  "in_reply_to_status_id" : "55261436024328192",
  "created_at" : "Tue Apr 05 14:18:13 +0000 2011",
  "favorited" : false,
  "full_text" : "@MrRetweets",
  "lang" : "und",
  "in_reply_to_screen_name" : "TEKASHI6IX9lNE",
  "in_reply_to_user_id_str" : "116709307"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "68" ],
  "favorite_count" : "0",
  "id_str" : "456079635785482241",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079635785482241",
  "created_at" : "Tue Apr 15 14:40:33 +0000 2014",
  "favorited" : false,
  "full_text" : "It's hard to forget someone who gave you so many things to remember.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ETHICAL ONE",
      "screen_name" : "PsychographEd",
      "indices" : [ "3", "17" ],
      "id_str" : "58795639",
      "id" : "58795639"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "128" ],
  "favorite_count" : "0",
  "id_str" : "456079473897902080",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "456079473897902080",
  "created_at" : "Tue Apr 15 14:39:54 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @PsychographEd: When stupid people ask silly questions, don’t take the trouble to answer, just say “good question” and leave.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/xMm58bXso0",
      "expanded_url" : "http://bit.ly/1ergBXY",
      "display_url" : "bit.ly/1ergBXY",
      "indices" : [ "68", "90" ]
    } ]
  },
  "display_text_range" : [ "0", "90" ],
  "favorite_count" : "0",
  "id_str" : "455826846970814464",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455826846970814464",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 14 21:56:03 +0000 2014",
  "favorited" : false,
  "full_text" : "PHOTO: Barack Obama Saves Wife Michelle From Embarrassing Situation http://t.co/xMm58bXso0",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/omfjGHFIq4",
      "expanded_url" : "http://bit.ly/1n7d7fR",
      "display_url" : "bit.ly/1n7d7fR",
      "indices" : [ "49", "71" ]
    } ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "455826374868357121",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455826374868357121",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 14 21:54:11 +0000 2014",
  "favorited" : false,
  "full_text" : "Hilarious: Basketmouth Assaults Hospital Patient http://t.co/omfjGHFIq4",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/K1kXs4XJgw",
      "expanded_url" : "http://www.411vibes.com/2014/04/striking-resemblance-usher-raymonds.html",
      "display_url" : "411vibes.com/2014/04/striki…",
      "indices" : [ "82", "104" ]
    } ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "455826252298207232",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455826252298207232",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 14 21:53:42 +0000 2014",
  "favorited" : false,
  "full_text" : "STRIKING RESEMBLANCE: Usher Raymond’s Twin Brother Discovered In Nigeria [PHOTOS] http://t.co/K1kXs4XJgw",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/ZlIUzkk0lx",
      "expanded_url" : "http://www.411vibes.com/2014/04/photos-japans-annual-penis-festival-nsfw.html",
      "display_url" : "411vibes.com/2014/04/photos…",
      "indices" : [ "50", "72" ]
    } ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "455826034852904960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455826034852904960",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 14 21:52:50 +0000 2014",
  "favorited" : false,
  "full_text" : "(PHOTOS) — JAPAN’s Annual Pen1s Festival : (NSFW) http://t.co/ZlIUzkk0lx",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/ZoWSRpQUfO",
      "expanded_url" : "http://www.411vibes.com/2014/04/highest-paid-black-actors.html",
      "display_url" : "411vibes.com/2014/04/highes…",
      "indices" : [ "26", "48" ]
    } ]
  },
  "display_text_range" : [ "0", "48" ],
  "favorite_count" : "0",
  "id_str" : "455825978821210114",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455825978821210114",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 14 21:52:36 +0000 2014",
  "favorited" : false,
  "full_text" : "Highest Paid Black Actors http://t.co/ZoWSRpQUfO",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/59KvLsDvvZ",
      "expanded_url" : "http://www.thetrentonline.com/5-secrets-women-keep-husbands/?utm_source=rss&utm_medium=rss&utm_campaign=5-secrets-women-keep-husbands",
      "display_url" : "thetrentonline.com/5-secrets-wome…",
      "indices" : [ "41", "63" ]
    } ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "455825681973522432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455825681973522432",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 14 21:51:26 +0000 2014",
  "favorited" : false,
  "full_text" : "5 Secrets Women Keep From Their Husbands http://t.co/59KvLsDvvZ",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/aNIFP9Wo5g",
      "expanded_url" : "http://www.thetrentonline.com/guys-11-places-women-want-touched/?utm_source=rss&utm_medium=rss&utm_campaign=guys-11-places-women-want-touched",
      "display_url" : "thetrentonline.com/guys-11-places…",
      "indices" : [ "41", "63" ]
    } ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "455825628466786304",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455825628466786304",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 14 21:51:13 +0000 2014",
  "favorited" : false,
  "full_text" : "Guys, 11 Places Women Want To Be Touched http://t.co/aNIFP9Wo5g",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "theknowledge",
      "screen_name" : "theknowIedge",
      "indices" : [ "3", "16" ],
      "id_str" : "18255675",
      "id" : "18255675"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "455825461046939648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455825461046939648",
  "created_at" : "Mon Apr 14 21:50:33 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheKnowIedge: Listening to music activates the reward system in our brains — This is why we spend money attending concerts and buying s…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "128" ],
  "favorite_count" : "0",
  "id_str" : "455316955533443072",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455316955533443072",
  "created_at" : "Sun Apr 13 12:09:56 +0000 2014",
  "favorited" : false,
  "full_text" : "[InformationNigeria] Fourteen-year old Bride Apologises For Killing 35-year-old Husband With Rat Poison 17 Days After Wedding...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "455316851904749568",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455316851904749568",
  "created_at" : "Sun Apr 13 12:09:31 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: You must be my new boss because you just gave me a raise.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMGFacts",
      "screen_name" : "OMGFacts",
      "indices" : [ "3", "12" ],
      "id_str" : "77888423",
      "id" : "77888423"
    } ],
    "urls" : [ {
      "url" : "http://t.co/rRKy3Vsa7v",
      "expanded_url" : "http://bit.ly/1hEtIj",
      "display_url" : "bit.ly/1hEtIj",
      "indices" : [ "94", "116" ]
    } ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/OMGFacts/status/455314600947249152/photo/1",
      "source_status_id" : "455314600947249152",
      "indices" : [ "117", "139" ],
      "url" : "http://t.co/VP5HSUJ926",
      "media_url" : "http://pbs.twimg.com/media/BlGaN5GCQAAzC4w.jpg",
      "id_str" : "455314600796241920",
      "source_user_id" : "77888423",
      "id" : "455314600796241920",
      "media_url_https" : "https://pbs.twimg.com/media/BlGaN5GCQAAzC4w.jpg",
      "source_user_id_str" : "77888423",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "596",
          "h" : "314",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "596",
          "h" : "314",
          "resize" : "fit"
        },
        "small" : {
          "w" : "596",
          "h" : "314",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "455314600947249152",
      "display_url" : "pic.twitter.com/VP5HSUJ926"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "455316794191118336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455316794191118336",
  "possibly_sensitive" : false,
  "created_at" : "Sun Apr 13 12:09:17 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @OMGFacts: This Artist Made 19 Sick Kids Dreams Come True Aaaaaaand Now I'm Crying ---&gt; http://t.co/rRKy3Vsa7v http://t.co/VP5HSUJ926",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/OMGFacts/status/455314600947249152/photo/1",
      "source_status_id" : "455314600947249152",
      "indices" : [ "117", "139" ],
      "url" : "http://t.co/VP5HSUJ926",
      "media_url" : "http://pbs.twimg.com/media/BlGaN5GCQAAzC4w.jpg",
      "id_str" : "455314600796241920",
      "source_user_id" : "77888423",
      "id" : "455314600796241920",
      "media_url_https" : "https://pbs.twimg.com/media/BlGaN5GCQAAzC4w.jpg",
      "source_user_id_str" : "77888423",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "596",
          "h" : "314",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "596",
          "h" : "314",
          "resize" : "fit"
        },
        "small" : {
          "w" : "596",
          "h" : "314",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "455314600947249152",
      "display_url" : "pic.twitter.com/VP5HSUJ926"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "1", "17" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "455316560195108864",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455316560195108864",
  "created_at" : "Sun Apr 13 12:08:21 +0000 2014",
  "favorited" : false,
  "full_text" : "\"@LargerThanWords: Never bend your head. Hold it high. Look the world straight in the eye.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "id_str" : "455316539202600960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455316539202600960",
  "created_at" : "Sun Apr 13 12:08:16 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Sometimes you have to go through the hard times to realize how strong you are.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "TheMorningConvo",
      "indices" : [ "90", "106" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mana Ionescu",
      "screen_name" : "manamica",
      "indices" : [ "3", "12" ],
      "id_str" : "13520532",
      "id" : "13520532"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "455316388694212608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "455316388694212608",
  "created_at" : "Sun Apr 13 12:07:41 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @manamica: \"Whether you think you can or think you can't, you are right.\" - Henry Ford #TheMorningConvo",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "450412925258584064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "450412925258584064",
  "created_at" : "Sun Mar 30 23:23:04 +0000 2014",
  "favorited" : false,
  "full_text" : "A real boyfriend never \"gives up\" on his girl. Period!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "0",
  "id_str" : "449672533865140224",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "449672533865140224",
  "created_at" : "Fri Mar 28 22:21:01 +0000 2014",
  "favorited" : false,
  "full_text" : "Your ability to do the extraordinary, puts you above ordinary.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://tweet.im/\" rel=\"nofollow\">Tweet.IM</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "33" ],
  "favorite_count" : "0",
  "id_str" : "449630920963018753",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "449630920963018753",
  "created_at" : "Fri Mar 28 19:35:39 +0000 2014",
  "favorited" : false,
  "full_text" : "Once you pop, the fun don't stop.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/TGrCAgxDgL",
      "expanded_url" : "http://bit.ly/1g3Zk1x",
      "display_url" : "bit.ly/1g3Zk1x",
      "indices" : [ "97", "119" ]
    } ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "440389203311206400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440389203311206400",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:32:22 +0000 2014",
  "favorited" : false,
  "full_text" : "DISTURBING VIDEO: Naked Prostitute Fights Man On The Streets For Refusing To Pay For Sex [WATCH] http://t.co/TGrCAgxDgL",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/FEh0yW5h7D",
      "expanded_url" : "http://bit.ly/1jLxMCm",
      "display_url" : "bit.ly/1jLxMCm",
      "indices" : [ "57", "79" ]
    } ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "440388805246611456",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440388805246611456",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:30:47 +0000 2014",
  "favorited" : false,
  "full_text" : "Job Vacancy: Google is hiring with good pay! (Apply Now) http://t.co/FEh0yW5h7D",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/jZjyYfeiT5",
      "expanded_url" : "http://bit.ly/1g3ZaqK",
      "display_url" : "bit.ly/1g3ZaqK",
      "indices" : [ "47", "69" ]
    } ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "440388739714793472",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440388739714793472",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:30:32 +0000 2014",
  "favorited" : false,
  "full_text" : "Sean Tizzle - Kilogbe (Music Video) | Download http://t.co/jZjyYfeiT5",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/ZmjLnhGeWz",
      "expanded_url" : "http://bit.ly/1g3ZbuW",
      "display_url" : "bit.ly/1g3ZbuW",
      "indices" : [ "88", "110" ]
    } ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "id_str" : "440388563394641920",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440388563394641920",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:29:50 +0000 2014",
  "favorited" : false,
  "full_text" : "Unbelievable: Pistorius caught on camera kissing girlfriend before killing her (Photos) http://t.co/ZmjLnhGeWz",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/5LYVlEvXGI",
      "expanded_url" : "http://bit.ly/1jLxFGQ",
      "display_url" : "bit.ly/1jLxFGQ",
      "indices" : [ "48", "70" ]
    } ]
  },
  "display_text_range" : [ "0", "70" ],
  "favorite_count" : "0",
  "id_str" : "440388500937252864",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440388500937252864",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:29:35 +0000 2014",
  "favorited" : false,
  "full_text" : "Not Again: Kanu undergoes another heart surgery http://t.co/5LYVlEvXGI",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/ErY0XtYSj1",
      "expanded_url" : "http://bit.ly/1jLxGKZ",
      "display_url" : "bit.ly/1jLxGKZ",
      "indices" : [ "59", "81" ]
    } ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "440388371245187072",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440388371245187072",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:29:04 +0000 2014",
  "favorited" : false,
  "full_text" : "Photos: Mikel Obi and Genevieve Nnaji co-star in new movie http://t.co/ErY0XtYSj1",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/bY5qc28MgB",
      "expanded_url" : "http://bit.ly/1jLxxHm",
      "display_url" : "bit.ly/1jLxxHm",
      "indices" : [ "68", "90" ]
    } ]
  },
  "display_text_range" : [ "0", "90" ],
  "favorite_count" : "0",
  "id_str" : "440387927596867584",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440387927596867584",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:27:18 +0000 2014",
  "favorited" : false,
  "full_text" : "Knife-wielding terror gang attack train station in China killing 33 http://t.co/bY5qc28MgB",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/CwYpWrHwml",
      "expanded_url" : "http://bit.ly/1cwnTmT",
      "display_url" : "bit.ly/1cwnTmT",
      "indices" : [ "90", "112" ]
    } ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "440387845380116480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440387845380116480",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:26:59 +0000 2014",
  "favorited" : false,
  "full_text" : "26-Yr-Old Catholic nun Pleads Guilty To Killing Her Newborn After Giving Birth In Convent http://t.co/CwYpWrHwml",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/qOKUXVdXKK",
      "expanded_url" : "http://bit.ly/1hELd6v",
      "display_url" : "bit.ly/1hELd6v",
      "indices" : [ "29", "51" ]
    } ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "0",
  "id_str" : "440387782243266560",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440387782243266560",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:26:43 +0000 2014",
  "favorited" : false,
  "full_text" : "Not again Rihanna, not again http://t.co/qOKUXVdXKK",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/isxEu7lIgo",
      "expanded_url" : "http://bit.ly/1g3Z16T",
      "display_url" : "bit.ly/1g3Z16T",
      "indices" : [ "72", "94" ]
    } ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "440387738786091008",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440387738786091008",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:26:33 +0000 2014",
  "favorited" : false,
  "full_text" : "See what Omotola Jalade Ekeinde said about gender equality, Great Point http://t.co/isxEu7lIgo",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/eEeLAooOEa",
      "expanded_url" : "http://bit.ly/1cwnBfS",
      "display_url" : "bit.ly/1cwnBfS",
      "indices" : [ "36", "58" ]
    } ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "0",
  "id_str" : "440386627182264320",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440386627182264320",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:22:08 +0000 2014",
  "favorited" : false,
  "full_text" : "Oscars 2014: Complete winners' list http://t.co/eEeLAooOEa",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/flz3fOKqKc",
      "expanded_url" : "http://bit.ly/1hEKzpu",
      "display_url" : "bit.ly/1hEKzpu",
      "indices" : [ "97", "119" ]
    } ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "0",
  "id_str" : "440386568915013632",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440386568915013632",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:21:54 +0000 2014",
  "favorited" : false,
  "full_text" : "PHOTOS: Footballer Ronaldo Strikes Gold At World’s Biggest, Nudest Street Party In Brazil [LOOK] http://t.co/flz3fOKqKc",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/yufZK9JwJ6",
      "expanded_url" : "http://bit.ly/1jLx3kF",
      "display_url" : "bit.ly/1jLx3kF",
      "indices" : [ "58", "80" ]
    } ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "440386504284987392",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440386504284987392",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:21:39 +0000 2014",
  "favorited" : false,
  "full_text" : "Fuel Scarcity: Petrol Stations In Lagos Run Out Of Supply http://t.co/yufZK9JwJ6",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/gdKmoYV6kO",
      "expanded_url" : "http://bit.ly/1hWBIye",
      "display_url" : "bit.ly/1hWBIye",
      "indices" : [ "104", "126" ]
    } ]
  },
  "display_text_range" : [ "0", "126" ],
  "favorite_count" : "0",
  "id_str" : "440386383862300672",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440386383862300672",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:21:10 +0000 2014",
  "favorited" : false,
  "full_text" : "Oscars 2014: This Is The Most Retweeted Selfie In HUMAN History, Frankly, Most Famous Selfie Too [LOOK] http://t.co/gdKmoYV6kO",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/O9S49MpU2Y",
      "expanded_url" : "http://bit.ly/1hEKqCz",
      "display_url" : "bit.ly/1hEKqCz",
      "indices" : [ "95", "117" ]
    } ]
  },
  "display_text_range" : [ "0", "117" ],
  "favorite_count" : "0",
  "id_str" : "440386321711132672",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440386321711132672",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:20:55 +0000 2014",
  "favorited" : false,
  "full_text" : "‘Only Oscar Pistorius Knows What Happened’: As Murder Case Opens, Forensics Takes Centre Stage http://t.co/O9S49MpU2Y",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/9gFbBDznVx",
      "expanded_url" : "http://bit.ly/1jLwZBh",
      "display_url" : "bit.ly/1jLwZBh",
      "indices" : [ "35", "57" ]
    } ]
  },
  "display_text_range" : [ "0", "57" ],
  "favorite_count" : "0",
  "id_str" : "440386262483337216",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440386262483337216",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:20:41 +0000 2014",
  "favorited" : false,
  "full_text" : "The Health Benefits Of Spicy Foods http://t.co/9gFbBDznVx",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/S4DyKDFObq",
      "expanded_url" : "http://bit.ly/1jLwXcK",
      "display_url" : "bit.ly/1jLwXcK",
      "indices" : [ "90", "112" ]
    } ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "440386184691613696",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440386184691613696",
  "possibly_sensitive" : false,
  "created_at" : "Mon Mar 03 07:20:23 +0000 2014",
  "favorited" : false,
  "full_text" : "‘On Brink Of Disaster’: Ukraine Puts Armed Forces On Combat Alert Amid Crisis With Russia http://t.co/S4DyKDFObq",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Юлька Потапчук",
      "screen_name" : "AgwuComedy",
      "indices" : [ "3", "14" ],
      "id_str" : "164091471",
      "id" : "164091471"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "126" ],
  "favorite_count" : "0",
  "id_str" : "440125825934172160",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440125825934172160",
  "created_at" : "Sun Mar 02 14:05:48 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @AgwuComedy: You’re alive; you have mass; and you occupy space. Do you know what this means? YOU MATTER!. RT if you get it.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "68" ],
  "favorite_count" : "0",
  "id_str" : "440125685374676992",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440125685374676992",
  "created_at" : "Sun Mar 02 14:05:15 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: It is possible for humans to smell a storm coming.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "107" ],
  "favorite_count" : "0",
  "id_str" : "440125604491694081",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440125604491694081",
  "created_at" : "Sun Mar 02 14:04:55 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: The harder you work for something, the greater you'll feel when you finally achieve it.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "440125503736131584",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440125503736131584",
  "created_at" : "Sun Mar 02 14:04:31 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: No amount of tears will ever make things the way I want them.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "0",
  "id_str" : "440125451982610433",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "440125451982610433",
  "created_at" : "Sun Mar 02 14:04:19 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: Music sounds better with you.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "113" ],
  "favorite_count" : "0",
  "id_str" : "439901990358089728",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439901990358089728",
  "created_at" : "Sat Mar 01 23:16:22 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Humans can theoretically survive on a diet entirely composed of nothing but potatoes and butter.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "123" ],
  "favorite_count" : "0",
  "id_str" : "439901271953539073",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439901271953539073",
  "created_at" : "Sat Mar 01 23:13:30 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Success is not counted by how high you have climbed but by how many people you brought with you. - Wil Rose",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Tweets™",
      "screen_name" : "Lmao",
      "indices" : [ "3", "8" ],
      "id_str" : "237634998",
      "id" : "237634998"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "439901217171705856",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439901217171705856",
  "created_at" : "Sat Mar 01 23:13:17 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Lmao: being skinny might be nice, but having pizza is nicer",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Tweets™",
      "screen_name" : "Lmao",
      "indices" : [ "3", "8" ],
      "id_str" : "237634998",
      "id" : "237634998"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "439901215980523520",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439901215980523520",
  "created_at" : "Sat Mar 01 23:13:17 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Lmao: \"It's gonna be okay.\"   \n\n...   \n\n\"Yeah, because it's not happening to you.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "439900938284052482",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439900938284052482",
  "created_at" : "Sat Mar 01 23:12:11 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Factsionary: Psychology says; People tend to value memories more than actual people. Sometimes you miss the memories, not the actual pe…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "439900933670330368",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439900933670330368",
  "created_at" : "Sat Mar 01 23:12:10 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Factsionary: After four days without sleep you will start to hallucinate.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "95" ],
  "favorite_count" : "0",
  "id_str" : "439900898215464961",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439900898215464961",
  "created_at" : "Sat Mar 01 23:12:01 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Factsionary: It takes a million years for a glass bottle to fully break down in a landfill.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "111" ],
  "favorite_count" : "0",
  "id_str" : "439900882306486272",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439900882306486272",
  "created_at" : "Sat Mar 01 23:11:57 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Factsionary: 16% of workers admit to purposely closing the elevator door when they see someone approaching.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "factsionary",
      "indices" : [ "3", "15" ],
      "id_str" : "43042353",
      "id" : "43042353"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "439900878561370112",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439900878561370112",
  "created_at" : "Sat Mar 01 23:11:57 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Factsionary: When the iPhone was in development it was code-named \"Project Purple.\"",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "SURULERE",
      "indices" : [ "0", "9" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "31" ],
  "favorite_count" : "0",
  "id_str" : "439817423747702784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439817423747702784",
  "created_at" : "Sat Mar 01 17:40:19 +0000 2014",
  "favorited" : false,
  "full_text" : "#SURULERE Patience is a virtue.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgos",
      "indices" : [ "29", "36" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ZodiacFact",
      "screen_name" : "ZodiacFacts",
      "indices" : [ "3", "15" ],
      "id_str" : "125786481",
      "id" : "125786481"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "439815546616680448",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439815546616680448",
  "created_at" : "Sat Mar 01 17:32:52 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @ZodiacFacts: Sometimes a #Virgos protective instinct prevents them from opening up.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "id_str" : "439814776294612993",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439814776294612993",
  "created_at" : "Sat Mar 01 17:29:48 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Kind words can be short and easy to speak, but their echoes are truly endless. -Mother Theresa",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/7FQ2FZdbOu",
      "expanded_url" : "http://bit.ly/1jGfbYp",
      "display_url" : "bit.ly/1jGfbYp",
      "indices" : [ "90", "112" ]
    } ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "439508328541327361",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439508328541327361",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 28 21:12:05 +0000 2014",
  "favorited" : false,
  "full_text" : "SEE The Expensive Gift Samuel Eto'o Gave Davido and SEE His Response To Mourinho! (PHOTO) http://t.co/7FQ2FZdbOu",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/WCdFNhDphJ",
      "expanded_url" : "http://bit.ly/1jGem1z",
      "display_url" : "bit.ly/1jGem1z",
      "indices" : [ "78", "100" ]
    } ]
  },
  "display_text_range" : [ "0", "100" ],
  "favorite_count" : "0",
  "id_str" : "439505557519872001",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439505557519872001",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 28 21:01:05 +0000 2014",
  "favorited" : false,
  "full_text" : "BREAKING NEWS: MTN, Airtel, Glo To Pay N700 MILLION For Poor Network Services http://t.co/WCdFNhDphJ",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/PYjClg8tzX",
      "expanded_url" : "http://www.411vibes.com/2014/02/just-in-balotelli-to-face-life-ban.html",
      "display_url" : "411vibes.com/2014/02/just-i…",
      "indices" : [ "39", "61" ]
    } ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "439505299104628736",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439505299104628736",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 28 21:00:03 +0000 2014",
  "favorited" : false,
  "full_text" : "JUST IN: 'Balotelli' To Face Life Ban? http://t.co/PYjClg8tzX",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/L4fM7kkx9S",
      "expanded_url" : "http://bit.ly/1gHHl2t",
      "display_url" : "bit.ly/1gHHl2t",
      "indices" : [ "51", "73" ]
    } ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "439504718155747328",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439504718155747328",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 28 20:57:45 +0000 2014",
  "favorited" : false,
  "full_text" : "Ladies, 5 Things He DOES NOT Want To Hear From You http://t.co/L4fM7kkx9S",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/Y8wmNR9QWi",
      "expanded_url" : "http://bit.ly/1jGdYjO",
      "display_url" : "bit.ly/1jGdYjO",
      "indices" : [ "112", "134" ]
    } ]
  },
  "display_text_range" : [ "0", "134" ],
  "favorite_count" : "0",
  "id_str" : "439504512890720258",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439504512890720258",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 28 20:56:56 +0000 2014",
  "favorited" : false,
  "full_text" : "‘I’ve slept with 300 people and had AT LEAST 5 orgasms a day’ – Confessions Of A Female Nymphomaniac (PICTURED) http://t.co/Y8wmNR9QWi",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "29" ],
  "favorite_count" : "0",
  "id_str" : "439503743730868225",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439503743730868225",
  "created_at" : "Fri Feb 28 20:53:52 +0000 2014",
  "favorited" : false,
  "full_text" : "Hold On.. Pain Ends.. H.O.P.E",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "113" ],
  "favorite_count" : "0",
  "id_str" : "439503233078538241",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439503233078538241",
  "created_at" : "Fri Feb 28 20:51:51 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Over 6 milligrams of gold are lost every year from the average wedding ring just by wearing it.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "17", "23" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "BestofVirgo",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "0",
  "id_str" : "439503211968598016",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439503211968598016",
  "created_at" : "Fri Feb 28 20:51:46 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @BestofVirgo: #Virgo are thoughtful, affectionate and gracious.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "89" ],
  "favorite_count" : "0",
  "id_str" : "439503184705638402",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439503184705638402",
  "created_at" : "Fri Feb 28 20:51:39 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Better three hours too soon than a minute too late. - William Shakespeare",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RELLZ",
      "screen_name" : "TheSoDopePosts",
      "indices" : [ "3", "18" ],
      "id_str" : "56813097",
      "id" : "56813097"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheSoDopePosts/status/439500612770992128/photo/1",
      "source_status_id" : "439500612770992128",
      "indices" : [ "47", "69" ],
      "url" : "http://t.co/SVw7yiTwRr",
      "media_url" : "http://pbs.twimg.com/media/BhlreosIAAEdVAE.jpg",
      "id_str" : "439500612708073473",
      "source_user_id" : "56813097",
      "id" : "439500612708073473",
      "media_url_https" : "https://pbs.twimg.com/media/BhlreosIAAEdVAE.jpg",
      "source_user_id_str" : "56813097",
      "sizes" : {
        "medium" : {
          "w" : "600",
          "h" : "502",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "600",
          "h" : "502",
          "resize" : "fit"
        },
        "large" : {
          "w" : "600",
          "h" : "502",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "439500612770992128",
      "display_url" : "pic.twitter.com/SVw7yiTwRr"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "439503155538444289",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439503155538444289",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 28 20:51:32 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheSoDopePosts: When females hear my voice http://t.co/SVw7yiTwRr",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/TheSoDopePosts/status/439500612770992128/photo/1",
      "source_status_id" : "439500612770992128",
      "indices" : [ "47", "69" ],
      "url" : "http://t.co/SVw7yiTwRr",
      "media_url" : "http://pbs.twimg.com/media/BhlreosIAAEdVAE.jpg",
      "id_str" : "439500612708073473",
      "source_user_id" : "56813097",
      "id" : "439500612708073473",
      "media_url_https" : "https://pbs.twimg.com/media/BhlreosIAAEdVAE.jpg",
      "source_user_id_str" : "56813097",
      "sizes" : {
        "medium" : {
          "w" : "600",
          "h" : "502",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "600",
          "h" : "502",
          "resize" : "fit"
        },
        "large" : {
          "w" : "600",
          "h" : "502",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "439500612770992128",
      "display_url" : "pic.twitter.com/SVw7yiTwRr"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "lovequotes",
      "indices" : [ "98", "109" ]
    }, {
      "text" : "peace",
      "indices" : [ "110", "116" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "116" ],
  "favorite_count" : "0",
  "id_str" : "439503053843357696",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "439503053843357696",
  "created_at" : "Fri Feb 28 20:51:08 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Modern technology Owes ecology -An apology.\n~Alan M. Eddison  #lovequotes #peace",
  "lang" : "hu"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/AWRXo8Tb0c",
      "expanded_url" : "http://bit.ly/1o54puE",
      "display_url" : "bit.ly/1o54puE",
      "indices" : [ "80", "102" ]
    } ]
  },
  "display_text_range" : [ "0", "102" ],
  "favorite_count" : "0",
  "id_str" : "438569075208630272",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438569075208630272",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 26 06:59:50 +0000 2014",
  "favorited" : false,
  "full_text" : "Awww: Kanye West Reveals His Biggest Regret In Life, It May Make You Cry [LOOK] http://t.co/AWRXo8Tb0c",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/baTss5Wbwu",
      "expanded_url" : "http://bit.ly/1mzMuO2",
      "display_url" : "bit.ly/1mzMuO2",
      "indices" : [ "109", "131" ]
    } ]
  },
  "display_text_range" : [ "0", "131" ],
  "favorite_count" : "0",
  "id_str" : "438569016593235968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438569016593235968",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 26 06:59:36 +0000 2014",
  "favorited" : false,
  "full_text" : "Exposed: How Lamido Sanusi, Senator Saraki, Lai Alabi Fraudulently Acquired Intercontinental Bank Plc (READ) http://t.co/baTss5Wbwu",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/6Z7XZANF72",
      "expanded_url" : "http://bit.ly/MsKPwl",
      "display_url" : "bit.ly/MsKPwl",
      "indices" : [ "69", "91" ]
    } ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "438568949085904896",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438568949085904896",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 26 06:59:20 +0000 2014",
  "favorited" : false,
  "full_text" : "Want To Get Pregnant? There’s An App For That Called Kindara (CLICK) http://t.co/6Z7XZANF72",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/YJVZlAzV5M",
      "expanded_url" : "http://www.thetrentonline.com/police-arrest-four-raping-pupil/?utm_source=rss&utm_medium=rss&utm_campaign=police-arrest-four-raping-pupil",
      "display_url" : "thetrentonline.com/police-arrest-…",
      "indices" : [ "80", "102" ]
    } ]
  },
  "display_text_range" : [ "0", "102" ],
  "favorite_count" : "0",
  "id_str" : "438568859306823680",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438568859306823680",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 26 06:58:58 +0000 2014",
  "favorited" : false,
  "full_text" : "5 Men Rape Young Girl And Record Act With Phones, Suspects Arrested And Paraded http://t.co/YJVZlAzV5M",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/wKBhgrrmMT",
      "expanded_url" : "http://bit.ly/1bIfqBW",
      "display_url" : "bit.ly/1bIfqBW",
      "indices" : [ "69", "91" ]
    } ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "438257632215072768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438257632215072768",
  "possibly_sensitive" : false,
  "created_at" : "Tue Feb 25 10:22:16 +0000 2014",
  "favorited" : false,
  "full_text" : "PHOTO: Girl Forced To Have S£x With A Dog and Horse For Money (LOOK) http://t.co/wKBhgrrmMT",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/E60yW00Npp",
      "expanded_url" : "http://bit.ly/1bIfly3",
      "display_url" : "bit.ly/1bIfly3",
      "indices" : [ "79", "101" ]
    } ]
  },
  "display_text_range" : [ "0", "101" ],
  "favorite_count" : "0",
  "id_str" : "438257317709352960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438257317709352960",
  "possibly_sensitive" : false,
  "created_at" : "Tue Feb 25 10:21:01 +0000 2014",
  "favorited" : false,
  "full_text" : "Ousted Ukraine President Yanukovych’s ‘Wanted For Mass Murder’, Warrant Issued http://t.co/E60yW00Npp",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/VIIlCvXnrw",
      "expanded_url" : "http://bit.ly/1mEBty9",
      "display_url" : "bit.ly/1mEBty9",
      "indices" : [ "93", "115" ]
    }, {
      "url" : "http://t.co/vNg0lM5VZV",
      "expanded_url" : "http://pic.wittr.in/upcomingmovies2015",
      "display_url" : "pic.wittr.in/upcomingmovies…",
      "indices" : [ "117", "139" ]
    } ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "438257000464789504",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438257000464789504",
  "possibly_sensitive" : false,
  "created_at" : "Tue Feb 25 10:19:45 +0000 2014",
  "favorited" : false,
  "full_text" : "10 Exciting Movies coming out in 2015: 6. Warcraft 3. Batman vs. Superman 2. Star Wars VII : http://t.co/VIIlCvXnrw… http://t.co/vNg0lM5VZV",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Mind Blowing",
      "screen_name" : "MlNDBLOWINGS",
      "indices" : [ "3", "16" ],
      "id_str" : "723274946",
      "id" : "723274946"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "438256589813055488",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438256589813055488",
  "created_at" : "Tue Feb 25 10:18:08 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @MlNDBLOWINGS: 10 Exciting Movies coming out in 2015:\n6. Warcraft\n3. Batman vs. Superman\n2. Star Wars VII\nsee all : http://t.co/xlvCcjqz…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "114" ],
  "favorite_count" : "0",
  "id_str" : "438256454349643776",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438256454349643776",
  "created_at" : "Tue Feb 25 10:17:35 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: You be the Dairy Queen and I'll be your Burger King: You treat me right, and I'll do it your way.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "wisdomquotes",
      "indices" : [ "89", "102" ]
    }, {
      "text" : "quotes",
      "indices" : [ "103", "110" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "id_str" : "438256317103628288",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438256317103628288",
  "created_at" : "Tue Feb 25 10:17:03 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Sometimes we need much less than we think we need... #wisdomquotes #quotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The boys who ♡",
      "screen_name" : "TheseDamnQuote",
      "indices" : [ "3", "18" ],
      "id_str" : "63896875",
      "id" : "63896875"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "438256151206318080",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438256151206318080",
  "created_at" : "Tue Feb 25 10:16:23 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheseDamnQuote: Life is too short to spend it at war with yourself.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "LTW-Network™",
      "screen_name" : "LargerThanWords",
      "indices" : [ "3", "19" ],
      "id_str" : "544356176",
      "id" : "544356176"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "438256142289235968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438256142289235968",
  "created_at" : "Tue Feb 25 10:16:21 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @LargerThanWords: A strangers not a stranger when he says hello.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The Trent",
      "screen_name" : "TheTrentOnline",
      "indices" : [ "3", "18" ],
      "id_str" : "1965236834",
      "id" : "1965236834"
    } ],
    "urls" : [ {
      "url" : "http://t.co/U6m9AHKP4D",
      "expanded_url" : "http://thetrentonline.com/4-easy-ways-keep-skin-glowing/",
      "display_url" : "thetrentonline.com/4-easy-ways-ke…",
      "indices" : [ "59", "81" ]
    } ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "438255968481452032",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438255968481452032",
  "possibly_sensitive" : false,
  "created_at" : "Tue Feb 25 10:15:39 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheTrentOnline: 4 Easy Ways To Keep Your Skin Glowing  http://t.co/U6m9AHKP4D",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "The Trent",
      "screen_name" : "TheTrentOnline",
      "indices" : [ "3", "18" ],
      "id_str" : "1965236834",
      "id" : "1965236834"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "438255893902532608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438255893902532608",
  "created_at" : "Tue Feb 25 10:15:22 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheTrentOnline: Exposed: How Lamido Sanusi, Senator Saraki, Lai Alabi Fraudulently Acquired Intercontinental Bank Plc (READ)  http://t.…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/xrYajyeWNZ",
      "expanded_url" : "http://bit.ly/1mtdxub",
      "display_url" : "bit.ly/1mtdxub",
      "indices" : [ "94", "116" ]
    } ]
  },
  "display_text_range" : [ "0", "116" ],
  "favorite_count" : "0",
  "id_str" : "438084919324340226",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438084919324340226",
  "possibly_sensitive" : false,
  "created_at" : "Mon Feb 24 22:55:58 +0000 2014",
  "favorited" : false,
  "full_text" : "TOP POST TODAY: SHOCKING: Two 5-Year Old Pupils Caught Nak£d, Having 'S£X' In School Bathroom http://t.co/xrYajyeWNZ",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/EatjsJjMOw",
      "expanded_url" : "http://bit.ly/1o1x5F2",
      "display_url" : "bit.ly/1o1x5F2",
      "indices" : [ "64", "86" ]
    } ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "438084681868009472",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438084681868009472",
  "possibly_sensitive" : false,
  "created_at" : "Mon Feb 24 22:55:02 +0000 2014",
  "favorited" : false,
  "full_text" : "BREAKING: Robin Thicke And Wife Split After 9 Years Of Marriage http://t.co/EatjsJjMOw",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/nksp6TYknT",
      "expanded_url" : "http://bit.ly/NsAMYN",
      "display_url" : "bit.ly/NsAMYN",
      "indices" : [ "31", "53" ]
    } ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "438084530592051200",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438084530592051200",
  "possibly_sensitive" : false,
  "created_at" : "Mon Feb 24 22:54:25 +0000 2014",
  "favorited" : false,
  "full_text" : "Did You Know? 10 Fun SEX Facts http://t.co/nksp6TYknT",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/ey0eanSEdg",
      "expanded_url" : "http://bit.ly/1mtddM8",
      "display_url" : "bit.ly/1mtddM8",
      "indices" : [ "39", "61" ]
    } ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "438084409255014400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438084409255014400",
  "possibly_sensitive" : false,
  "created_at" : "Mon Feb 24 22:53:57 +0000 2014",
  "favorited" : false,
  "full_text" : "7 Relationship Tips Ladies Should Note http://t.co/ey0eanSEdg",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/g0478UNBpj",
      "expanded_url" : "http://bit.ly/1k5ZPvU",
      "display_url" : "bit.ly/1k5ZPvU",
      "indices" : [ "62", "84" ]
    } ]
  },
  "display_text_range" : [ "0", "84" ],
  "favorite_count" : "0",
  "id_str" : "438084281370681346",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438084281370681346",
  "possibly_sensitive" : false,
  "created_at" : "Mon Feb 24 22:53:26 +0000 2014",
  "favorited" : false,
  "full_text" : "It’s Here: New Samsung Galaxy S5 Smartphone Unveiled (PHOTOS) http://t.co/g0478UNBpj",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/hyOfTL2NiY",
      "expanded_url" : "http://bit.ly/1fjIYko",
      "display_url" : "bit.ly/1fjIYko",
      "indices" : [ "82", "104" ]
    } ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "438084216442880001",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438084216442880001",
  "possibly_sensitive" : false,
  "created_at" : "Mon Feb 24 22:53:11 +0000 2014",
  "favorited" : false,
  "full_text" : "‘He was on of the best gifts God gave me’:Tribute By Komla Dumor’s Wife, Kwansema http://t.co/hyOfTL2NiY",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "48" ],
  "favorite_count" : "0",
  "id_str" : "438083401816739840",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438083401816739840",
  "created_at" : "Mon Feb 24 22:49:56 +0000 2014",
  "favorited" : false,
  "full_text" : "Some pople lack understanding try and find it ok",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/AwG3VvDy0i",
      "expanded_url" : "http://bit.ly/1k5Z0mH",
      "display_url" : "bit.ly/1k5Z0mH",
      "indices" : [ "27", "49" ]
    }, {
      "url" : "http://t.co/UmcEUDxs7F",
      "expanded_url" : "http://bit.ly/1k5Z2uS",
      "display_url" : "bit.ly/1k5Z2uS",
      "indices" : [ "50", "72" ]
    } ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "438083244370984960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438083244370984960",
  "possibly_sensitive" : false,
  "created_at" : "Mon Feb 24 22:49:19 +0000 2014",
  "favorited" : false,
  "full_text" : "Don't get the two confused http://t.co/AwG3VvDy0i http://t.co/UmcEUDxs7F",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Bae",
      "screen_name" : "GirlfriendNotes",
      "indices" : [ "3", "19" ],
      "id_str" : "332788870",
      "id" : "332788870"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "438082393854185473",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "438082393854185473",
  "created_at" : "Mon Feb 24 22:45:56 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @GirlfriendNotes: reasons to be a mermaid:\n\n- no periods\n- no pants\n- perfect hair\n- u get to lure men into their death\n\nalso, free clam…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/oOcp2Jw4oh",
      "expanded_url" : "http://bit.ly/1gsHrLf",
      "display_url" : "bit.ly/1gsHrLf",
      "indices" : [ "118", "140" ]
    } ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "437478133382787072",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437478133382787072",
  "possibly_sensitive" : false,
  "created_at" : "Sun Feb 23 06:44:49 +0000 2014",
  "favorited" : false,
  "full_text" : "♥ ~\"Meeting you was fate, becoming your friend was a choice but falling in love with you I had no control over :)\"~ ♥ http://t.co/oOcp2Jw4oh",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "437477825348911104",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437477825348911104",
  "created_at" : "Sun Feb 23 06:43:36 +0000 2014",
  "favorited" : false,
  "full_text" : "Some people just don't know how to be loyal",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "124" ],
  "favorite_count" : "0",
  "id_str" : "437477760047792128",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437477760047792128",
  "created_at" : "Sun Feb 23 06:43:20 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: Saudi Prince Alwaleed owns a diamond encrusted $48 million Mercedes and he charges $1000 just to touch it.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "437477691202486272",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437477691202486272",
  "created_at" : "Sun Feb 23 06:43:04 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Women who bottle up their emotions are considered more likely to develop the habit of chronic over thinking and depression.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "437336884323549184",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437336884323549184",
  "created_at" : "Sat Feb 22 21:23:33 +0000 2014",
  "favorited" : false,
  "full_text" : "My heart is with you, and it beats for only you...",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Survival Tips",
      "screen_name" : "Funny_Truth",
      "indices" : [ "3", "15" ],
      "id_str" : "296623811",
      "id" : "296623811"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "437334345079336960",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437334345079336960",
  "created_at" : "Sat Feb 22 21:13:27 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Funny_Truth: There’s something wrong with my bed. You’re not in it.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "437334258198511616",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437334258198511616",
  "created_at" : "Sat Feb 22 21:13:07 +0000 2014",
  "favorited" : false,
  "full_text" : "Never let a problem to be solved become more important than a person to be loved. -Barbra Johnson",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "88" ],
  "favorite_count" : "0",
  "id_str" : "437318358317678592",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437318358317678592",
  "created_at" : "Sat Feb 22 20:09:56 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: Kids born today will spend about 25% of their lives looking at screens.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "135" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "437267487483523072",
  "id_str" : "437275639755075584",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437275639755075584",
  "in_reply_to_status_id" : "437267487483523072",
  "created_at" : "Sat Feb 22 17:20:11 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc of d residual\nquality of d oil itself, bt primarily focusing on d wear behavior\nof d engines, gearboxes, axles etc.4/4",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "437267487483523072",
  "id_str" : "437274541317185536",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437274541317185536",
  "in_reply_to_status_id" : "437267487483523072",
  "created_at" : "Sat Feb 22 17:15:49 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc Other than d classical oil analysis, offered by most specialized labs,\nd ANAC system is nt only looking 4 a diagnosis 3/4",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "88" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "437267487483523072",
  "id_str" : "437273999912230912",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437273999912230912",
  "in_reply_to_status_id" : "437267487483523072",
  "created_at" : "Sat Feb 22 17:13:40 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc &amp; other\ndriveline components, based on d analysis of used oil.\n 2/4",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "FRMFB",
      "indices" : [ "131", "137" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "137" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "437266111504330752",
  "id_str" : "437273313891856384",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437273313891856384",
  "in_reply_to_status_id" : "437266111504330752",
  "created_at" : "Sat Feb 22 17:10:56 +0000 2014",
  "favorited" : false,
  "full_text" : "@Totalnigeriaplc ANAC (abbreviation for ANAlysis Compared) is d Total\nLubricants corporate diagnosis system for diesel engines 1/4 #FRMFB",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "FRMFB",
      "indices" : [ "116", "122" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "122" ],
  "favorite_count" : "0",
  "id_str" : "437273059926757376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437273059926757376",
  "created_at" : "Sat Feb 22 17:09:56 +0000 2014",
  "favorited" : false,
  "full_text" : "ANAC (abbreviation for ANAlysis Compared) is the Total\nLubricants corporate diagnosis system for diesel engines 1/4 #FRMFB",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "437266111504330752",
  "id_str" : "437272647421136896",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437272647421136896",
  "in_reply_to_status_id" : "437266111504330752",
  "created_at" : "Sat Feb 22 17:08:17 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc ANAC (abbreviation for ANAlysis Compared) is the Total\nLubricants corporate diagnosis system for diesel engines etc#FRMFB",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "437271002998112256",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437271002998112256",
  "created_at" : "Sat Feb 22 17:01:45 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc ANAC is an abbr. for ANAlysis Compared... Total lubricant",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "FRMFB",
      "indices" : [ "132", "138" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "437267487483523072",
  "id_str" : "437270365547823104",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437270365547823104",
  "in_reply_to_status_id" : "437267487483523072",
  "created_at" : "Sat Feb 22 16:59:13 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc ANAC(abbreviation for ANAlysis\nCompared) is the Total Lubricants corporate diagnosis system\nfor diesel engines etc #FRMFB",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "FRMFB",
      "indices" : [ "133", "139" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "437269711471276032",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437269711471276032",
  "created_at" : "Sat Feb 22 16:56:37 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc ANAC (abbreviation for ANAlysis Compared) is the Total\nLubricants corporate diagnosis system for diesel engines etc #FRMFB",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "FRMFB",
      "indices" : [ "34", "40" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "id_str" : "437268660944916480",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437268660944916480",
  "created_at" : "Sat Feb 22 16:52:27 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc total lubricant  #FRMFB",
  "lang" : "ca",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "FRMFB",
      "indices" : [ "55", "61" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "437268489402068992",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437268489402068992",
  "created_at" : "Sat Feb 22 16:51:46 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc Automatic Number Announcement Circuit #FRMFB",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "437268400625422336",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437268400625422336",
  "created_at" : "Sat Feb 22 16:51:25 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc Automatic Number Announcement Circuit",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ {
      "url" : "https://t.co/lLTQhDaBBF",
      "expanded_url" : "https://mobile.twitter.com/TOTALNigeriaplc/status/436888644406620162?p=v",
      "display_url" : "mobile.twitter.com/TOTALNigeriapl…",
      "indices" : [ "35", "58" ]
    } ]
  },
  "display_text_range" : [ "0", "85" ],
  "favorite_count" : "0",
  "id_str" : "437267697186127873",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437267697186127873",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 16:48:37 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc 2time in a row... https://t.co/lLTQhDaBBF are those not the answers?",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ {
      "url" : "https://t.co/lLTQhDaBBF",
      "expanded_url" : "https://mobile.twitter.com/TOTALNigeriaplc/status/436888644406620162?p=v",
      "display_url" : "mobile.twitter.com/TOTALNigeriapl…",
      "indices" : [ "40", "63" ]
    } ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "437267412002803712",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437267412002803712",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 16:47:29 +0000 2014",
  "favorited" : false,
  "full_text" : "@TOTALNigeriaplc no winners on twitter? https://t.co/lLTQhDaBBF",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M2)</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "OLD TOTAL ACCOUNT",
      "screen_name" : "totalnigeriaplc",
      "indices" : [ "0", "16" ],
      "id_str" : "3004173442",
      "id" : "3004173442"
    } ],
    "urls" : [ {
      "url" : "https://t.co/lLTQhDaBBF",
      "expanded_url" : "https://mobile.twitter.com/TOTALNigeriaplc/status/436888644406620162?p=v",
      "display_url" : "mobile.twitter.com/TOTALNigeriapl…",
      "indices" : [ "47", "70" ]
    } ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "437259586731778048",
  "id_str" : "437262133282471936",
  "in_reply_to_user_id" : "2223762204",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437262133282471936",
  "in_reply_to_status_id" : "437259586731778048",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 16:26:31 +0000 2014",
  "favorited" : false,
  "full_text" : "@totalnigeriaplc I got d ans to yesterday quiz https://t.co/lLTQhDaBBF check it out",
  "lang" : "en",
  "in_reply_to_screen_name" : "TOTALNigeria",
  "in_reply_to_user_id_str" : "2223762204"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "437230221637734400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437230221637734400",
  "created_at" : "Sat Feb 22 14:19:42 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: It's okay to cry. Just keep going.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ "94", "101" ]
    }, {
      "text" : "lovequotes",
      "indices" : [ "102", "113" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "TheLoverQuotes",
      "screen_name" : "TheLoverQuotes",
      "indices" : [ "3", "18" ],
      "id_str" : "261074003",
      "id" : "261074003"
    }, {
      "name" : "Chaska Borek",
      "screen_name" : "ChaskaBorek",
      "indices" : [ "23", "35" ],
      "id_str" : "180330699",
      "id" : "180330699"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "113" ],
  "favorite_count" : "0",
  "id_str" : "437229774889824256",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437229774889824256",
  "created_at" : "Sat Feb 22 14:17:56 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheLoverQuotes: RT @ChaskaBorek Some people make the world special just be being in it... #quotes #lovequotes",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/t368JCM7Py",
      "expanded_url" : "http://bit.ly/1f8clWN",
      "display_url" : "bit.ly/1f8clWN",
      "indices" : [ "53", "75" ]
    } ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "437222154095300608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437222154095300608",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 13:47:39 +0000 2014",
  "favorited" : false,
  "full_text" : "I don’t regret fighting 50 Cents –Eedris Abdulkareem http://t.co/t368JCM7Py",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/4CUYR5t846",
      "expanded_url" : "http://bit.ly/1jnJaEo",
      "display_url" : "bit.ly/1jnJaEo",
      "indices" : [ "45", "67" ]
    } ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "437221997794574336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437221997794574336",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 13:47:02 +0000 2014",
  "favorited" : false,
  "full_text" : "D’banj, KSA warm up for Glo Evergreen Series http://t.co/4CUYR5t846",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "133" ],
  "favorite_count" : "0",
  "id_str" : "437221797088755712",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437221797088755712",
  "created_at" : "Sat Feb 22 13:46:14 +0000 2014",
  "favorited" : false,
  "full_text" : "If someone flashes their brights, it means there is a cop ahead. If they flick their lights on and off, it means your lights are off.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "41" ],
  "favorite_count" : "0",
  "id_str" : "437221583242145792",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437221583242145792",
  "created_at" : "Sat Feb 22 13:45:23 +0000 2014",
  "favorited" : false,
  "full_text" : "my maturity level depends on who I'm with",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/KO3MkZoDGL",
      "expanded_url" : "http://bit.ly/1gVPUsP",
      "display_url" : "bit.ly/1gVPUsP",
      "indices" : [ "52", "74" ]
    } ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "437213520552542208",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437213520552542208",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 13:13:20 +0000 2014",
  "favorited" : false,
  "full_text" : "Updated List Of The Top 10 Richest Sportsmen. WOOOW http://t.co/KO3MkZoDGL",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/YV3Fy9xwPO",
      "expanded_url" : "http://bit.ly/1p6AjKM",
      "display_url" : "bit.ly/1p6AjKM",
      "indices" : [ "46", "68" ]
    } ]
  },
  "display_text_range" : [ "0", "68" ],
  "favorite_count" : "0",
  "id_str" : "437212191960629248",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437212191960629248",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 13:08:04 +0000 2014",
  "favorited" : false,
  "full_text" : "DAYUUM!!! Basketmouth Breaks Record. MUST SEE http://t.co/YV3Fy9xwPO",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/C2uDCZuJ3y",
      "expanded_url" : "http://bit.ly/Omr4Z4",
      "display_url" : "bit.ly/Omr4Z4",
      "indices" : [ "77", "99" ]
    } ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "0",
  "id_str" : "437210487554834432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437210487554834432",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 13:01:17 +0000 2014",
  "favorited" : false,
  "full_text" : "‘Give to others’: 107-Year-Old Nun Shares Her Secrets For A Long Joyful Life http://t.co/C2uDCZuJ3y",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/2dc0dbkGNt",
      "expanded_url" : "http://bit.ly/1p6vNMj",
      "display_url" : "bit.ly/1p6vNMj",
      "indices" : [ "41", "63" ]
    } ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "437210350384345088",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437210350384345088",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 13:00:45 +0000 2014",
  "favorited" : false,
  "full_text" : "8 Things Women DESPERATELY Want From Men http://t.co/2dc0dbkGNt",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "TheFacts1O1",
      "indices" : [ "3", "15" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "437210241168846848",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437210241168846848",
  "created_at" : "Sat Feb 22 13:00:19 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFacts1O1: There is a place in Tvennessee named Nameless.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "437210197715857408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437210197715857408",
  "created_at" : "Sat Feb 22 13:00:08 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: In 2009, a 10-year-old named Zoe Pemberton tried to sell her grandmother on eBay - She was banned after bids went up to o…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "437210080048869376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437210080048869376",
  "created_at" : "Sat Feb 22 12:59:40 +0000 2014",
  "favorited" : false,
  "full_text" : "The past cannot be changed, forgotten, edited, or erased. It can only be accepted",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "FLIRT ;)",
      "screen_name" : "Sheldon_Jokes",
      "indices" : [ "3", "17" ],
      "id_str" : "986049937",
      "id" : "986049937"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "437210033559187456",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437210033559187456",
  "created_at" : "Sat Feb 22 12:59:29 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Sheldon_Jokes: If people got notifications about screenshotted texts we would all be screwed",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ "3", "14" ],
      "id_str" : "129845242",
      "id" : "129845242"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "70" ],
  "favorite_count" : "0",
  "id_str" : "437209995135176705",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437209995135176705",
  "created_at" : "Sat Feb 22 12:59:20 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Inspire_Us: Turn your cant's into cans and your dreams into plans.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "0",
  "id_str" : "437209909642682368",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437209909642682368",
  "created_at" : "Sat Feb 22 12:59:00 +0000 2014",
  "favorited" : false,
  "full_text" : "Every mother on earth gave birth to a child...except my mother! She gave birth to a legend.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "SomebodyLied",
      "indices" : [ "70", "83" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "437209835252506624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437209835252506624",
  "created_at" : "Sat Feb 22 12:58:42 +0000 2014",
  "favorited" : false,
  "full_text" : "My Agric Science teacher used to say, \"Weed is an unwanted plant...!\" #SomebodyLied",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Dapo Osuntuyi",
      "screen_name" : "dappyboy0489",
      "indices" : [ "3", "16" ],
      "id_str" : "262836675",
      "id" : "262836675"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "437209715098267648",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437209715098267648",
  "created_at" : "Sat Feb 22 12:58:13 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @Dappyboy0489: In 1996 Ac Milan legend George Weah, paid for his teammates uniforms and expenses. So that Liberia could enter the Africa…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "115" ],
  "favorite_count" : "0",
  "id_str" : "437209698010673152",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437209698010673152",
  "created_at" : "Sat Feb 22 12:58:09 +0000 2014",
  "favorited" : false,
  "full_text" : "Brazilian legend Pele, scored 92 hat tricks, 4 goals on 31 ooccasions, 5 goals on 6 occasions, and 8 on an occasion",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "437209569165836288",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437209569165836288",
  "created_at" : "Sat Feb 22 12:57:38 +0000 2014",
  "favorited" : false,
  "full_text" : "In 2006,Nigeria Football Federation agreed that Referees may accept bribes from clubs,but that shouldn't affect their decisions during games",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Funny Sayings",
      "screen_name" : "TheFunnySayings",
      "indices" : [ "3", "19" ],
      "id_str" : "2356378772",
      "id" : "2356378772"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "88" ],
  "favorite_count" : "0",
  "id_str" : "437209452560011264",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437209452560011264",
  "created_at" : "Sat Feb 22 12:57:11 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFunnySayings: If you talk to me past midnight i get real personal and it’s weird.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "B*tch Problems",
      "screen_name" : "FemaleTexts",
      "indices" : [ "3", "15" ],
      "id_str" : "204887235",
      "id" : "204887235"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "437089573144129536",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437089573144129536",
  "created_at" : "Sat Feb 22 05:00:49 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @FemaleTexts: In life you will meet two kinds of people. Ones who build you up, and ones who tear you down. But in the end, you will tha…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "B*tch Problems",
      "screen_name" : "FemaleTexts",
      "indices" : [ "3", "15" ],
      "id_str" : "204887235",
      "id" : "204887235"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "437089521885523968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437089521885523968",
  "created_at" : "Sat Feb 22 05:00:37 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @FemaleTexts: Kiss me like you miss me.\uD83D\uDE18",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/psLwivbPl7",
      "expanded_url" : "http://bit.ly/1czS0gt",
      "display_url" : "bit.ly/1czS0gt",
      "indices" : [ "76", "98" ]
    } ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "id_str" : "437088423326007296",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437088423326007296",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 04:56:15 +0000 2014",
  "favorited" : false,
  "full_text" : "Revealed: President Jonathan’s First Query To Suspended CBN Governor Sanusi http://t.co/psLwivbPl7",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/8FQhbubOYF",
      "expanded_url" : "http://bit.ly/1foS6Zi",
      "display_url" : "bit.ly/1foS6Zi",
      "indices" : [ "42", "64" ]
    } ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "437088226478923776",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437088226478923776",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 04:55:28 +0000 2014",
  "favorited" : false,
  "full_text" : "Watch It: 10 Signs She’ll Make A BAD WIFE http://t.co/8FQhbubOYF",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/uBQbswUYaj",
      "expanded_url" : "http://bit.ly/1bTJomN",
      "display_url" : "bit.ly/1bTJomN",
      "indices" : [ "99", "121" ]
    } ]
  },
  "display_text_range" : [ "0", "121" ],
  "favorite_count" : "0",
  "id_str" : "437087611547815936",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437087611547815936",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 04:53:01 +0000 2014",
  "favorited" : false,
  "full_text" : "The Nigerian Guy Who Turned to a Pretty Lady Shows Off Incredible Photos Of Her S£xy Body [PHOTOS] http://t.co/uBQbswUYaj",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/VnFYPQBUYi",
      "expanded_url" : "http://bit.ly/OlpBlR",
      "display_url" : "bit.ly/OlpBlR",
      "indices" : [ "88", "110" ]
    } ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "0",
  "id_str" : "437087439157747712",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437087439157747712",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 04:52:20 +0000 2014",
  "favorited" : false,
  "full_text" : "WOW! Rooney Becomes Highest Paid Man Utd Footballer Ever! SEE How Much He's Paid (LOOK) http://t.co/VnFYPQBUYi",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/wj1XkBnVvl",
      "expanded_url" : "http://bit.ly/1foRJhj",
      "display_url" : "bit.ly/1foRJhj",
      "indices" : [ "62", "84" ]
    } ]
  },
  "display_text_range" : [ "0", "84" ],
  "favorite_count" : "0",
  "id_str" : "437087340855828480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437087340855828480",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 04:51:57 +0000 2014",
  "favorited" : false,
  "full_text" : "Apple Founder Steve Jobs Likely To Appear On US Postage Stamp http://t.co/wj1XkBnVvl",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/TJoRCK52DV",
      "expanded_url" : "http://bit.ly/1bTJb30",
      "display_url" : "bit.ly/1bTJb30",
      "indices" : [ "74", "96" ]
    } ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "437087005496066048",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437087005496066048",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 04:50:37 +0000 2014",
  "favorited" : false,
  "full_text" : "2.3 million tickets for the 2014 FIFA World Cup already allocated to fans http://t.co/TJoRCK52DV",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "32" ],
  "favorite_count" : "0",
  "id_str" : "437086681406377984",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437086681406377984",
  "created_at" : "Sat Feb 22 04:49:20 +0000 2014",
  "favorited" : false,
  "full_text" : "when there is life there is Hope",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/8w1emk6riu",
      "expanded_url" : "http://bit.ly/1czR4Zo",
      "display_url" : "bit.ly/1czR4Zo",
      "indices" : [ "31", "53" ]
    } ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "437086458449764352",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437086458449764352",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 22 04:48:27 +0000 2014",
  "favorited" : false,
  "full_text" : "Love doesn't lie, people do. ~ http://t.co/8w1emk6riu",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Gueinie",
      "screen_name" : "kinkysextweets",
      "indices" : [ "3", "18" ],
      "id_str" : "4716869174",
      "id" : "4716869174"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "437086102433071104",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437086102433071104",
  "created_at" : "Sat Feb 22 04:47:02 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @KinkySexTweets: If you miss her, you should tell her. If you love her, you should show it. She's worth the hurt, you already know it. M…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Psychological Facts",
      "screen_name" : "TheFactsBook",
      "indices" : [ "3", "16" ],
      "id_str" : "257799442",
      "id" : "257799442"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "130" ],
  "favorite_count" : "0",
  "id_str" : "437085643907530752",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437085643907530752",
  "created_at" : "Sat Feb 22 04:45:12 +0000 2014",
  "favorited" : false,
  "full_text" : "RT @TheFactsBook: \"Emotionap\" is the given term to which overwhelming emotions causes you to fall asleep in the middle of the day.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "0",
  "id_str" : "437085518493655040",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437085518493655040",
  "created_at" : "Sat Feb 22 04:44:42 +0000 2014",
  "favorited" : false,
  "full_text" : "One in five men between the ages of 25 and 34 are living with their parents",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Virgo",
      "indices" : [ "0", "6" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "0",
  "id_str" : "437085440165031936",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "437085440165031936",
  "created_at" : "Sat Feb 22 04:44:24 +0000 2014",
  "favorited" : false,
  "full_text" : "#Virgo women like a man with sexy hands and clean/manicured nails.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "id_str" : "436944716555644928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436944716555644928",
  "created_at" : "Fri Feb 21 19:25:13 +0000 2014",
  "favorited" : false,
  "full_text" : "Can our feelings be the same for each other?",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/4dvTabDi2l",
      "expanded_url" : "http://bit.ly/1dbsryZ",
      "display_url" : "bit.ly/1dbsryZ",
      "indices" : [ "24", "46" ]
    }, {
      "url" : "http://t.co/q4m69Q10Sn",
      "expanded_url" : "http://bit.ly/1dbsv1V",
      "display_url" : "bit.ly/1dbsv1V",
      "indices" : [ "47", "69" ]
    } ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "436944647194431488",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436944647194431488",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 19:24:56 +0000 2014",
  "favorited" : false,
  "full_text" : "How to approach failure http://t.co/4dvTabDi2l http://t.co/q4m69Q10Sn",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "30" ],
  "favorite_count" : "0",
  "id_str" : "436944215583768576",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436944215583768576",
  "created_at" : "Fri Feb 21 19:23:13 +0000 2014",
  "favorited" : false,
  "full_text" : "Reminder: charge your battery.",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/L0vmXypZAg",
      "expanded_url" : "http://bit.ly/1myvcEq",
      "display_url" : "bit.ly/1myvcEq",
      "indices" : [ "39", "61" ]
    } ]
  },
  "display_text_range" : [ "0", "61" ],
  "favorite_count" : "0",
  "id_str" : "436932907765354496",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436932907765354496",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:38:17 +0000 2014",
  "favorited" : false,
  "full_text" : "M.I ft. HHP – SuperHuman (Music Video) http://t.co/L0vmXypZAg",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "http://t.co/Nw8xfCprYF",
      "expanded_url" : "http://bit.ly/1myv9s7",
      "display_url" : "bit.ly/1myv9s7",
      "indices" : [ "80", "102" ]
    } ]
  },
  "display_text_range" : [ "0", "102" ],
  "favorite_count" : "0",
  "id_str" : "436932778522071040",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "436932778522071040",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 21 18:37:46 +0000 2014",
  "favorited" : false,
  "full_text" : "FILTHY GAME: A Gallery Of Proud Side Chicks On Instagram &amp; Twitter (PHOTOS) http://t.co/Nw8xfCprYF",
  "lang" : "en"
} ]