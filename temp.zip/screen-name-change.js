window.YTD.screen_name_change.part0 = [ {
  "screenNameChange" : {
    "accountId" : "259258056",
    "screenNameChange" : {
      "changedAt" : "2011-10-22T08:12:24.000Z",
      "changedFrom" : "Luiz_vicky",
      "changedTo" : "Lil_luiz_young"
    }
  }
}, {
  "screenNameChange" : {
    "accountId" : "259258056",
    "screenNameChange" : {
      "changedAt" : "2013-04-26T03:55:59.000Z",
      "changedFrom" : "Lil_luiz_young",
      "changedTo" : "vi_CAde"
    }
  }
}, {
  "screenNameChange" : {
    "accountId" : "259258056",
    "screenNameChange" : {
      "changedAt" : "2019-04-26T15:14:31.000Z",
      "changedFrom" : "vi_CAde",
      "changedTo" : "sorXCode"
    }
  }
} ]