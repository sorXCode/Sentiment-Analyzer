window.YTD.direct_message.part0 = [ {
  "dmConversation" : {
    "conversationId" : "15819466-259258056",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Congratulations!\n\nYou are a Day 12 Winner for the #Emilinks #MyDoorStory giveaway\n\nKindly send the following information and a photo of you featuring a bad door to team@bellanaija.com:\n\nFull Name:\nPhone Number:\nEmail Address: \nValid Bank Account Number:\nBank Name:\n\nThe subject of your email should be lucky Number 117\n\nOnce you receive your alert. Kindly inform others about your win and encourage them to enter. \n\nAlso, be reminded that the lucky number should be known to you and you and you alone. Any issues resulting as a default of this term will not be acknowledged by BellaNaija.\n\nYou can only win once during this promo, therefore you are not eligible to enter again.\n\nTerms &amp; Conditions Apply.\n\nThank you!",
        "mediaUrls" : [ ],
        "senderId" : "15819466",
        "id" : "767005689327788036",
        "createdAt" : "2016-08-20T14:29:41.329Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "20632300-259258056",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Please also follow us on Facebook: http://www.facebook.com/WrestlingNewsSourcecom & vist out website: http://WrestlingNewsSource.com",
        "mediaUrls" : [ ],
        "senderId" : "20632300",
        "id" : "2750130118",
        "createdAt" : "2011-04-05T17:43:12.000Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-751010851633725440",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "751010851633725440",
        "text" : "LOLITA!!! Whats up girlie? I kinda lost ur contact, av\nbeen trying 2 reach u... Be kind enuf\n2 drop ur number here??",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "899708269077426182",
        "createdAt" : "2017-08-21T19:02:21.974Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-620945249",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "620945249",
        "text" : "Hello, I GET NEW FOLLOWERS WITH FOLLOWPORT =&gt; /www.FOLLOWPORT.US ((please copy-paste for your safety)) I recommend it",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "401743838026272769",
        "createdAt" : "2013-11-16T16:09:29.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Evrytin is fine but boring",
        "mediaUrls" : [ ],
        "senderId" : "620945249",
        "id" : "395563487554187264",
        "createdAt" : "2013-10-30T14:50:59.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "620945249",
        "text" : "Heart Beat of Nigeria ;-) ...  how's everything over there?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "393469717559533569",
        "createdAt" : "2013-10-24T20:11:05.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Edo...benin",
        "mediaUrls" : [ ],
        "senderId" : "620945249",
        "id" : "393254335293169664",
        "createdAt" : "2013-10-24T05:55:14.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "620945249",
        "text" : "Ado-Ekiti... And you?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "391486902471491584",
        "createdAt" : "2013-10-19T08:52:05.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "tot,,,,,u no longer.\nanyway.......u based were?",
        "mediaUrls" : [ ],
        "senderId" : "620945249",
        "id" : "391485332539338752",
        "createdAt" : "2013-10-19T08:45:51.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "620945249",
        "text" : "Lol.. Sure I am... Y?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "390764494689173504",
        "createdAt" : "2013-10-17T09:01:30.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hey r u still on twitter?",
        "mediaUrls" : [ ],
        "senderId" : "620945249",
        "id" : "390484925683892224",
        "createdAt" : "2013-10-16T14:30:35.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "620945249",
        "text" : "Sorry, I didn't post that... My account was hacked into last night...",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363160032960987138",
        "createdAt" : "2013-08-02T04:51:13.000Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-965779717",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Rebranded to @Philosophy_Muse You can find my tweets there!",
        "mediaUrls" : [ ],
        "senderId" : "965779717",
        "id" : "330591236849278977",
        "createdAt" : "2013-05-04T07:54:27.000Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-1181208025",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Hello Ms. Lee, are you there?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "785078672365465604",
        "createdAt" : "2016-10-09T11:25:16.244Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Hello :-) how are you doing?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "393468945161670656",
        "createdAt" : "2013-10-24T20:08:01.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Lol from baby",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "364518708015685632",
        "createdAt" : "2013-08-05T22:50:07.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "If Olive Oil is made from Olives and Vegetable oils\r\nfrom Vegetables, then what is Baby oil made from???",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "364486950381555712",
        "createdAt" : "2013-08-05T20:43:55.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "okay, ódà'ró ",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363052597139099648",
        "createdAt" : "2013-08-01T21:44:19.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "M gonna write these down bby m sleepy now lets call it a nyt",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363051835210207233",
        "createdAt" : "2013-08-01T21:41:17.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "My night was fine ----- Mojú re",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363051480938315777",
        "createdAt" : "2013-08-01T21:39:52.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "how was your night? ----- Sojí re?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363051094538080256",
        "createdAt" : "2013-08-01T21:38:20.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "good morning --- ekáàró",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363049822116257792",
        "createdAt" : "2013-08-01T21:33:17.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Ohk lets start with the morning greeting",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363047654248292352",
        "createdAt" : "2013-08-01T21:24:40.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Sweet dreams is ódà'ró",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363047603463680000",
        "createdAt" : "2013-08-01T21:24:28.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "let's start with the greetings",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363046785792491520",
        "createdAt" : "2013-08-01T21:21:13.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Today? Okay",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363046594259582977",
        "createdAt" : "2013-08-01T21:20:27.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Starting from today???",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363046235415924736",
        "createdAt" : "2013-08-01T21:19:02.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "whenever you're ready ;-)",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363045974265954304",
        "createdAt" : "2013-08-01T21:17:59.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Ohk bby ithink i get you coz even us south africans we hv our own differences....so wen will u teach me Yoruba?",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363044270350950400",
        "createdAt" : "2013-08-01T21:11:13.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "They differ alot, in their language, dressing and all other aspects",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363039601213976576",
        "createdAt" : "2013-08-01T20:52:40.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Wow so how do they differ?",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363038668149096448",
        "createdAt" : "2013-08-01T20:48:58.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Im Yoruba but know a little Igbo",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363038138639187968",
        "createdAt" : "2013-08-01T20:46:51.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Yeah... that's from Igbo tribe...",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363037943159459840",
        "createdAt" : "2013-08-01T20:46:05.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Jus wana knw my bby more....so onyinye means girl?",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363036982819045376",
        "createdAt" : "2013-08-01T20:42:16.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Yeah... why?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363036756737667072",
        "createdAt" : "2013-08-01T20:41:22.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "As always my bby.......u nigerian ayt?",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363033956540628992",
        "createdAt" : "2013-08-01T20:30:14.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "thanx for understanding dear",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363033070686851072",
        "createdAt" : "2013-08-01T20:26:43.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "# #\r\n# ## #\r\n# #\r\n#\r\n#\r\n# # #\r\n# # #\r\n###",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363032800049373184",
        "createdAt" : "2013-08-01T20:25:39.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "No prob bby i understand...you wanted to know more abt me8-)",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363032753320624128",
        "createdAt" : "2013-08-01T20:25:27.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "ok... sorry for asking such a dumb question ",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363031494442229763",
        "createdAt" : "2013-08-01T20:20:27.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "And bby Masentle is not my bby shez my lil c-star",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363030605388189696",
        "createdAt" : "2013-08-01T20:16:55.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Lol we'l Masentle was born i december by dat tym me and yew were not chatting we started chatting in may if m nt mistaken",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363030202118459392",
        "createdAt" : "2013-08-01T20:15:19.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "the pregnancy",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363029476436766720",
        "createdAt" : "2013-08-01T20:12:26.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "I ddnt tel you abt wat?",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363028483997323264",
        "createdAt" : "2013-08-01T20:08:29.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "okau, i only asked cos u didnt tel me abt ur prg anymore...",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363028223384227840",
        "createdAt" : "2013-08-01T20:07:27.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Masentle is our familys last born",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363027568183631872",
        "createdAt" : "2013-08-01T20:04:51.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "who's the mother of Masentle?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363027125831335936",
        "createdAt" : "2013-08-01T20:03:06.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "yeah, true",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363026572187414529",
        "createdAt" : "2013-08-01T20:00:54.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "You wanted to chat my bby;) m all earz",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363026324866093056",
        "createdAt" : "2013-08-01T19:59:55.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "hi sweet pie... ",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "363025888197083138",
        "createdAt" : "2013-08-01T19:58:11.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Bby",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "363024947536334848",
        "createdAt" : "2013-08-01T19:54:26.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Lol :)",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "361578954714398720",
        "createdAt" : "2013-07-28T20:08:35.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Lolz.... thanx",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "361524847626575872",
        "createdAt" : "2013-07-28T16:33:35.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Lol u sure should be becoz dat was my aim #to flatter u",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "361504208819736576",
        "createdAt" : "2013-07-28T15:11:34.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "m flattered.... :*",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "361468644867330049",
        "createdAt" : "2013-07-28T12:50:15.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : ":)m the bestest because of you:D",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "361459811512094721",
        "createdAt" : "2013-07-28T12:15:09.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "but you're the bestest ;-)",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "361403129104830464",
        "createdAt" : "2013-07-28T08:29:55.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1181208025",
        "text" : "Lolz thanx... ",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "361402738363478017",
        "createdAt" : "2013-07-28T08:28:22.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "You the best :*",
        "mediaUrls" : [ ],
        "senderId" : "1181208025",
        "id" : "361399142821531649",
        "createdAt" : "2013-07-28T08:14:04.000Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-1896623816",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1896623816",
        "text" : "Hello Beautiful",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "436140286524522496",
        "createdAt" : "2014-02-19T14:08:42.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1896623816",
        "text" : "Okay",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "434999817434300416",
        "createdAt" : "2014-02-16T10:36:53.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "aYt Then i'll tell u on wechat",
        "mediaUrls" : [ ],
        "senderId" : "1896623816",
        "id" : "434999704443973632",
        "createdAt" : "2014-02-16T10:36:26.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1896623816",
        "text" : "Sure I will",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "434998337360912384",
        "createdAt" : "2014-02-16T10:31:00.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "n imma ask ya for a few favours! Thats if u willing to do em!",
        "mediaUrls" : [ ],
        "senderId" : "1896623816",
        "id" : "434998081332215808",
        "createdAt" : "2014-02-16T10:29:59.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "TheeWeirdKarabo",
        "mediaUrls" : [ ],
        "senderId" : "1896623816",
        "id" : "434997958384578561",
        "createdAt" : "2014-02-16T10:29:29.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1896623816",
        "text" : "What's your ID? I can't find you via your mobile number",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "434997678855159808",
        "createdAt" : "2014-02-16T10:28:23.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1896623816",
        "text" : "oh I see... I've been sending messages to your whatsapp but have not been receiving any reply",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "434995722543706112",
        "createdAt" : "2014-02-16T10:20:36.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1896623816",
        "text" : "Yes...",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "434995404787421184",
        "createdAt" : "2014-02-16T10:19:20.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Im Not On whatsapp Anymo",
        "mediaUrls" : [ ],
        "senderId" : "1896623816",
        "id" : "434995285669183488",
        "createdAt" : "2014-02-16T10:18:52.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Did U download Wechat?",
        "mediaUrls" : [ ],
        "senderId" : "1896623816",
        "id" : "434995217721458689",
        "createdAt" : "2014-02-16T10:18:36.000Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1896623816",
        "text" : "Hello kabs love...",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "434994768733827073",
        "createdAt" : "2014-02-16T10:16:49.000Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-2176015079",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hi, Get More Twitter Followers – Fast and Easy /www.NEWFOLLOWERS.ME ((please copy-paste for your safety))  I get real followers. Good Days.",
        "mediaUrls" : [ ],
        "senderId" : "2176015079",
        "id" : "401745208758398976",
        "createdAt" : "2013-11-16T16:14:56.000Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-2196875942",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hi, Do you want new followers? /www.bestfollowers.org (please copy-paste for your safety) I get more followers with this site. See you..",
        "mediaUrls" : [ ],
        "senderId" : "2196875942",
        "id" : "401807464519045121",
        "createdAt" : "2013-11-16T20:22:19.000Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-2238984385",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "2238984385",
        "text" : "ehn, kini?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "887332974190112772",
        "createdAt" : "2017-07-18T15:27:21.615Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "'Yanju :-)",
        "mediaUrls" : [ ],
        "senderId" : "2238984385",
        "id" : "854400507963691012",
        "createdAt" : "2017-04-18T18:25:29.954Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "259258056-2869365082",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "Pardon me. I won't be able to send that anytime soon, I'm currently at home for vacation and I don't have  my ID card here. Can I send it anytime I get back to school, hopefully next month?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "826757681234980867",
        "createdAt" : "2017-02-01T11:42:46.335Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hi Victor, Thank you for your response. We will like to see year of validity. Thank you for choosing Zoto.",
        "mediaUrls" : [ ],
        "senderId" : "2869365082",
        "id" : "826083265069056003",
        "createdAt" : "2017-01-30T15:02:53.021Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "The email address used is ennythan006@gmail.com \n\nThanks https://t.co/KqLioG1LsH",
        "mediaUrls" : [ "https://ton.twitter.com/dm/826065928433577993/826065835294912514/jNnUNBDh.jpg" ],
        "senderId" : "259258056",
        "id" : "826065928433577993",
        "createdAt" : "2017-01-30T13:54:00.149Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hi Victor, Thank you for your reaching out to us. May we request you send us the email address you used to send your National approved passport to us also send us the screenshot on here to further help assist. Thank you for choosing Zoto.",
        "mediaUrls" : [ ],
        "senderId" : "2869365082",
        "id" : "825994474643918852",
        "createdAt" : "2017-01-30T09:10:03.697Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "I've sent my school ID card to your mailbox",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "825356471110078467",
        "createdAt" : "2017-01-28T14:54:51.943Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hi Victor, From our investigation, we can see that your account is fraudulent. Please respond to referral user verification mail that was sent to you or Please send a screenshot of your Goverment issued ID card to claim your referral bonus. Thank you for choosing Zoto.",
        "mediaUrls" : [ ],
        "senderId" : "2869365082",
        "id" : "819822341463150595",
        "createdAt" : "2017-01-13T08:24:12.474Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "My issue remains unresolved. Any hope? Thanks",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "819695112343031811",
        "createdAt" : "2017-01-12T23:58:38.668Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "Hello Zubby, I still can't see your mail. How can I clear myself of this misconception?",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "811645135347916803",
        "createdAt" : "2016-12-21T18:50:54.603Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "Fraudulent? In what way? I can't see your mail in my mailbox.",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "810819498160877571",
        "createdAt" : "2016-12-19T12:10:07.359Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hi Victor,\n\nFrom our investigation, we can see that your account is fraudulent. Please respond to referral user verification mail that was sent to you. Thank you for choosing Zoto.",
        "mediaUrls" : [ ],
        "senderId" : "2869365082",
        "id" : "810779023949393923",
        "createdAt" : "2016-12-19T09:29:17.560Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "Thanks",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "808274738342752259",
        "createdAt" : "2016-12-12T11:38:09.480Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hi Victor, Your complaint has been forwarded to the appropriate team. Pls exercise patience we will let you know when we have a feedback",
        "mediaUrls" : [ ],
        "senderId" : "2869365082",
        "id" : "808274225911971843",
        "createdAt" : "2016-12-12T11:36:07.167Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "Okay, I understand. My referral code is ADEYAV, my registered number is 08100021452 and my friends' numbers are 08187787220, 09030048422, 08140026405, 08162276205, 08172577244, 07065332528 and one Olajide ( received a mail that he has recharged, but I no longer have his contact on my phone). Thanks.",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "808269395550175235",
        "createdAt" : "2016-12-12T11:16:55.524Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "259258056",
        "text" : "Hi Victor, We are sorry about the delay in your referral bonus. Due to the high volume of demand, we've scheduled the reward for the referral package in batches. However, you could send us your referral code, registered number and the friend that you referred's number. Thank you for choosing Zoto",
        "mediaUrls" : [ ],
        "senderId" : "2869365082",
        "id" : "808236043812139012",
        "createdAt" : "2016-12-12T09:04:23.854Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "2869365082",
        "text" : "Good day Zubby. I have a little problem with users I referred to this\nplatform. None of them seem to have received their referral bonus\nafter their first successful purchase and upload of their ID cards for\nverification. I haven't received my rewards for the refers too.\nWe know you're busy behind the system day and night to keep everyone\nand everything in balance and we appreciate you for that. It will be\nof great interest to your esteemed company if this issue is looked\ninto and solved. Thanks.",
        "mediaUrls" : [ ],
        "senderId" : "259258056",
        "id" : "807668509358653443",
        "createdAt" : "2016-12-10T19:29:13.094Z"
      }
    } ]
  }
} ]