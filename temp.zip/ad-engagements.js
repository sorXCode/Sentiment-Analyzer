window.YTD.ad_engagements.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Desktop"
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1093607194480656384",
              "tweetText" : "By the time you've finished your next cup of coffee, you'll forget half of what you just learned.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Pluralsight",
              "screenName" : "@pluralsight"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "Nigeria"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "Desktop"
            } ],
            "impressionTime" : "2019-04-27 15:10:00"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2019-04-27 15:12:20",
            "engagementType" : "CardUrlClick"
          } ]
        } ]
      }
    }
  }
} ]