window.YTD.follower.part0 = [ {
  "follower" : {
    "accountId" : "803516808758173696"
  }
}, {
  "follower" : {
    "accountId" : "122280832"
  }
}, {
  "follower" : {
    "accountId" : "1080653320384102404"
  }
}, {
  "follower" : {
    "accountId" : "1054396312475574273"
  }
}, {
  "follower" : {
    "accountId" : "1027283720024281089"
  }
}, {
  "follower" : {
    "accountId" : "936254324270870528"
  }
}, {
  "follower" : {
    "accountId" : "976598563512823809"
  }
}, {
  "follower" : {
    "accountId" : "3345029353"
  }
}, {
  "follower" : {
    "accountId" : "925181134232850433"
  }
}, {
  "follower" : {
    "accountId" : "889758434450690049"
  }
}, {
  "follower" : {
    "accountId" : "813587304694611968"
  }
}, {
  "follower" : {
    "accountId" : "828709510432829441"
  }
}, {
  "follower" : {
    "accountId" : "817771212122243072"
  }
}, {
  "follower" : {
    "accountId" : "499243108"
  }
}, {
  "follower" : {
    "accountId" : "802589568629350401"
  }
}, {
  "follower" : {
    "accountId" : "802629175668592641"
  }
}, {
  "follower" : {
    "accountId" : "4369327456"
  }
}, {
  "follower" : {
    "accountId" : "751010851633725440"
  }
}, {
  "follower" : {
    "accountId" : "1828924782"
  }
}, {
  "follower" : {
    "accountId" : "3377136730"
  }
}, {
  "follower" : {
    "accountId" : "41107832"
  }
}, {
  "follower" : {
    "accountId" : "2363669806"
  }
}, {
  "follower" : {
    "accountId" : "4835203017"
  }
}, {
  "follower" : {
    "accountId" : "2238984385"
  }
}, {
  "follower" : {
    "accountId" : "622112937"
  }
}, {
  "follower" : {
    "accountId" : "2277560471"
  }
}, {
  "follower" : {
    "accountId" : "251476656"
  }
}, {
  "follower" : {
    "accountId" : "272337283"
  }
}, {
  "follower" : {
    "accountId" : "257380317"
  }
}, {
  "follower" : {
    "accountId" : "897638228"
  }
}, {
  "follower" : {
    "accountId" : "2186984019"
  }
}, {
  "follower" : {
    "accountId" : "2187949042"
  }
}, {
  "follower" : {
    "accountId" : "1393119740"
  }
}, {
  "follower" : {
    "accountId" : "1380977688"
  }
}, {
  "follower" : {
    "accountId" : "56813097"
  }
}, {
  "follower" : {
    "accountId" : "243937772"
  }
}, {
  "follower" : {
    "accountId" : "456735656"
  }
}, {
  "follower" : {
    "accountId" : "1181208025"
  }
}, {
  "follower" : {
    "accountId" : "559956657"
  }
}, {
  "follower" : {
    "accountId" : "1226401826"
  }
}, {
  "follower" : {
    "accountId" : "83354760"
  }
}, {
  "follower" : {
    "accountId" : "486118647"
  }
}, {
  "follower" : {
    "accountId" : "477589376"
  }
} ]