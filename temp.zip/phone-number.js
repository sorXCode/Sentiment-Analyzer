window.YTD.phone_number.part0 = [ {
  "device" : {
    "phoneNumber" : "+2348100021452"
  }
} ]