window.YTD.block.part0 = [ {
  "blocking" : {
    "accountId" : "516578419"
  }
}, {
  "blocking" : {
    "accountId" : "288354398"
  }
} ]