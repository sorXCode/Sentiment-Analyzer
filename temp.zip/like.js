window.YTD.like.part0 = [ {
  "like" : {
    "tweetId" : "727559659733852161",
    "fullText" : "*takes the long way home just to listen to more songs*",
    "expandedUrl" : "https://twitter.com/i/web/status/727559659733852161"
  }
}, {
  "like" : {
    "tweetId" : "434351675978317824",
    "fullText" : "Gosh! I Seriously Need To Stop Retweeting -.-",
    "expandedUrl" : "https://twitter.com/i/web/status/434351675978317824"
  }
}, {
  "like" : {
    "tweetId" : "377315706393853952",
    "fullText" : "Jesus loves me.",
    "expandedUrl" : "https://twitter.com/i/web/status/377315706393853952"
  }
}, {
  "like" : {
    "tweetId" : "407079176806875136",
    "fullText" : "Avoy! - An expression of fear; surprise.",
    "expandedUrl" : "https://twitter.com/i/web/status/407079176806875136"
  }
}, {
  "like" : {
    "tweetId" : "392983974311899137",
    "fullText" : "Keep it real with the people around you no matter how fake they are.",
    "expandedUrl" : "https://twitter.com/i/web/status/392983974311899137"
  }
}, {
  "like" : {
    "tweetId" : "364177751646806018",
    "fullText" : "the best time to kiss a girl: http://t.co/zwfHHvthzW",
    "expandedUrl" : "https://twitter.com/i/web/status/364177751646806018"
  }
}, {
  "like" : {
    "tweetId" : "402904837056376832",
    "fullText" : "Can I have a picture of you so I can show Santa what I want for Christmas?",
    "expandedUrl" : "https://twitter.com/i/web/status/402904837056376832"
  }
}, {
  "like" : {
    "tweetId" : "372682565637111808",
    "fullText" : "After Tupac was cremated, his ashes were mixed with marijuana and smoked by members of his hip-hop group, Outlawz.",
    "expandedUrl" : "https://twitter.com/i/web/status/372682565637111808"
  }
}, {
  "like" : {
    "tweetId" : "407847608632090624",
    "fullText" : "I am done with the past, the future has plenty of room for change.",
    "expandedUrl" : "https://twitter.com/i/web/status/407847608632090624"
  }
}, {
  "like" : {
    "tweetId" : "393468002999742464",
    "fullText" : "Forget about Spiderman, Superman, and Batman. I’ll be your man.",
    "expandedUrl" : "https://twitter.com/i/web/status/393468002999742464"
  }
}, {
  "like" : {
    "tweetId" : "390140397978005504",
    "fullText" : "do you like stars? I know a motel with five.",
    "expandedUrl" : "https://twitter.com/i/web/status/390140397978005504"
  }
}, {
  "like" : {
    "tweetId" : "551898479757639680",
    "fullText" : "When you talk, you are repeating what you already know. But if you listen, you may learn something new.",
    "expandedUrl" : "https://twitter.com/i/web/status/551898479757639680"
  }
}, {
  "like" : {
    "tweetId" : "364463555263098880",
    "fullText" : "Strongly agree RT @JAYCEE_AKA_SEAN: It doesn't matter how fast you are going, as long as you are making progress!",
    "expandedUrl" : "https://twitter.com/i/web/status/364463555263098880"
  }
}, {
  "like" : {
    "tweetId" : "394316769449365504",
    "fullText" : "my brain has too many tabs open",
    "expandedUrl" : "https://twitter.com/i/web/status/394316769449365504"
  }
}, {
  "like" : {
    "tweetId" : "407252958158794752",
    "fullText" : "Thantophobia, the fear of losing someone you love.",
    "expandedUrl" : "https://twitter.com/i/web/status/407252958158794752"
  }
}, {
  "like" : {
    "tweetId" : "727577368345247745",
    "fullText" : "RT @ChaskaBorek Your looks may grab my eye, but your personality will hold my heart. #lovequotes",
    "expandedUrl" : "https://twitter.com/i/web/status/727577368345247745"
  }
}, {
  "like" : {
    "tweetId" : "388597629170757632",
    "fullText" : "\"By learning you will teach, by teaching you will learn.\" -Latin proverb @PfP4SA",
    "expandedUrl" : "https://twitter.com/i/web/status/388597629170757632"
  }
}, {
  "like" : {
    "tweetId" : "373195850140647425",
    "fullText" : "Hurt me once and i'll show you the true meaning of pain for the rest of yo living days #I_cross_my_heart_i_hope_to_die",
    "expandedUrl" : "https://twitter.com/i/web/status/373195850140647425"
  }
}, {
  "like" : {
    "tweetId" : "807860641948114944",
    "fullText" : "@Bigdaddybeba IM FCKIN CRYIN I LOOPED THIS 7 TIMES AKDJWLXNDLFN WHEN YOU SAID OW AT THE END IM DONE",
    "expandedUrl" : "https://twitter.com/i/web/status/807860641948114944"
  }
}, {
  "like" : {
    "tweetId" : "367129596056977410",
    "fullText" : "You’re a girl?  Prove it.",
    "expandedUrl" : "https://twitter.com/i/web/status/367129596056977410"
  }
}, {
  "like" : {
    "tweetId" : "407079284160090112",
    "fullText" : "Does your v-card have a code? Because I will hack it.",
    "expandedUrl" : "https://twitter.com/i/web/status/407079284160090112"
  }
}, {
  "like" : {
    "tweetId" : "435515371106222080",
    "fullText" : "The last thing I touch before I close my eyes is my phone",
    "expandedUrl" : "https://twitter.com/i/web/status/435515371106222080"
  }
}, {
  "like" : {
    "tweetId" : "412105356978814977",
    "fullText" : "If you do not enjoy what you are doing, you will never be good at it. -Luke Parker",
    "expandedUrl" : "https://twitter.com/i/web/status/412105356978814977"
  }
}, {
  "like" : {
    "tweetId" : "406103514109472768",
    "fullText" : "Be Strong Enough To Wαlk αwαy From Things or People Thαt Cαnt Put α Smile On Your Fαce No mαtter how Close You αre To that Shiiiiii",
    "expandedUrl" : "https://twitter.com/i/web/status/406103514109472768"
  }
}, {
  "like" : {
    "tweetId" : "435096331632508928",
    "fullText" : "Never regret growing old. Not everyone has that privilege.",
    "expandedUrl" : "https://twitter.com/i/web/status/435096331632508928"
  }
}, {
  "like" : {
    "tweetId" : "151490350131855360",
    "fullText" : "I was in love, and the feeling was even more wonderful than I ever imagined it could be.",
    "expandedUrl" : "https://twitter.com/i/web/status/151490350131855360"
  }
}, {
  "like" : {
    "tweetId" : "124871648695418881",
    "fullText" : "If at first you don’t succeed, try, try again. Then quit. There’s no point in being a damn fool about it.",
    "expandedUrl" : "https://twitter.com/i/web/status/124871648695418881"
  }
}, {
  "like" : {
    "tweetId" : "70157881932120064",
    "fullText" : "Mentally, my energy is like a figure 8, On the side, that's infinite. Method Man",
    "expandedUrl" : "https://twitter.com/i/web/status/70157881932120064"
  }
}, {
  "like" : {
    "tweetId" : "333627692924694528",
    "fullText" : "70% of people suffer from allodoxaphobia, the fear of annoying others.",
    "expandedUrl" : "https://twitter.com/i/web/status/333627692924694528"
  }
}, {
  "like" : {
    "tweetId" : "70138278615064576",
    "fullText" : "Love is like a mustard seed;\nplanted by God\nand watered by men.",
    "expandedUrl" : "https://twitter.com/i/web/status/70138278615064576"
  }
}, {
  "like" : {
    "tweetId" : "363126278938820609",
    "fullText" : "Peanut butter is an excellent cleaner for leather furniture. Just rub a small amount on and work it in in a circular motion.",
    "expandedUrl" : "https://twitter.com/i/web/status/363126278938820609"
  }
}, {
  "like" : {
    "tweetId" : "360093021724872705",
    "fullText" : "Umbrella can't stop the rain but protects us.....Confidence may not bring success but it gives a heart to face any challenge.",
    "expandedUrl" : "https://twitter.com/i/web/status/360093021724872705"
  }
}, {
  "like" : {
    "tweetId" : "104115687106150400",
    "fullText" : "A woman should know how to look like a girl, how to act like a lady, how to think like a man. #TFS",
    "expandedUrl" : "https://twitter.com/i/web/status/104115687106150400"
  }
}, {
  "like" : {
    "tweetId" : "70131629334609920",
    "fullText" : "Too few fish in the sea http://goo.gl/fb/QMI99",
    "expandedUrl" : "https://twitter.com/i/web/status/70131629334609920"
  }
}, {
  "like" : {
    "tweetId" : "124839842663251969",
    "fullText" : "If strippers are now called exotic dancers then drug dealers should be called exotic pharmacist.",
    "expandedUrl" : "https://twitter.com/i/web/status/124839842663251969"
  }
}, {
  "like" : {
    "tweetId" : "81548648156102656",
    "fullText" : "Workers in an ant colony only live for about 45-60 days, but a colony's queen can live up to 20 years. #OMGIneverKnew",
    "expandedUrl" : "https://twitter.com/i/web/status/81548648156102656"
  }
}, {
  "like" : {
    "tweetId" : "124885333153292288",
    "fullText" : "When friends kiss, they are no longer friends, and not yet lovers. They are something in between.",
    "expandedUrl" : "https://twitter.com/i/web/status/124885333153292288"
  }
}, {
  "like" : {
    "tweetId" : "91565561481400320",
    "fullText" : "If you are gentleman to me, you will see the lady in me. If you are a jerk to me, you will see the bitch in me.",
    "expandedUrl" : "https://twitter.com/i/web/status/91565561481400320"
  }
}, {
  "like" : {
    "tweetId" : "81547965256302596",
    "fullText" : "That which does not kill us makes us stronger.",
    "expandedUrl" : "https://twitter.com/i/web/status/81547965256302596"
  }
}, {
  "like" : {
    "tweetId" : "164392083627577346",
    "fullText" : "Be who you want to be, go where you want to go, and love who you want to love. #LargerThanWords",
    "expandedUrl" : "https://twitter.com/i/web/status/164392083627577346"
  }
}, {
  "like" : {
    "tweetId" : "360868686149599234",
    "fullText" : "Life must always be balanced.....therez a time for hair-pee-ness and a time for sorrow,time to smile n a (cont) http://t.co/dHvrVSNrMk",
    "expandedUrl" : "https://twitter.com/i/web/status/360868686149599234"
  }
}, {
  "like" : {
    "tweetId" : "103569384236269568",
    "fullText" : "For good and for bad, better or worse, it's my Indonesia homeland. Not just a home, but it's my identity. Happy Birthday Indonesia.",
    "expandedUrl" : "https://twitter.com/i/web/status/103569384236269568"
  }
}, {
  "like" : {
    "tweetId" : "125728959559245824",
    "fullText" : "\"Everything happens for a reason & people change like the seasons\" ~ @scads408",
    "expandedUrl" : "https://twitter.com/i/web/status/125728959559245824"
  }
}, {
  "like" : {
    "tweetId" : "125224629005598721",
    "fullText" : "Kissing is a habit. F***ing is a game. Guys get all the pleasure, but Girls get all the pain.",
    "expandedUrl" : "https://twitter.com/i/web/status/125224629005598721"
  }
}, {
  "like" : {
    "tweetId" : "102965240966295552",
    "fullText" : "Just because he's a boy, doesn't mean he won't cry when he looses the girl he loves. #DamnItsTrue",
    "expandedUrl" : "https://twitter.com/i/web/status/102965240966295552"
  }
}, {
  "like" : {
    "tweetId" : "363026894876598272",
    "fullText" : "I wont give up on you too champ @vi_cade",
    "expandedUrl" : "https://twitter.com/i/web/status/363026894876598272"
  }
} ]