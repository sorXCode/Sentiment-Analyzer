window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "",
      "website" : "",
      "location" : "Somewhere in the Milky way"
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/378800000228631568/01c7730a044661d644902c093a1644e0.jpeg",
    "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/259258056/1556345683"
  }
} ]