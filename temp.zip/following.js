window.YTD.following.part0 = [ {
  "following" : {
    "accountId" : "122280832"
  }
}, {
  "following" : {
    "accountId" : "2990403801"
  }
}, {
  "following" : {
    "accountId" : "1090299141664792576"
  }
}, {
  "following" : {
    "accountId" : "429173115"
  }
}, {
  "following" : {
    "accountId" : "1088596340"
  }
}, {
  "following" : {
    "accountId" : "2869365082"
  }
}, {
  "following" : {
    "accountId" : "2238984385"
  }
}, {
  "following" : {
    "accountId" : "751010851633725440"
  }
}, {
  "following" : {
    "accountId" : "15819466"
  }
}, {
  "following" : {
    "accountId" : "3401524931"
  }
}, {
  "following" : {
    "accountId" : "601227277"
  }
}, {
  "following" : {
    "accountId" : "3345029353"
  }
}, {
  "following" : {
    "accountId" : "2223762204"
  }
}, {
  "following" : {
    "accountId" : "262836675"
  }
}, {
  "following" : {
    "accountId" : "13520532"
  }
}, {
  "following" : {
    "accountId" : "72385532"
  }
}, {
  "following" : {
    "accountId" : "272337283"
  }
}, {
  "following" : {
    "accountId" : "58795639"
  }
}, {
  "following" : {
    "accountId" : "897638228"
  }
}, {
  "following" : {
    "accountId" : "1662909558"
  }
}, {
  "following" : {
    "accountId" : "2186984019"
  }
}, {
  "following" : {
    "accountId" : "277051086"
  }
}, {
  "following" : {
    "accountId" : "2187949042"
  }
}, {
  "following" : {
    "accountId" : "1255680978"
  }
}, {
  "following" : {
    "accountId" : "503428792"
  }
}, {
  "following" : {
    "accountId" : "408355601"
  }
}, {
  "following" : {
    "accountId" : "56813097"
  }
}, {
  "following" : {
    "accountId" : "331936328"
  }
}, {
  "following" : {
    "accountId" : "456735656"
  }
}, {
  "following" : {
    "accountId" : "1181208025"
  }
}, {
  "following" : {
    "accountId" : "1439544385"
  }
}, {
  "following" : {
    "accountId" : "559956657"
  }
}, {
  "following" : {
    "accountId" : "296623811"
  }
}, {
  "following" : {
    "accountId" : "126571944"
  }
}, {
  "following" : {
    "accountId" : "243937772"
  }
}, {
  "following" : {
    "accountId" : "965779717"
  }
}, {
  "following" : {
    "accountId" : "620945249"
  }
}, {
  "following" : {
    "accountId" : "123757534"
  }
}, {
  "following" : {
    "accountId" : "35274401"
  }
}, {
  "following" : {
    "accountId" : "73593143"
  }
}, {
  "following" : {
    "accountId" : "15693493"
  }
}, {
  "following" : {
    "accountId" : "77888423"
  }
}, {
  "following" : {
    "accountId" : "129845242"
  }
}, {
  "following" : {
    "accountId" : "91316071"
  }
}, {
  "following" : {
    "accountId" : "486118647"
  }
}, {
  "following" : {
    "accountId" : "251476656"
  }
}, {
  "following" : {
    "accountId" : "136123870"
  }
}, {
  "following" : {
    "accountId" : "125786481"
  }
}, {
  "following" : {
    "accountId" : "261074003"
  }
}, {
  "following" : {
    "accountId" : "26778990"
  }
}, {
  "following" : {
    "accountId" : "156917110"
  }
}, {
  "following" : {
    "accountId" : "75692158"
  }
}, {
  "following" : {
    "accountId" : "17471979"
  }
}, {
  "following" : {
    "accountId" : "17842366"
  }
} ]