window.YTD.mute.part0 = [ {
  "muting" : {
    "accountId" : "804084385"
  }
} ]