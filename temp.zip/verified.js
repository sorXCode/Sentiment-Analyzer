window.YTD.verified.part0 = [ {
  "verified" : {
    "accountId" : "259258056",
    "verified" : false
  }
} ]