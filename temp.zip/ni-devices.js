window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "messagingDevice" : {
      "phoneNumber" : "+2348100021452",
      "carrier" : "mtn_ng",
      "deviceType" : "Full",
      "updatedDate" : "2013.10.11",
      "createdDate" : "2012.05.28"
    }
  }
} ]