window.YTD.account.part0 = [ {
  "account" : {
    "phoneNumber" : "+2348100021452",
    "email" : "Victoradeyanju@rocketmail.com",
    "createdVia" : "oauth:49150",
    "username" : "sorXCode",
    "accountId" : "259258056",
    "createdAt" : "2011-03-01T13:50:10.000Z",
    "accountDisplayName" : "Victor Adeyanju"
  }
} ]