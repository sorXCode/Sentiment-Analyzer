window.YTD.account_timezone.part0 = [ {
  "accountTimezone" : {
    "accountId" : "259258056",
    "timeZone" : "West Central Africa"
  }
} ]