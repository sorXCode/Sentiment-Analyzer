window.YTD.email_address_change.part0 = [ {
  "emailAddressChange" : {
    "accountId" : "259258056",
    "emailChange" : {
      "changedAt" : "2011-03-01T14:11:51.000Z",
      "changedTo" : "Afarinnako@yahoo.com"
    }
  }
}, {
  "emailAddressChange" : {
    "accountId" : "259258056",
    "emailChange" : {
      "changedAt" : "2011-10-22T09:10:19.000Z",
      "changedFrom" : "Afarinnako@yahoo.com",
      "changedTo" : "Victoradeyanju@rocketmail.com"
    }
  }
} ]