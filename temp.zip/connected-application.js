window.YTD.connected_application.part0 = [ {
  "connectedApplication" : {
    "organization" : {
      "name" : "Seesmic"
    },
    "name" : "Seesmic",
    "description" : "Seesmic now offers the Twitter client you've been waiting for! A powerful feature-rich application that's simple and easy to use.",
    "permissions" : [ "read", "write", "directmessages" ],
    "approvedAt" : "2013-11-18T09:11:37.000Z",
    "id" : "128830"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Cando Entertainment, LLC",
      "url" : ""
    },
    "name" : "TwitrPix",
    "description" : "TwitrPix is a social media discovery and sharing platform that helps you upload and share photos on Twitter using a web browser, browser add-on, mobile phone or email.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2013-12-25T12:40:55.000Z",
    "id" : "1947"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter",
      "url" : "http://twitter.com"
    },
    "name" : "Mobile Web",
    "description" : "Twitter Mobile Web",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2014-08-19T02:57:40.000Z",
    "id" : "49152"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Opera Software ASA",
      "url" : "http://www.opera.com/"
    },
    "name" : "Opera Mini",
    "description" : "Opera Mini web browser",
    "permissions" : [ "read" ],
    "approvedAt" : "2012-11-04T05:47:14.000Z",
    "id" : "1527565"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "ProcessOne",
      "url" : "http://www.process-one.net"
    },
    "name" : "Tweet.IM",
    "description" : "ProcessOne public instance of Twitter XMPP gateway. This gateway can be use to use Twitter from any XMPP client.",
    "permissions" : [ "read", "write", "directmessages" ],
    "approvedAt" : "2012-08-02T04:36:20.000Z",
    "id" : "41743"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Samsung Electronics",
      "url" : "http://www.samsung.com"
    },
    "name" : "Samsung Mobile",
    "description" : "Samsung mobile own applications",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2014-09-15T19:29:13.000Z",
    "id" : "50735"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Yahoo",
      "url" : "https://www.yahoo.com"
    },
    "name" : "Yahoo",
    "description" : "Yahoo application",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2012-02-27T07:47:08.000Z",
    "id" : "54643"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Facebook",
      "url" : "http://www.facebook.com"
    },
    "name" : "Facebook",
    "description" : "Facebook to Twitter",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2013-11-15T22:14:37.000Z",
    "id" : "14220"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "",
      "url" : ""
    },
    "name" : "Twitter for Nokia S40",
    "description" : "Twitter for Nokia Series 40 and Asha devices.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2015-09-04T06:09:02.000Z",
    "id" : "1881168"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "",
      "url" : ""
    },
    "name" : "HTC BlinkFeed",
    "description" : "This application allows us to show tweets on HTC BlinkFeed",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2015-09-17T09:04:13.000Z",
    "id" : "4104199"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : ""
    },
    "name" : "solend_owl",
    "description" : "A test twitter application for Tutorial Demonstration",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2019-06-11T14:55:03.000Z",
    "id" : "16515065"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "TwitLonger Ltd"
    },
    "name" : "Twitlonger",
    "description" : "Twitlonger is a simple app to allow you to post longer thoughts via Twitter, without the need to write a whole blog post. Think of it like Twitpic for text.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2013-09-05T05:24:14.000Z",
    "id" : "169"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitpic Inc",
      "url" : "http://twitpic.com"
    },
    "name" : "Twitpic",
    "description" : "Share photos on Twitter with Twitpic",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2013-08-04T04:41:09.000Z",
    "id" : "3294"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter, Inc.",
      "url" : ""
    },
    "name" : "Twitter for Android",
    "description" : "Twitter for Android",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2013-06-26T21:23:28.000Z",
    "id" : "258901"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "",
      "url" : ""
    },
    "name" : "Write Longer",
    "description" : "An alternative to mobile Twitter, bringing you the best tweeting experience to your phone.",
    "permissions" : [ "read", "write", "directmessages" ],
    "approvedAt" : "2013-08-03T21:50:46.000Z",
    "id" : "1217755"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "",
      "url" : ""
    },
    "name" : "GifBoom App",
    "description" : "Gifboom is an application to publish your gifs to social networks!",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2017-02-23T16:24:56.000Z",
    "id" : "1168999"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Disqus",
      "url" : "http://disqus.com/",
      "privacyPolicyUrl" : "https://help.disqus.com/customer/portal/articles/466259-privacy-policy",
      "termsAndConditionsUrl" : "https://help.disqus.com/customer/portal/articles/466260-terms-of-service"
    },
    "name" : "DISQUS",
    "description" : "Disqus is a service and tool for web comments and discussions.",
    "permissions" : [ "read", "emailaddress" ],
    "approvedAt" : "2018-07-06T10:18:50.000Z",
    "id" : "2858"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Research In Motion Limited",
      "url" : "http://www.rim.com"
    },
    "name" : "Twitter for BlackBerry®",
    "description" : "Twitter for BlackBerry® smartphones helps you stay in touch anywhere, anytime. You can post a tweet, follow other Twitter users, search, upload photos and more",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2014-02-06T20:00:44.000Z",
    "id" : "48025"
  }
} ]