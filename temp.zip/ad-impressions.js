window.YTD.ad_impressions.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "impressionTime" : "2019-04-26 14:04:20",
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "WtfSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        }, {
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "SearchTweets",
          "promotedTweetInfo" : {
            "tweetId" : "1118853165179387906",
            "tweetText" : "It’s been Four years of Africa’s biggest food festival and we are ready to do it again.\n\nClear your calendars; Come, Let's Eat!! \uD83C\uDF7D️\n\n#GTBankFoodDrink https://t.co/yibVBMEfSp",
            "urls" : [ ],
            "mediaUrls" : [ "https://t.co/yibVBMEfSp" ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Guaranty Trust Bank",
            "screenName" : "@gtbank"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          } ],
          "impressionTime" : "2019-04-26 14:04:36"
        }, {
          "impressionTime" : "2019-04-26 15:46:09",
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "WtfSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        }, {
          "impressionTime" : "2019-04-26 15:08:06",
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "ProfileAccountsSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        }, {
          "impressionTime" : "2019-04-26 13:31:08",
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "WtfSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        }, {
          "impressionTime" : "2019-04-26 13:32:23",
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "WtfSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        }, {
          "impressionTime" : "2019-04-26 13:31:47",
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "WtfSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1120723923694489600",
            "tweetText" : "Luke Whearty is the bar operator, restaurant innovator, drink creator and founder of BYRDI with over a decade of experience.\n\nLuke will be at the GTBank Food and Drink Festival. To register for his class: https://t.co/XvEBq1Ov6V\n\n#GTBankFoodDrink https://t.co/w8P2A47hXH",
            "urls" : [ "https://t.co/XvEBq1Ov6V" ],
            "mediaUrls" : [ "https://t.co/w8P2A47hXH" ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Guaranty Trust Bank",
            "screenName" : "@gtbank"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          } ],
          "impressionTime" : "2019-04-27 06:33:27"
        }, {
          "impressionTime" : "2019-04-27 06:12:18",
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "ProfileAccountsSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        }, {
          "impressionTime" : "2019-04-27 06:10:58",
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "ProfileAccountsSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1121345692021088258",
            "tweetText" : "We have a bank account especially for you and your needs.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Zenith Bank",
            "screenName" : "@ZenithBank"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Keywords",
            "targetingValue" : "league"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "starts"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "please"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          } ],
          "impressionTime" : "2019-04-27 06:19:16"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "impressionTime" : "2019-04-27 15:10:15",
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "WtfSidebar",
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          }
        }, {
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1093607194480656384",
            "tweetText" : "By the time you've finished your next cup of coffee, you'll forget half of what you just learned.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          }, {
            "targetingType" : "Platforms",
            "targetingValue" : "Desktop"
          } ],
          "impressionTime" : "2019-04-27 15:11:37"
        }, {
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1103511283049984000",
            "tweetText" : "Official from China's council on poverty alleviation and development:\n- Over 80 million living in rural areas have been lifted out of poverty in 6 years\n- Goal is to lift all counties out of poverty by 2020.\nFollow us for more.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "CGTN",
            "screenName" : "@CGTNOfficial"
          },
          "impressionTime" : "2019-04-27 15:13:40"
        }, {
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1097948939645607939",
            "tweetText" : "Launch your website today for only $2.95/month* #CantGetBetterThanThis #MyNewWebsite",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Bluehost",
            "screenName" : "@bluehost"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Tailored audiences (web)",
            "targetingValue" : "Abandoned Cart - Shared"
          }, {
            "targetingType" : "Tailored audiences (web)",
            "targetingValue" : "New Signups"
          }, {
            "targetingType" : "Languages",
            "targetingValue" : "English"
          }, {
            "targetingType" : "Platforms",
            "targetingValue" : "Desktop"
          } ],
          "impressionTime" : "2019-04-27 15:12:54"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1121345692021088258",
            "tweetText" : "We have a bank account especially for you and your needs.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Zenith Bank",
            "screenName" : "@ZenithBank"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Keywords",
            "targetingValue" : "league"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "today"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "starts"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "people"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "please"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "new"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "share"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "nigerian"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "needs"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "team"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "nigeria"
          }, {
            "targetingType" : "Keywords",
            "targetingValue" : "need"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          } ],
          "impressionTime" : "2019-04-28 06:59:50"
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1097948939645607939",
            "tweetText" : "Launch your website today for only $2.95/month* #CantGetBetterThanThis #MyNewWebsite",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Bluehost",
            "screenName" : "@bluehost"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Retargeting campaign engager",
            "targetingValue" : "Retargeting campaign engager: 12515415"
          }, {
            "targetingType" : "Retargeting engagement type",
            "targetingValue" : "Retargeting engagement type: 1"
          }, {
            "targetingType" : "Tailored audiences (web)",
            "targetingValue" : "New Signups"
          }, {
            "targetingType" : "Languages",
            "targetingValue" : "English"
          }, {
            "targetingType" : "Platforms",
            "targetingValue" : "Android"
          } ],
          "impressionTime" : "2019-04-28 06:59:22"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "SearchTweets",
          "promotedTweetInfo" : {
            "tweetId" : "1121345692021088258",
            "tweetText" : "We have a bank account especially for you and your needs.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Zenith Bank",
            "screenName" : "@ZenithBank"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          } ],
          "impressionTime" : "2019-05-14 18:35:30"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1120564022653390853",
            "tweetText" : "\uD83D\uDCE3 Calling all traders! Start earning real tradeable cash with FXTM's biggest promotion ever. \uD83D\uDCB0\nGet 30% back on each of your deposits \uD83D\uDE4C all the way up to a massive $5K bonus!\uD83D\uDCB2Act fast, you only have 30 days!",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "ForexTime - FXTM",
            "screenName" : "@ItsForexTime"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@fidelitybankplc"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@vanguardngrnews"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@elrufai"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@PeterPsquare"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@THEBEAT999FM"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@BankyW"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@ChibuikeAmaechi"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@Soundsultan"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@eLDeeTheDon"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@UNIONBANK_NG"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@GuardianNigeria"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@PremiumTimesng"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@MobilePunch"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@ShopKonga"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@IAmOkocha"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@AirtelNigeria"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@JumiaNigeria"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@MI_Abaga"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@inecnigeria"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@PolarisBankLtd"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@NigeriaNewsdesk"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@basket_mouth"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@bellanaija"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@access_more"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@CoolFMNigeria"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@channelstv"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@UBAGroup"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@tundefashola"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@official2baba"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@TiwaSavage"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@ProfOsinbajo"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@NOIweala"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@abikedabiri"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@wemabank"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@abati1990"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@FirstBankngr"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@wandecoal"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@AsiwajuTinubu"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@gtbank"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@kfayemi"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@SaharaReporters"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@ZenithBank"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@bukolasaraki"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@myaccessbank"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@LeadershipNGA"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@THISDAYLIVE"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@iam_Davido"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@wizkidayo"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@DONJAZZY"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@obyezeks"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@raufaregbesola"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@realFFK"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@TheNationNews"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@atiku"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@IamDrSID"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@GenevieveNnaji1"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@NuhuRibadu"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@OnaziOgenyi"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@StanbicIBTC"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@Realomosexy"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@UnityBankPlc"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@Iceprincezamani"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@APCNigeria"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@YNaija"
          }, {
            "targetingType" : "Tailored audiences (web)",
            "targetingValue" : "RegMy-Lead"
          }, {
            "targetingType" : "Age",
            "targetingValue" : "21 and up"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          }, {
            "targetingType" : "Platforms",
            "targetingValue" : "Android"
          }, {
            "targetingType" : "Gender",
            "targetingValue" : "Male"
          } ],
          "impressionTime" : "2019-05-17 22:43:00"
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1097948939645607939",
            "tweetText" : "Launch your website today for only $2.95/month* #CantGetBetterThanThis #MyNewWebsite",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Bluehost",
            "screenName" : "@bluehost"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Retargeting campaign engager",
            "targetingValue" : "Retargeting campaign engager: 12515415"
          }, {
            "targetingType" : "Retargeting engagement type",
            "targetingValue" : "Retargeting engagement type: 1"
          }, {
            "targetingType" : "Tailored audiences (web)",
            "targetingValue" : "New Signups"
          }, {
            "targetingType" : "Languages",
            "targetingValue" : "English"
          }, {
            "targetingType" : "Platforms",
            "targetingValue" : "Android"
          } ],
          "impressionTime" : "2019-05-17 22:39:10"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "SearchTweets",
          "promotedTweetInfo" : {
            "tweetId" : "1121347212733288448",
            "tweetText" : "Can’t move your #data or applications to the #publiccloud? Let @Oracle provide the public cloud behind your firewall with Oracle #Cloud at Customer: https://t.co/8GSuX8GEkL",
            "urls" : [ "https://t.co/8GSuX8GEkL" ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Oracle IT Infrastructure",
            "screenName" : "@Infrastructure"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@ForbesTech"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@Gizmodo"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@WIRED"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@intel"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@TechCrunch"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@engadget"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@CNET"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@guardiantech"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          } ],
          "impressionTime" : "2019-05-23 16:10:15"
        }, {
          "deviceInfo" : {
            "osType" : "Android"
          },
          "displayLocation" : "SearchTweets",
          "promotedTweetInfo" : {
            "tweetId" : "1128511949984210944",
            "tweetText" : "5 game-changing practices for a leader who takes the reins after a legendary executive departs.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "strategy+business",
            "screenName" : "@stratandbiz"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@SkipPrichard"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@kenblanchard"
          }, {
            "targetingType" : "Follower look-alikes",
            "targetingValue" : "@HarvardBiz"
          }, {
            "targetingType" : "Languages",
            "targetingValue" : "English"
          } ],
          "impressionTime" : "2019-05-23 16:10:31"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adImpressions" : {
        "impressions" : [ {
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1093607194480656384",
            "tweetText" : "By the time you've finished your next cup of coffee, you'll forget half of what you just learned.",
            "urls" : [ ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Pluralsight",
            "screenName" : "@pluralsight"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          }, {
            "targetingType" : "Platforms",
            "targetingValue" : "Desktop"
          } ],
          "impressionTime" : "2019-06-11 15:31:50"
        }, {
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "WtfSidebar",
          "advertiserInfo" : {
            "advertiserName" : "People's Daily, China",
            "screenName" : "@PDChina"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          } ],
          "impressionTime" : "2019-06-11 15:31:55"
        }, {
          "deviceInfo" : {
            "osType" : "Desktop"
          },
          "displayLocation" : "TimelineHome",
          "promotedTweetInfo" : {
            "tweetId" : "1136699273267912704",
            "tweetText" : "#Success comes to the #doers of today, not the what if’ers of tomorrow. #Website #WebHosting #Bluehost \uD83D\uDC49https://t.co/JcqlZw2M5F",
            "urls" : [ "https://t.co/JcqlZw2M5F" ],
            "mediaUrls" : [ ]
          },
          "advertiserInfo" : {
            "advertiserName" : "Bluehost",
            "screenName" : "@bluehost"
          },
          "matchedTargetingCriteria" : [ {
            "targetingType" : "Retargeting campaign engager",
            "targetingValue" : "Retargeting campaign engager: 12515415"
          }, {
            "targetingType" : "Retargeting engagement type",
            "targetingValue" : "Retargeting engagement type: 1"
          }, {
            "targetingType" : "Tailored audiences (web)",
            "targetingValue" : "New Signups"
          }, {
            "targetingType" : "Locations",
            "targetingValue" : "Nigeria"
          }, {
            "targetingType" : "Platforms",
            "targetingValue" : "Desktop"
          } ],
          "impressionTime" : "2019-06-11 13:28:50"
        } ]
      }
    }
  }
} ]